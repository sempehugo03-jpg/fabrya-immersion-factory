import unittest

from fabrya_factory.orchestrator import GenerationOrchestrator
from fabrya_factory.security import new_project_token
from tests.support import TempStore


class OrchestratorTests(TempStore, unittest.TestCase):
    def test_provider_disabled_job_is_checkpointed_and_blocked_without_network(self):
        project = self.store.create_project("No-provider project", new_project_token())
        job, _ = self.store.create_job(str(project["id"]), "Atelier Équinoxe", "orch-0001")
        orchestrator = GenerationOrchestrator(self.store, provider_enabled=False)
        self.assertTrue(orchestrator.run_one())
        result = self.store.get_job(str(project["id"]), str(job["id"]))
        self.assertEqual(result["status"], "blocked")
        self.assertEqual(result["error_code"], "OPENAI_PROVIDER_DISABLED")
        checkpoints = self.store.list_checkpoints(str(job["id"]))
        self.assertTrue(any(x["payload"].get("external_calls") == 0 for x in checkpoints))

    def test_enabled_flag_without_key_or_adapter_stays_blocked(self):
        project = self.store.create_project("Still disabled", new_project_token())
        job, _ = self.store.create_job(str(project["id"]), "Brief", "orch-0002")
        orchestrator = GenerationOrchestrator(self.store, provider_enabled=True)
        self.assertTrue(orchestrator.run_one())
        result = self.store.get_job(str(project["id"]), str(job["id"]))
        self.assertEqual(result["status"], "blocked")
        self.assertEqual(result["error_code"], "OPENAI_BUDGET_NOT_CONFIGURED")


if __name__ == "__main__":
    unittest.main()
