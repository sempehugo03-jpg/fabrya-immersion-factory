"""Hand-authored schema fixtures for offline tests; never returned as OpenAI output."""

REFERENCE_BRIEFS = {
    "garage": "Atelier Équinoxe est un garage automobile premium spécialisé dans les véhicules sportifs et de collection. Le site doit être cinématographique, élégant, immersif dès l'ouverture, avec navigation remarquable et images photoréalistes originales.",
    "podology": "Un cabinet de podologie reçoit des patients pour bilans et soins du pied. Le site doit rassurer, expliquer les prestations et faciliter la prise de rendez-vous, sans promettre de résultat médical.",
    "interior_architecture": "Un studio d'architecture intérieure accompagne des rénovations et aménagements résidentiels. Le site doit présenter sa méthode et ses projets, distinguer les réalisations authentiques des images conceptuelles et susciter des demandes de rendez-vous.",
}


def blueprint_fixture(kind: str) -> dict[str, object]:
    profiles = {
        "garage": {
            "company_name": "Atelier Équinoxe", "industry": "Garage premium de véhicules sportifs et de collection",
            "offerings": ["Entretien et accompagnement de véhicules sportifs et de collection"],
            "positioning": "Soin expert et culture automobile, sans promesse non fournie.",
            "facts_from_brief": ["Garage premium", "Véhicules sportifs et de collection"],
            "assumptions": ["Une clientèle recherche un accueil sélectif"], "missing_information": ["Adresse", "Équipe", "Services exacts", "Véhicules et locaux authentiques"],
        },
        "podology": {
            "company_name": "Cabinet de podologie", "industry": "Podologie et soins du pied",
            "offerings": ["Bilans", "Soins du pied"], "positioning": "Information claire et accueil rassurant, sans promesse thérapeutique.",
            "facts_from_brief": ["Cabinet de podologie", "Bilans et soins", "Rendez-vous souhaités"],
            "assumptions": ["Des patients peuvent être anxieux"], "missing_information": ["Adresse", "Diplômes", "Tarifs", "Moyens de réservation"],
        },
        "interior_architecture": {
            "company_name": "Studio d'architecture intérieure", "industry": "Architecture intérieure et rénovation résidentielle",
            "offerings": ["Accompagnement de rénovations", "Aménagement résidentiel"],
            "positioning": "Une approche de projet lisible, appuyée par une sélection authentique de réalisations.",
            "facts_from_brief": ["Studio d'architecture intérieure", "Projets résidentiels", "Rénovation et aménagement"],
            "assumptions": ["Le processus de conception peut devenir une preuve de valeur"], "missing_information": ["Nom de marque", "Zone géographique", "Réalisations photographiées", "Budget moyen"],
        },
    }
    profile = profiles[kind]
    if kind == "garage":
        title, concept, fit, atmosphere = "Le silence avant le départ", "Une automobile traitée comme une pièce mécanique au repos, révélée par une lumière rasante qui glisse sur ses formes.", "Le contraste entre précision d'atelier et rareté des véhicules traduit le positionnement premium sans inventer l'apparence réelle du garage.", "Noir graphite, reflet ambre, silence tendu et gestes précis."
        palette = [("Graphite", "#17191B", "fond"), ("Ambre atelier", "#D29A52", "accent"), ("Craie", "#EEEAE2", "texte")]
        signature = "Une bande de lumière révèle progressivement les courbes d'une voiture conceptuelle au premier défilement."
        webgl, three_d = False, "Une photographie conceptuelle originale suffit pour cette direction; un rendu WebGL ajouterait du poids sans apporter de valeur démontrée."
        asset_role, asset_prompt, auth = "Hero conceptuel automobile", "Photographie conceptuelle originale d'une sportive de collection non identifiable, cadrage bas trois-quarts, atelier noir générique, reflet ambre contrôlé, matière métal et cuir, composition ample avec espace de titre, sans logo ni détail revendiqué comme authentique.", False
    elif kind == "podology":
        title, concept, fit, atmosphere = "La confiance au premier pas", "Une ligne de pression abstraite se transforme en repères de parcours de soin, du bilan au rendez-vous.", "Un langage calme et explicatif réduit l'inquiétude et soutient la prise de rendez-vous sans présenter un résultat médical garanti.", "Ivoire, sauge et lumière diffuse; gestes lents et surfaces tactiles."
        palette = [("Ivoire", "#F4F0E8", "fond"), ("Sauge", "#71877A", "accent"), ("Encre douce", "#26342F", "texte")]
        signature = "Une ligne d'appui abstraite guide le regard du premier écran vers les étapes du bilan, puis vers le rendez-vous."
        webgl, three_d = False, "Une composition typographique et une illustration conceptuelle légère expliquent mieux le parcours qu'une scène 3D médicale."
        asset_role, asset_prompt, auth = "Illustration conceptuelle du mouvement", "Illustration conceptuelle originale d'une empreinte stylisée et d'une ligne de pression douce, fond ivoire, lumière diffuse, cadrage vertical mobile adaptable, sans corps reconnaissable, sans imagerie de diagnostic et sans allégation médicale.", False
    else:
        title, concept, fit, atmosphere = "Habiter la lumière", "Chaque projet s'ouvre par une coupe lumineuse: matière, volume et circulation deviennent une séquence de seuils.", "Le concept fait ressentir l'espace avant de montrer le processus, tandis que les réalisations réelles restent séparées des mises en scène conceptuelles.", "Minéral chaud, ombre nette, papier architectural et lumière de fin de journée."
        palette = [("Craie minérale", "#E8E2D7", "fond"), ("Terre cuite", "#A85E43", "accent"), ("Basalte", "#292A28", "texte")]
        signature = "Une coupe spatiale en panoramique fait passer d'un seuil sombre à un volume lumineux, puis révèle la méthode du studio."
        webgl, three_d = True, "Une scène WebGL ne se justifiera que si un modèle d'espace authentique ou expressément autorisé est fourni; sinon, produire une séquence photographique conceptuelle légère."
        asset_role, asset_prompt, auth = "Espace résidentiel conceptuel", "Image conceptuelle photoréaliste d'un intérieur résidentiel imaginaire, rénovation contemporaine aux matières minérales et bois chaud, rayon de soleil découpé, composition avec profondeur axiale et espace de texte, sans prétendre représenter une réalisation du studio.", False
    return {
        "contract_version": "fabrya.creative-blueprint/v1",
        "analysis": {
            "business_profile": profile,
            "target_audience": ["Personnes cherchant un service professionnel adapté à leur besoin"],
            "conversion_goals": ["Demande de contact ou rendez-vous"],
            "visual_constraints": ["Ne pas inventer les faits absents du brief", "Pas d'images de banque tierce"],
            "client_assets": [{"description": "Références authentiques de marque et de lieu non encore fournies", "status": "needs_authentic_reference", "intended_use": "Réserver les zones d'authenticité aux médias autorisés par le client."}],
        },
        "art_direction": {
            "concept_title": title, "central_concept": concept, "business_fit_rationale": fit, "atmosphere": atmosphere,
            "palette": [{"name": n, "hex": h, "role": r} for n, h, r in palette],
            "typography_direction": "Une grotesque nette pour l'information et une sérif de contraste pour les titres éditoriaux.",
            "composition": "Un sujet dominant, une hiérarchie claire et des zones de respiration; éviter la grille de cartes répétée.",
            "photography_direction": {"style": "Photographie éditoriale conceptuelle, originale et clairement signalée comme telle.", "framing": "Sujet décentré et espace négatif réservé aux textes; variante de cadrage mobile dédiée.", "lighting": atmosphere, "materials": "Matières choisies pour cette identité et conservées dans tous les visuels.", "authenticity_rules": ["Ne pas inventer les locaux, salariés, témoignages ou projets réels.", "Utiliser les médias du client uniquement avec autorisation."]},
            "narrative": "Du premier contact visuel à la compréhension du service, puis vers une action simple.",
            "page_hierarchy": [{"page": "Accueil", "purpose": "Présenter le concept et guider vers l'offre", "visual_role": "Moment signature"}, {"page": "Services", "purpose": "Expliquer les prestations", "visual_role": "Lisibilité"}, {"page": "Contact", "purpose": "Déclencher la demande", "visual_role": "Confiance et action"}],
            "originality_guardrails": [f"Ne pas réutiliser le concept « {title} » pour une autre entreprise.", "Aucun template recoloré; les visuels restent conceptuels tant que les références ne sont pas fournies."],
        },
        "immersion": {
            "signature_moment": signature,
            "depth_model": "Profondeur créée par cadrage, lumière, échelle et transition; pas d'effet parallax par défaut.",
            "interactions": [{"name": title, "trigger": "Premier écran puis défilement", "behavior": signature, "rationale": fit, "mobile_behavior": "Séquence verticale à assets cadrés pour petit écran.", "reduced_motion_behavior": "Afficher directement l'image et le repère de contenu, sans mouvement obligatoire.", "performance_cost": "low"}],
            "three_d_decision": {"use_webgl": webgl, "rationale": three_d, "fallback": "Séquence d'images optimisées et transition CSS sans dépendance WebGL."},
            "transition_plan": ["Révélation du concept", "Explication du service", "Appel à l'action"],
            "mobile_adaptation": ["Composition verticale dédiée", "CTA visible", "Aucune dépendance au survol"],
            "reduced_motion_plan": "Respecter prefers-reduced-motion; retirer l'animation et conserver le contenu final immédiatement visible.",
            "performance_constraints": ["Chargement différé hors écran", "Média principal compressé", "Animations transform/opacity uniquement"],
        },
        "visual_plan": {
            "global_consistency_rules": ["Même courbe de lumière, même traitement colorimétrique", "Pas d'image tierce récupérée"],
            "external_stock_media_allowed": False,
            "assets": [{"asset_id": f"concept-{kind}-hero", "role": asset_role, "representation": "conceptual_generated_visual", "subject_and_content": asset_prompt, "composition": "Sujet cadré dans un environnement qui laisse place au titre.", "desktop_framing": "Paysage, grand espace négatif latéral.", "mobile_framing": "Portrait recadré sur le sujet principal.", "lighting": atmosphere, "format": "WebP ou AVIF responsive, source haute qualité conservée.", "continuity_notes": "Palette, matériaux et lumière strictement alignés sur la direction artistique.", "generation_prompt": asset_prompt, "authentic_reference_required": auth, "authenticity_note": "Concept visuel fictif, ne représente pas l'entreprise ou une réalisation réelle."}],
        },
    }
