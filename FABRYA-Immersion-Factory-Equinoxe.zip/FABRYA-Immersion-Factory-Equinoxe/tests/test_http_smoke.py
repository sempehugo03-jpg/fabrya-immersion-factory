import json
import tempfile
import threading
import unittest
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request as UrlRequest, urlopen
from wsgiref.simple_server import WSGIServer, make_server
from socketserver import ThreadingMixIn

from fabrya_factory.api import FactoryApi, wsgi_app
from fabrya_factory.config import Settings
from fabrya_factory.orchestrator import GenerationOrchestrator
from fabrya_factory.store import Store


class LocalThreadedServer(ThreadingMixIn, WSGIServer):
    daemon_threads = True
    allow_reuse_address = True


class HttpSmokeTests(unittest.TestCase):
    def test_real_loopback_http_flow(self):
        with tempfile.TemporaryDirectory() as directory:
            settings = Settings(Path(directory), "loopback-bootstrap", generation_budget_micros=0)
            store = Store(Path(directory) / "factory.sqlite3")
            api = FactoryApi(settings, store)
            server = make_server("127.0.0.1", 0, wsgi_app(api), server_class=LocalThreadedServer)
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            base = f"http://127.0.0.1:{server.server_port}"
            try:
                with urlopen(base + "/healthz", timeout=2) as response:
                    self.assertEqual(json.loads(response.read())["provider_calls_enabled"], False)

                create = UrlRequest(base + "/v1/projects", data=json.dumps({"name": "Local test"}).encode(), method="POST", headers={"Authorization": "Bearer loopback-bootstrap", "Content-Type": "application/json"})
                with urlopen(create, timeout=2) as response:
                    project = json.loads(response.read())
                    self.assertEqual(response.status, 201)

                submit = UrlRequest(base + f"/v1/projects/{project['project_id']}/generations", data=json.dumps({"brief": "Fictitious garage"}).encode(), method="POST", headers={"Authorization": "Bearer " + project["project_token"], "Content-Type": "application/json", "Idempotency-Key": "loopback-job-001"})
                with urlopen(submit, timeout=2) as response:
                    job = json.loads(response.read())
                    self.assertEqual(response.status, 202)

                self.assertTrue(GenerationOrchestrator(store).run_one())
                status_request = UrlRequest(base + job["status_url"], headers={"Authorization": "Bearer " + project["project_token"]})
                with urlopen(status_request, timeout=2) as response:
                    state = json.loads(response.read())
                    self.assertEqual(state["status"], "blocked")
                    self.assertEqual(state["error_code"], "OPENAI_PROVIDER_DISABLED")

                denied = UrlRequest(base + job["status_url"], headers={"Authorization": "Bearer wrong-project-token"})
                with self.assertRaises(HTTPError) as caught:
                    urlopen(denied, timeout=2)
                self.assertEqual(caught.exception.code, 404)
            finally:
                server.shutdown()
                server.server_close()
                thread.join(timeout=2)


if __name__ == "__main__":
    unittest.main()
