import unittest

from fabrya_factory.contracts import TOOL_CATALOG, require_text
from fabrya_factory.errors import ValidationError


class ContractTests(unittest.TestCase):
    def test_all_fifteen_tool_contracts_are_listed_once(self):
        self.assertEqual(len(TOOL_CATALOG), 15)
        self.assertEqual(len({tool.name for tool in TOOL_CATALOG}), 15)
        self.assertTrue(all(tool.input_type and tool.output_type for tool in TOOL_CATALOG))

    def test_brief_text_is_trimmed_and_bounded(self):
        self.assertEqual(require_text("  Garage premium  ", label="brief"), "Garage premium")
        with self.assertRaises(ValidationError):
            require_text("   ", label="brief")
        with self.assertRaises(ValidationError):
            require_text("x" * 21, label="brief", maximum=20)


if __name__ == "__main__":
    unittest.main()
