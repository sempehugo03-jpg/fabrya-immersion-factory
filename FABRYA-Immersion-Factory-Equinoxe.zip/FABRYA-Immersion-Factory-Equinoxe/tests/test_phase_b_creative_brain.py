from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

from fabrya_factory.creative_blueprint import BLUEPRINT_VERSION, assemble_blueprint, validate_model_decisions
from fabrya_factory.costs import CostSupervisor
from fabrya_factory.errors import ValidationError
from fabrya_factory.openai_provider import (
    CREATIVE_INSTRUCTIONS, OpenAICreativeProvider, build_response_payload, maximum_reservation_micros,
)
from fabrya_factory.orchestrator import GenerationOrchestrator
from fabrya_factory.security import new_project_token
from fabrya_factory.store import Store
from tests.creative_reference_fixtures import REFERENCE_BRIEFS, blueprint_fixture
from tests.support import TempStore


class CreativeBlueprintTests(unittest.TestCase):
    def test_published_json_schema_matches_runtime_contract(self):
        schema_path = Path(__file__).parents[1] / "docs" / "fabrya.creative-blueprint.v1.schema.json"
        published = json.loads(schema_path.read_text(encoding="utf-8"))
        from fabrya_factory.creative_blueprint import BLUEPRINT_JSON_SCHEMA
        for key, value in BLUEPRINT_JSON_SCHEMA.items():
            self.assertEqual(published[key], value)

    def test_three_reference_briefs_have_valid_distinct_justified_immersions(self):
        blueprints = {}
        for kind, brief in REFERENCE_BRIEFS.items():
            fixture = blueprint_fixture(kind)
            decisions = validate_model_decisions(fixture)
            wrapped = assemble_blueprint(decisions, {
                "generation_id": f"offline-fixture-{kind}", "generated_at": "2026-11-17T00:00:00+00:00",
                "model": "OFFLINE_FIXTURE_NOT_OPENAI", "sdk_version": "3.52.0", "provider": "offline_fixture", "response_id": "fixture",
                "request_id": "fixture", "brief_sha256": "a" * 64, "prompt_version": "fabrya.creative-director/v1",
                "input_tokens": 0, "output_tokens": 0, "estimated_cost_micros_usd": 0,
            })
            decisions = wrapped["decisions"]
            blueprints[kind] = decisions
            self.assertTrue(brief)
            self.assertEqual(wrapped["contract_version"], BLUEPRINT_VERSION)
            self.assertTrue(decisions["art_direction"]["business_fit_rationale"].strip())
            self.assertTrue(decisions["immersion"]["signature_moment"].strip())
            self.assertTrue(all(x["rationale"].strip() for x in decisions["immersion"]["interactions"]))
            self.assertTrue(all(x["reduced_motion_behavior"].strip() for x in decisions["immersion"]["interactions"]))
            self.assertFalse(decisions["visual_plan"]["external_stock_media_allowed"])
            self.assertTrue(all(x["generation_prompt"].strip() for x in decisions["visual_plan"]["assets"]))
            self.assertIn("facts_from_brief", decisions["analysis"]["business_profile"])
            self.assertIn("assumptions", decisions["analysis"]["business_profile"])
            self.assertIn("missing_information", decisions["analysis"]["business_profile"])
            self.assertEqual(wrapped["generation"]["provider"], "offline_fixture")
        titles = {b["art_direction"]["concept_title"] for b in blueprints.values()}
        moments = {b["immersion"]["signature_moment"] for b in blueprints.values()}
        self.assertEqual(len(titles), 3)
        self.assertEqual(len(moments), 3)

    def test_schema_rejects_unknown_fields_and_fake_stock_media_permission(self):
        value = blueprint_fixture("garage")
        value["invented"] = "not allowed"
        with self.assertRaises(ValidationError):
            validate_model_decisions(value)
        value = blueprint_fixture("garage")
        value["visual_plan"]["external_stock_media_allowed"] = True
        with self.assertRaises(ValidationError):
            validate_model_decisions(value)

    def test_response_payload_is_strict_async_structured_output_without_tools(self):
        payload = build_response_payload("gpt-6.1-sol", REFERENCE_BRIEFS["garage"], "fif-test-request")
        self.assertEqual(payload["text"]["format"]["type"], "json_schema")
        self.assertTrue(payload["text"]["format"]["strict"])
        self.assertFalse(payload["store"])
        self.assertEqual(payload["tools"], [])
        self.assertIn("untrusted client data", payload["instructions"])
        self.assertEqual(payload["extra_headers"]["X-Client-Request-Id"], "fif-test-request")
        # 16k input / 5k output at the current Standard rates exceeds the requested $0.05 cap.
        self.assertEqual(maximum_reservation_micros("gpt-6.1-sol"), 82_000)
        self.assertGreater(maximum_reservation_micros("gpt-6.1-sol"), 50_000)
        self.assertEqual(maximum_reservation_micros("gpt-6-luna"), 4_100)


class _FakeResponses:
    def __init__(self, text: str):
        self.text = text
        self.calls: list[dict[str, object]] = []

    async def create(self, **kwargs):
        self.calls.append(kwargs)
        return SimpleNamespace(
            output_text=self.text, id="resp_offline_fixture", model="gpt-6.1-sol",
            _request_id="req_offline_fixture", usage=SimpleNamespace(input_tokens=1200, output_tokens=900),
        )


class _FakeClient:
    def __init__(self, text: str):
        self.responses = _FakeResponses(text)


class CreativeJobIntegrationTests(TempStore, unittest.TestCase):
    def test_job_uses_async_provider_adapter_and_persists_blueprint_and_cost(self):
        project = self.store.create_project("Offline fake only", new_project_token(), budget_micros=100_000)
        job, _ = self.store.create_job(str(project["id"]), REFERENCE_BRIEFS["garage"], "phaseb-job-001")
        client = _FakeClient(json.dumps(blueprint_fixture("garage"), ensure_ascii=False))
        provider = OpenAICreativeProvider(client, "gpt-6.1-sol", provider_name="offline_fixture")
        runner = GenerationOrchestrator(self.store, provider_enabled=True, provider=provider,
            generation_budget_micros=100_000, max_call_micros=100_000)
        self.assertTrue(runner.run_one())
        saved_job = self.store.get_job(str(project["id"]), str(job["id"]))
        saved = self.store.get_creative_blueprint(str(project["id"]), str(job["id"]))
        self.assertEqual(saved_job["status"], "completed")
        self.assertEqual(saved["contract_version"], BLUEPRINT_VERSION)
        self.assertEqual(saved["blueprint"]["generation"]["provider"], "offline_fixture")
        self.assertEqual(saved["blueprint"]["generation"]["response_id"], "resp_offline_fixture")
        self.assertEqual(saved["blueprint"]["generation"]["sdk_version"], "3.52.0")
        self.assertEqual(saved["blueprint"]["generation"]["input_tokens"], 1200)
        self.assertEqual(saved["blueprint"]["generation"]["prompt_version"], "fabrya.creative-director/v1")
        self.assertEqual(len(client.responses.calls), 1)
        self.assertEqual(client.responses.calls[0]["model"], "gpt-6.1-sol")
        checkpoints = self.store.list_checkpoints(str(job["id"]))
        self.assertTrue(any(x["stage"] == "creative_blueprint_validated" for x in checkpoints))
        self.assertTrue(any(x["payload"].get("site_code_generated") is False for x in checkpoints))
        with self.store._connect() as db:
            charge = db.execute("SELECT actual_micros,estimated_micros FROM cost_events WHERE job_id=?", (job["id"],)).fetchone()
        self.assertEqual(charge["actual_micros"], 0)
        self.assertEqual(charge["estimated_micros"], saved["blueprint"]["generation"]["estimated_cost_micros_usd"])
        self.assertEqual(self.store.budget_usage(str(project["id"]), str(job["id"])), charge["estimated_micros"])
        first_generation_id = saved["generation_id"]
        next_job, _ = self.store.create_job(str(project["id"]), REFERENCE_BRIEFS["podology"], "phaseb-job-001b")
        self.assertTrue(runner.run_one())
        history = self.store.list_creative_blueprints(str(project["id"]))
        self.assertEqual(len(history), 2)
        self.assertEqual(history[0]["version_number"], 2)
        self.assertEqual(history[0]["job_id"], next_job["id"])
        self.assertEqual(history[0]["parent_generation_id"], first_generation_id)
        self.assertEqual(history[1]["version_number"], 1)
        self.assertEqual(len(client.responses.calls), 2)

    def test_zero_max_call_cap_fails_closed_without_provider_request(self):
        project = self.store.create_project("Zero cap", new_project_token(), budget_micros=50_000)
        job, _ = self.store.create_job(str(project["id"]), "Short brief", "phaseb-job-002")
        client = _FakeClient(json.dumps(blueprint_fixture("garage"), ensure_ascii=False))
        runner = GenerationOrchestrator(self.store, provider_enabled=True,
            provider=OpenAICreativeProvider(client, "gpt-6.1-sol", provider_name="offline_fixture"),
            generation_budget_micros=50_000, max_call_micros=0)
        runner.run_one()
        state = self.store.get_job(str(project["id"]), str(job["id"]))
        self.assertEqual(state["status"], "blocked")
        self.assertEqual(state["error_code"], "OPENAI_BUDGET_NOT_CONFIGURED")
        self.assertEqual(client.responses.calls, [])

    def test_fifty_cent_cap_blocks_default_model_before_provider_request(self):
        project = self.store.create_project("Requested $0.05 cap", new_project_token(), budget_micros=50_000)
        job, _ = self.store.create_job(str(project["id"]), REFERENCE_BRIEFS["garage"], "phaseb-cap-005")
        client = _FakeClient(json.dumps(blueprint_fixture("garage"), ensure_ascii=False))
        runner = GenerationOrchestrator(self.store, provider_enabled=True,
            provider=OpenAICreativeProvider(client, "gpt-6.1-sol", provider_name="offline_fixture"),
            generation_budget_micros=50_000, max_call_micros=50_000)
        self.assertTrue(runner.run_one())
        state = self.store.get_job(str(project["id"]), str(job["id"]))
        self.assertEqual(state["status"], "blocked")
        self.assertEqual(state["error_code"], "OPENAI_BUDGET_EXCEEDED_OR_UNAUTHORIZED")
        self.assertEqual(client.responses.calls, [])

    def test_ambiguous_provider_attempt_is_not_retried_after_restart(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        store = Store(Path(temp.name) / "factory.sqlite3")
        project = store.create_project("Interrupted", new_project_token(), budget_micros=40_000)
        job, _ = store.create_job(str(project["id"]), "Brief", "phaseb-job-003")
        store.claim_next_job()
        store.add_cost_event(str(project["id"]), str(job["id"]), "openai", "creative_blueprint_v1", 30_000)
        self.assertTrue(store.begin_provider_call(str(job["id"]), "stable-call-key", "gpt-6.1-sol", "client-request-id"))
        requeued, failed = store.recover_interrupted_jobs()
        self.assertEqual((requeued, failed), (0, 1))
        self.assertEqual(store.get_job(str(project["id"]), str(job["id"]))["error_code"], "OPENAI_OUTCOME_UNKNOWN")
        self.assertFalse(store.begin_provider_call(str(job["id"]), "stable-call-key", "gpt-6.1-sol", "client-request-id"))
