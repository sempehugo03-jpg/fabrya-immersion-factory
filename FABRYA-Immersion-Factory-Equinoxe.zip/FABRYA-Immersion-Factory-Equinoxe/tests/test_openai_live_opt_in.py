"""One billable request, guarded by an explicit operator opt-in; not run in Phase B."""

from __future__ import annotations

import os
import tempfile
import unittest
from pathlib import Path

from fabrya_factory.openai_provider import OpenAICreativeProvider, maximum_reservation_micros
from fabrya_factory.orchestrator import GenerationOrchestrator
from fabrya_factory.security import new_project_token
from fabrya_factory.store import Store
from tests.creative_reference_fixtures import REFERENCE_BRIEFS


@unittest.skipUnless(os.environ.get("FACTORY_LIVE_OPENAI_TEST") == "AUTHORIZED", "requires separate founder authorization; performs one billable API call")
class OpenAILiveOptInTests(unittest.TestCase):
    def test_one_real_creative_blueprint_request(self):
        if os.environ.get("FACTORY_OPENAI_PLATFORM_LIMIT_VERIFIED") != "YES":
            self.fail("Verify the selected OpenAI project's hard spend limit and current usage first")
        if os.environ.get("FACTORY_OPENAI_ENABLED", "").lower() != "true":
            self.fail("Set FACTORY_OPENAI_ENABLED=true only after authorizing the first live test")
        if not os.environ.get("OPENAI_API_KEY", "").strip():
            self.fail("An existing server-side OPENAI_API_KEY is required; this test never creates one")
        model = os.environ.get("FACTORY_OPENAI_MODEL", "gpt-6.1-sol")
        call_cap = int(round(float(os.environ.get("FACTORY_OPENAI_MAX_CALL_USD", "0")) * 1_000_000))
        job_budget = int(round(float(os.environ.get("FACTORY_GENERATION_BUDGET_USD", "0")) * 1_000_000))
        required = maximum_reservation_micros(model)
        if call_cap < required or job_budget < required:
            self.fail(f"Configured call and generation budgets must each be at least ${required / 1_000_000:.3f}")

        provider = OpenAICreativeProvider.from_env(model=model,
            timeout_seconds=float(os.environ.get("FACTORY_OPENAI_TIMEOUT_SECONDS", "60")))
        if provider is None:
            self.fail("OpenAI adapter could not be initialized")
        with tempfile.TemporaryDirectory() as temp:
            store = Store(Path(temp) / "live-test.sqlite3")
            project = store.create_project("Explicit live API smoke test", new_project_token(), budget_micros=job_budget)
            job, _ = store.create_job(str(project["id"]), REFERENCE_BRIEFS["garage"], "live-once-garage-blueprint")
            runner = GenerationOrchestrator(store, provider_enabled=True, provider=provider,
                generation_budget_micros=job_budget, max_call_micros=call_cap)
            runner.run_one()
            final = store.get_job(str(project["id"]), str(job["id"]))
            self.assertEqual(final["status"], "completed", f"Live provider request failed with {final['error_code']}")
            blueprint = store.get_creative_blueprint(str(project["id"]), str(job["id"]))
            self.assertEqual(blueprint["blueprint"]["generation"]["provider"], "openai")
            self.assertGreater(blueprint["blueprint"]["generation"]["input_tokens"], 0)
            self.assertGreater(blueprint["blueprint"]["generation"]["output_tokens"], 0)


if __name__ == "__main__":
    unittest.main()
