import unittest

from fabrya_factory.costs import CostSupervisor
from fabrya_factory.errors import BudgetExceeded
from fabrya_factory.security import new_project_token
from tests.support import TempStore


class CostTests(TempStore, unittest.TestCase):
    def test_zero_default_budget_blocks_positive_reservation(self):
        project = self.store.create_project("Zero budget", new_project_token())
        job, _ = self.store.create_job(str(project["id"]), "No spend", "cost-0001")
        with self.assertRaises(BudgetExceeded):
            CostSupervisor(self.store).reserve(str(project["id"]), str(job["id"]), "openai", "image", 1)

    def test_reservation_and_settlement_are_accounted(self):
        project = self.store.create_project("Test budget", new_project_token(), budget_micros=100)
        job, _ = self.store.create_job(str(project["id"]), "Test only", "cost-0002")
        supervisor = CostSupervisor(self.store)
        reservation = supervisor.reserve(str(project["id"]), str(job["id"]), "fake-provider", "test-call", 60)
        self.assertEqual(reservation.remaining_micros, 40)
        supervisor.settle(reservation, 42)
        self.assertEqual(self.store.budget_usage(str(project["id"]), str(job["id"])), 42)

    def test_overrun_is_rejected(self):
        project = self.store.create_project("Test budget", new_project_token(), budget_micros=10)
        job, _ = self.store.create_job(str(project["id"]), "Test", "cost-0003")
        supervisor = CostSupervisor(self.store)
        reservation = supervisor.reserve(str(project["id"]), str(job["id"]), "fake-provider", "test-call", 10)
        with self.assertRaises(BudgetExceeded):
            supervisor.settle(reservation, 11)


if __name__ == "__main__":
    unittest.main()
