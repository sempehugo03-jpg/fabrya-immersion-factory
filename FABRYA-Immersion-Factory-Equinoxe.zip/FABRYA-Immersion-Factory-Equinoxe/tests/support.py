import tempfile
from pathlib import Path

from fabrya_factory.store import Store


class TempStore:
    def setUp(self):
        super().setUp()
        self.temp_dir = tempfile.TemporaryDirectory()
        self.store = Store(Path(self.temp_dir.name) / "factory.sqlite3")

    def tearDown(self):
        self.temp_dir.cleanup()
        super().tearDown()

