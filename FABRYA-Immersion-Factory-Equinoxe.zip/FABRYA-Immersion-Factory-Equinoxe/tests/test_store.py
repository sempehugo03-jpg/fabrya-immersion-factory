import tempfile
import unittest
from pathlib import Path

from fabrya_factory.errors import Conflict
from fabrya_factory.security import new_project_token
from fabrya_factory.store import Store


class StoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / "factory.sqlite3"
        self.store = Store(self.path)
        self.project = self.store.create_project("Équinoxe test", new_project_token())

    def tearDown(self):
        self.tmp.cleanup()

    def test_idempotent_generation_intake(self):
        first, replay = self.store.create_job(str(self.project["id"]), "Garage sportif", "request-0001")
        second, replay2 = self.store.create_job(str(self.project["id"]), "Garage sportif", "request-0001")
        self.assertFalse(replay)
        self.assertTrue(replay2)
        self.assertEqual(first["id"], second["id"])

    def test_idempotency_key_cannot_change_request(self):
        self.store.create_job(str(self.project["id"]), "Brief A", "request-0002")
        with self.assertRaises(Conflict):
            self.store.create_job(str(self.project["id"]), "Brief B", "request-0002")

    def test_invalid_transition_is_rejected(self):
        job, _ = self.store.create_job(str(self.project["id"]), "Garage", "request-0003")
        with self.assertRaises(Conflict):
            self.store.transition_job(str(job["id"]), "completed", "done")

    def test_checkpoints_survive_store_reopen(self):
        job, _ = self.store.create_job(str(self.project["id"]), "Garage", "request-0004")
        self.store.add_checkpoint(str(job["id"]), "saved", "running", {"external_calls": 0})
        reopened = Store(self.path)
        checkpoints = reopened.list_checkpoints(str(job["id"]))
        self.assertEqual(checkpoints[0]["stage"], "saved")
        self.assertEqual(checkpoints[0]["payload"]["external_calls"], 0)

    def test_version_numbers_are_project_scoped(self):
        v1 = self.store.create_version(str(self.project["id"]), {"hash": "abc"})
        v2 = self.store.create_version(str(self.project["id"]), {"hash": "def"}, parent_id=str(v1["id"]))
        self.assertEqual(v1["version_number"], 1)
        self.assertEqual(v2["version_number"], 2)


if __name__ == "__main__":
    unittest.main()
