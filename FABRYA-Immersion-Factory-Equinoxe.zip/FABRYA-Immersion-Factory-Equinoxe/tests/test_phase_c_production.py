from __future__ import annotations

import asyncio
import base64
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

from fabrya_factory.creative_blueprint import assemble_blueprint
from fabrya_factory.errors import NotReady
from fabrya_factory.production import (
    BuildSandbox, MediaPlanBuilder, OpenAIImageProvider, OriginalImageFactory,
    ProductionPipeline, site_plan_from_blueprint,
)
from fabrya_factory.security import new_project_token
from fabrya_factory.store import Store
from tests.creative_reference_fixtures import REFERENCE_BRIEFS, blueprint_fixture


def garage_blueprint() -> dict[str, object]:
    return assemble_blueprint(blueprint_fixture("garage"), {
        "generation_id": "offline-fixture-phase-c-test", "generated_at": "2026-11-17T00:00:00+00:00",
        "model": "OFFLINE_FIXTURE_NOT_OPENAI", "sdk_version": "not-used", "provider": "offline_fixture",
        "response_id": "fixture-no-response", "request_id": "fixture-no-request", "brief_sha256": "0" * 64,
        "prompt_version": "fabrya.creative-director/v1", "input_tokens": 0, "output_tokens": 0,
        "estimated_cost_micros_usd": 0,
    })


class _FakeImageService:
    def __init__(self) -> None:
        self.calls: list[dict[str, object]] = []

    async def generate(self, **kwargs):
        self.calls.append(kwargs)
        return SimpleNamespace(data=[SimpleNamespace(b64_json=base64.b64encode(b"fixture-png").decode())],
                               _request_id="mock-request", usage=SimpleNamespace(input_tokens=12, output_tokens=80))


class ProductionPlumbingTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.store = Store(self.root / "factory.sqlite3")
        self.project = self.store.create_project("Fixture-only", new_project_token(), budget_micros=0)
        self.job, _ = self.store.create_job(str(self.project["id"]), REFERENCE_BRIEFS["garage"], "phase-c-test-job-1")
        self.blueprint = garage_blueprint()

    async def test_media_planner_creates_desktop_mobile_prompts_without_external_stock(self):
        plan = MediaPlanBuilder.from_blueprint(self.blueprint)
        self.assertFalse(plan.external_stock_media_allowed)
        self.assertEqual(plan.contract_version, "fabrya.media-plan/v1")
        self.assertIn("paysage", plan.assets[0].desktop_prompt.lower())
        self.assertIn("portrait", plan.assets[0].mobile_prompt.lower())
        self.assertIn("No stock imagery", plan.assets[0].desktop_prompt)
        site_plan = site_plan_from_blueprint(self.blueprint)
        self.assertEqual(site_plan["form_mode"], "local_fixture_no_external_submission")
        self.assertEqual(site_plan["provenance"], "offline_fixture")

    async def test_image_adapter_payload_is_mocked_and_budget_zero_never_calls_provider(self):
        fake = _FakeImageService()
        adapter = OpenAIImageProvider(SimpleNamespace(images=fake), enabled=True)
        factory = OriginalImageFactory(self.store, self.root, adapter, enabled=False,
                                       generation_budget_micros=0, per_image_reservation_micros=0)
        plan = factory.plan(self.blueprint)
        with self.assertRaises(NotReady):
            await factory.generate_variant(str(self.project["id"]), str(self.job["id"]), plan.assets[0], "desktop")
        self.assertEqual(fake.calls, [])

        actual = await adapter.generate("unit-test prompt", size="1536x1024")
        self.assertEqual(actual.data, b"fixture-png")
        # Adapter argument forwarding is a fake service contract test; it is not an API call.
        self.assertEqual(fake.calls, [{"model": "gpt-image-2.6-sunburst", "prompt": "unit-test prompt",
                                      "size": "1536x1024", "quality": "high", "output_format": "png", "n": 1}])

    async def test_fixture_pipeline_persists_assets_checkpoints_version_and_sandbox_proof(self):
        pipeline = ProductionPipeline(self.store)
        report = await pipeline.run_fixture(str(self.project["id"]), str(self.job["id"]), self.blueprint,
                                            self.root / "artifact", browser_qa=False)
        self.assertTrue(report["fixture_only"])
        self.assertEqual(report["steps"]["sandbox"], "passed")
        self.assertTrue(report["build_report"]["network_denied"])
        self.assertEqual(report["steps"]["browser_qa"], "not_executed")
        self.assertEqual(report["job_status"], "blocked")
        self.assertEqual(report["media_count"], 2)
        media = self.store.list_factory_media(str(self.project["id"]), str(self.job["id"]))
        self.assertEqual({x["source_kind"] for x in media}, {"fixture"})
        self.assertTrue(all(x["provenance"]["fixture"] for x in media))
        self.assertEqual(len(self.store.list_versions(str(self.project["id"]))), 1)
        ordered_checkpoints = self.store.list_checkpoints(str(self.job["id"]))
        stages = {x["stage"] for x in ordered_checkpoints}
        self.assertTrue({"fixture_blueprint_loaded", "media_plan_created", "immersion_runtime_compiled",
                         "site_plan_created", "website_source_built", "sandbox_build", "browser_qa",
                         "version_created"}.issubset(stages))
        ordered_stages = [x["stage"] for x in ordered_checkpoints]
        self.assertLess(ordered_stages.index("fixture_media_saved"), ordered_stages.index("site_plan_created"))
        self.assertLess(ordered_stages.index("site_plan_created"), ordered_stages.index("immersion_runtime_compiled"))
        self.assertLess(ordered_stages.index("immersion_runtime_compiled"), ordered_stages.index("website_source_built"))
        self.assertTrue((self.root / "artifact" / "site" / "index.html").exists())
        self.assertTrue((self.root / "artifact" / "phase-c-report.json").exists())

    async def test_real_worker_pipeline_stops_before_image_call_when_provider_is_disabled(self):
        blueprint = json.loads(json.dumps(self.blueprint))
        blueprint["generation"]["provider"] = "openai"
        blueprint["generation"]["generation_id"] = "openai-blueprint-no-image-call"
        self.store.claim_job(str(self.job["id"]))
        image = OriginalImageFactory(self.store, self.root / "media", enabled=False,
                                     generation_budget_micros=0, per_image_reservation_micros=0)
        pipeline = ProductionPipeline(self.store, image_factory=image, artifact_root=self.root / "sites")
        result = await pipeline.run_generated(str(self.project["id"]), str(self.job["id"]), blueprint)
        self.assertEqual(result["job_status"], "blocked")
        self.assertEqual(result["stage"], "visual_assets")
        self.assertEqual(self.store.get_job(str(self.project["id"]), str(self.job["id"]))["error_code"],
                         "IMAGE_PROVIDER_DISABLED_OR_BUDGET_ZERO")
        self.assertEqual(self.store.list_factory_media(str(self.project["id"]), str(self.job["id"])), [])
        stages = {item["stage"] for item in self.store.list_checkpoints(str(self.job["id"]))}
        self.assertIn("media_plan_created", stages)
        self.assertNotIn("visual_asset_saved", stages)
        self.assertFalse((self.root / "sites" / str(self.project["id"]) / str(self.job["id"]) / "site").exists())

    async def test_fixture_media_operation_is_idempotent_and_not_client_media(self):
        plan = MediaPlanBuilder.from_blueprint(self.blueprint)
        factory = OriginalImageFactory(self.store, self.root)
        first = factory.fixture_asset(str(self.project["id"]), str(self.job["id"]), plan.assets[0], "desktop")
        second = factory.fixture_asset(str(self.project["id"]), str(self.job["id"]), plan.assets[0], "desktop")
        self.assertEqual(first["id"], second["id"])
        self.assertEqual(first["source_kind"], "fixture")
        self.assertEqual(first["rights_status"], "fixture_not_for_client_use")
        self.assertIn("FIXTURE", first["storage_key"])


class SandboxIsolationTests(unittest.TestCase):
    def test_real_build_sandbox_checks_javascript_and_denies_network_syscalls(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "index.html").write_text('<!doctype html><html lang="fr"><body>Fixture</body></html>', encoding="utf-8")
            (root / "site.js").write_text('console.log("fixture only");', encoding="utf-8")
            report = BuildSandbox().build(root)
        self.assertEqual(report.status, "passed", report.stderr)
        self.assertTrue(report.network_denied)


if __name__ == "__main__":
    unittest.main()
