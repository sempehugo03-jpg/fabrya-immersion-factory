import unittest

from fabrya_factory.errors import NotFound
from fabrya_factory.security import new_project_token, token_digest, token_matches
from fabrya_factory.store import Store
from tests.support import TempStore


class SecurityTests(TempStore, unittest.TestCase):
    def test_project_token_is_stored_as_digest(self):
        token = new_project_token()
        project = self.store.create_project("Garage test", token)
        self.assertTrue(self.store.project_authorized(str(project["id"]), token))
        self.assertFalse(self.store.project_authorized(str(project["id"]), token + "wrong"))
        self.assertEqual(len(token_digest(token)), 64)

    def test_unknown_project_is_not_authorized(self):
        self.assertFalse(self.store.project_authorized("prj_missing123", "random"))


if __name__ == "__main__":
    unittest.main()
