import json
import tempfile
import unittest
from pathlib import Path

from fabrya_factory.api import FactoryApi, Request
from fabrya_factory.config import Settings
from fabrya_factory.orchestrator import GenerationOrchestrator
from fabrya_factory.store import Store


class ApiTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.settings = Settings(Path(self.tmp.name), "bootstrap-secret", generation_budget_micros=0)
        self.store = Store(Path(self.tmp.name) / "factory.sqlite3")
        self.api = FactoryApi(self.settings, self.store)

    def tearDown(self):
        self.tmp.cleanup()

    def request(self, method, path, *, token=None, body=None, extra_headers=None):
        headers = {"content-type": "application/json"}
        if token:
            headers["authorization"] = "Bearer " + token
        if extra_headers:
            headers.update(extra_headers)
        raw = json.dumps(body).encode() if body is not None else b""
        return self.api.handle(Request(method, path, headers, raw))

    def create_project(self, name="Test project"):
        response = self.request("POST", "/v1/projects", token="bootstrap-secret", body={"name": name})
        self.assertEqual(response.status, 201)
        return response.body

    def test_project_creation_and_generation_are_scoped(self):
        project = self.create_project()
        pid, token = project["project_id"], project["project_token"]
        submitted = self.request("POST", f"/v1/projects/{pid}/generations", token=token, body={"brief": "Premium garage"}, extra_headers={"idempotency-key": "generation-0001"})
        self.assertEqual(submitted.status, 202)
        self.assertFalse(submitted.body["idempotent_replay"])
        replay = self.request("POST", f"/v1/projects/{pid}/generations", token=token, body={"brief": "Premium garage"}, extra_headers={"idempotency-key": "generation-0001"})
        self.assertTrue(replay.body["idempotent_replay"])
        other = self.request("GET", f"/v1/projects/{pid}/generations/{submitted.body['job_id']}", token="wrong-token")
        self.assertEqual(other.status, 404)

    def test_bootstrap_and_preview_fail_closed(self):
        denied = self.request("POST", "/v1/projects", token="wrong", body={"name": "No"})
        self.assertEqual(denied.status, 401)
        project = self.create_project()
        response = self.request("POST", f"/v1/projects/{project['project_id']}/previews", token=project["project_token"], body={"version_id": "ver_missing123"})
        self.assertEqual(response.status, 503)
        self.assertIn("not implemented", response.body["error"]["message"])

    def test_tool_catalog_reports_real_implementation_boundaries(self):
        response = self.request("GET", "/v1/tools")
        self.assertEqual(response.status, 200)
        self.assertEqual(len(response.body["tools"]), 15)
        statuses = {tool["name"]: tool["status"] for tool in response.body["tools"]}
        self.assertEqual(statuses["sandbox_builder"], "implemented")
        self.assertEqual(statuses["visual_generator"], "implemented_disabled")
        self.assertEqual(statuses["browser_inspector"], "not_verified")
        self.assertEqual(statuses["code_generator"], "fixture_only")
        self.assertEqual(statuses["preview_publisher"], "interface_only")

    def test_job_result_reports_blocker_not_fake_site(self):
        project = self.create_project()
        pid, token = project["project_id"], project["project_token"]
        submitted = self.request("POST", f"/v1/projects/{pid}/generations", token=token, body={"brief": "Garage"}, extra_headers={"idempotency-key": "generation-0002"})
        GenerationOrchestrator(self.store).run_one()
        result = self.request("GET", f"/v1/projects/{pid}/generations/{submitted.body['job_id']}/result", token=token)
        self.assertEqual(result.status, 409)
        self.assertEqual(result.body["error"]["code"], "OPENAI_PROVIDER_DISABLED")


if __name__ == "__main__":
    unittest.main()
