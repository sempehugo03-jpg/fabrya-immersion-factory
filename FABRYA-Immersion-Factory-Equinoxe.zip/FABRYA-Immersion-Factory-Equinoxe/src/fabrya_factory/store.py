from __future__ import annotations

import json
import sqlite3
import threading
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator

from .errors import Conflict, NotFound, ValidationError
from .security import token_digest, token_matches

STATUSES = {"queued", "running", "blocked", "failed", "completed", "cancelled"}
TRANSITIONS = {
    "queued": {"running", "cancelled", "blocked"},
    "running": {"blocked", "failed", "completed", "cancelled"},
    "blocked": {"queued", "cancelled"},
    "failed": {"queued", "cancelled"},
    "completed": set(),
    "cancelled": set(),
}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex}"


class Store:
    """SQLite-backed Phase A store; each method uses a short-lived connection."""

    def __init__(self, database_path: Path) -> None:
        self.database_path = database_path
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.database_path, timeout=5, isolation_level=None)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        connection.execute("PRAGMA busy_timeout = 5000")
        return connection

    @contextmanager
    def _transaction(self) -> Iterator[sqlite3.Connection]:
        with self._lock:
            db = self._connect()
            try:
                db.execute("BEGIN IMMEDIATE")
                yield db
                db.execute("COMMIT")
            except Exception:
                db.execute("ROLLBACK")
                raise
            finally:
                db.close()

    def _initialize(self) -> None:
        with self._connect() as db:
            db.execute("PRAGMA journal_mode = WAL")
            db.executescript(
                """
                CREATE TABLE IF NOT EXISTS projects (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    token_hash TEXT NOT NULL,
                    budget_micros INTEGER NOT NULL DEFAULT 0 CHECK (budget_micros >= 0),
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS jobs (
                    id TEXT PRIMARY KEY,
                    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
                    idempotency_key TEXT NOT NULL,
                    brief TEXT NOT NULL,
                    status TEXT NOT NULL CHECK (status IN ('queued','running','blocked','failed','completed','cancelled')),
                    stage TEXT NOT NULL,
                    error_code TEXT,
                    result_json TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    UNIQUE(project_id, idempotency_key)
                );
                CREATE INDEX IF NOT EXISTS jobs_project_created ON jobs(project_id, created_at DESC);
                CREATE TABLE IF NOT EXISTS checkpoints (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    job_id TEXT NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
                    stage TEXT NOT NULL,
                    status TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS versions (
                    id TEXT PRIMARY KEY,
                    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
                    version_number INTEGER NOT NULL,
                    parent_id TEXT,
                    manifest_json TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    UNIQUE(project_id, version_number)
                );
                CREATE TABLE IF NOT EXISTS media (
                    id TEXT PRIMARY KEY,
                    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
                    job_id TEXT REFERENCES jobs(id) ON DELETE SET NULL,
                    storage_key TEXT NOT NULL,
                    source_kind TEXT NOT NULL CHECK (source_kind IN ('generated','client_authorized')),
                    rights_status TEXT NOT NULL,
                    cost_micros INTEGER NOT NULL DEFAULT 0 CHECK (cost_micros >= 0),
                    provenance_json TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS cost_events (
                    id TEXT PRIMARY KEY,
                    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
                    job_id TEXT NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
                    provider TEXT NOT NULL,
                    operation TEXT NOT NULL,
                    reserved_micros INTEGER NOT NULL DEFAULT 0 CHECK (reserved_micros >= 0),
                    actual_micros INTEGER NOT NULL DEFAULT 0 CHECK (actual_micros >= 0),
                    estimated_micros INTEGER NOT NULL DEFAULT 0 CHECK (estimated_micros >= 0),
                    state TEXT NOT NULL CHECK (state IN ('reserved','settled','released')),
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS provider_calls (
                    id TEXT PRIMARY KEY,
                    job_id TEXT NOT NULL UNIQUE REFERENCES jobs(id) ON DELETE CASCADE,
                    idempotency_key TEXT NOT NULL UNIQUE,
                    client_request_id TEXT NOT NULL,
                    state TEXT NOT NULL CHECK (state IN ('started','succeeded','failed','uncertain')),
                    model TEXT NOT NULL,
                    request_id TEXT,
                    response_id TEXT,
                    input_tokens INTEGER,
                    output_tokens INTEGER,
                    estimated_cost_micros INTEGER NOT NULL DEFAULT 0 CHECK (estimated_cost_micros >= 0),
                    error_code TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS creative_blueprints (
                    id TEXT PRIMARY KEY,
                    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
                    job_id TEXT NOT NULL UNIQUE REFERENCES jobs(id) ON DELETE CASCADE,
                    generation_id TEXT NOT NULL UNIQUE,
                    version_number INTEGER NOT NULL,
                    parent_generation_id TEXT,
                    contract_version TEXT NOT NULL,
                    brief_sha256 TEXT NOT NULL,
                    blueprint_json TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS factory_operations (
                    id TEXT PRIMARY KEY,
                    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
                    job_id TEXT NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
                    operation_key TEXT NOT NULL,
                    provider TEXT NOT NULL,
                    request_sha256 TEXT NOT NULL,
                    state TEXT NOT NULL CHECK (state IN ('started','succeeded','failed','uncertain','blocked')),
                    result_json TEXT,
                    error_code TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    UNIQUE(project_id, job_id, operation_key)
                );
                CREATE TABLE IF NOT EXISTS factory_media (
                    id TEXT PRIMARY KEY,
                    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
                    job_id TEXT NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
                    asset_id TEXT NOT NULL,
                    variant TEXT NOT NULL CHECK (variant IN ('desktop','mobile','original')),
                    source_kind TEXT NOT NULL CHECK (source_kind IN ('generated','client_authorized','fixture')),
                    rights_status TEXT NOT NULL,
                    mime_type TEXT NOT NULL,
                    storage_key TEXT NOT NULL,
                    sha256 TEXT NOT NULL,
                    provider TEXT,
                    model TEXT,
                    request_id TEXT,
                    estimated_cost_micros INTEGER NOT NULL DEFAULT 0 CHECK (estimated_cost_micros >= 0),
                    provenance_json TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    UNIQUE(project_id, job_id, asset_id, variant)
                );
                """
            )
            columns = {str(row["name"]) for row in db.execute("PRAGMA table_info(cost_events)").fetchall()}
            if "estimated_micros" not in columns:
                db.execute("ALTER TABLE cost_events ADD COLUMN estimated_micros INTEGER NOT NULL DEFAULT 0 CHECK (estimated_micros >= 0)")
            provider_columns = {str(row["name"]) for row in db.execute("PRAGMA table_info(provider_calls)").fetchall()}
            if "client_request_id" not in provider_columns:
                db.execute("ALTER TABLE provider_calls ADD COLUMN client_request_id TEXT NOT NULL DEFAULT ''")
            blueprint_columns = {str(row["name"]) for row in db.execute("PRAGMA table_info(creative_blueprints)").fetchall()}
            if "version_number" not in blueprint_columns:
                db.execute("ALTER TABLE creative_blueprints ADD COLUMN version_number INTEGER NOT NULL DEFAULT 1")
            if "parent_generation_id" not in blueprint_columns:
                db.execute("ALTER TABLE creative_blueprints ADD COLUMN parent_generation_id TEXT")
            db.execute("CREATE UNIQUE INDEX IF NOT EXISTS creative_blueprints_project_version ON creative_blueprints(project_id,version_number)")

    def create_project(self, name: str, token: str, budget_micros: int = 0) -> dict[str, object]:
        project_id, created = new_id("prj"), utc_now()
        with self._transaction() as db:
            db.execute(
                "INSERT INTO projects(id,name,token_hash,budget_micros,created_at) VALUES(?,?,?,?,?)",
                (project_id, name, token_digest(token), budget_micros, created),
            )
        return {"id": project_id, "name": name, "budget_micros": budget_micros, "created_at": created}

    def project_authorized(self, project_id: str, token: str) -> bool:
        with self._connect() as db:
            row = db.execute("SELECT token_hash FROM projects WHERE id=?", (project_id,)).fetchone()
        return bool(row and token_matches(token, row["token_hash"]))

    def get_project(self, project_id: str) -> dict[str, object]:
        with self._connect() as db:
            row = db.execute("SELECT id,name,budget_micros,created_at FROM projects WHERE id=?", (project_id,)).fetchone()
        if not row:
            raise NotFound("Project not found")
        return dict(row)

    def create_job(self, project_id: str, brief: str, idempotency_key: str) -> tuple[dict[str, object], bool]:
        with self._transaction() as db:
            prior = db.execute(
                "SELECT * FROM jobs WHERE project_id=? AND idempotency_key=?",
                (project_id, idempotency_key),
            ).fetchone()
            if prior:
                if prior["brief"] != brief:
                    raise Conflict("Idempotency key was already used with a different brief")
                return dict(prior), True
            job_id, now = new_id("job"), utc_now()
            db.execute(
                "INSERT INTO jobs(id,project_id,idempotency_key,brief,status,stage,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)",
                (job_id, project_id, idempotency_key, brief, "queued", "accepted", now, now),
            )
            job = db.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
        return dict(job), False

    def get_job(self, project_id: str, job_id: str) -> dict[str, object]:
        with self._connect() as db:
            row = db.execute("SELECT * FROM jobs WHERE project_id=? AND id=?", (project_id, job_id)).fetchone()
        if not row:
            raise NotFound("Generation job not found")
        item = dict(row)
        item["result"] = json.loads(item.pop("result_json")) if item["result_json"] else None
        item.pop("idempotency_key", None)
        item.pop("brief", None)
        return item

    def claim_next_job(self) -> dict[str, object] | None:
        with self._transaction() as db:
            row = db.execute("SELECT * FROM jobs WHERE status='queued' ORDER BY created_at LIMIT 1").fetchone()
            if not row:
                return None
            now = utc_now()
            db.execute("UPDATE jobs SET status='running',stage='orchestrator_started',updated_at=? WHERE id=? AND status='queued'", (now, row["id"]))
            updated = db.execute("SELECT * FROM jobs WHERE id=?", (row["id"],)).fetchone()
            job = dict(updated)
        self.add_checkpoint(job["id"], "orchestrator_started", "running", {"provider_call": False})
        return job

    def claim_job(self, job_id: str) -> dict[str, object]:
        """Claim one previously queued job without consuming another worker's queue item."""
        with self._transaction() as db:
            row = db.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
            if not row:
                raise NotFound("Generation job not found")
            if row["status"] != "queued":
                raise Conflict(f"Cannot claim job in state {row['status']}")
            now = utc_now()
            db.execute("UPDATE jobs SET status='running',stage='orchestrator_started',updated_at=? WHERE id=? AND status='queued'", (now, job_id))
            updated = db.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
            job = dict(updated)
        self.add_checkpoint(job_id, "orchestrator_started", "running", {"provider_call": False})
        return job

    def transition_job(self, job_id: str, status: str, stage: str, *, error_code: str | None = None, result: dict[str, object] | None = None) -> None:
        if status not in STATUSES:
            raise ValidationError("Unknown job status")
        with self._transaction() as db:
            row = db.execute("SELECT status FROM jobs WHERE id=?", (job_id,)).fetchone()
            if not row:
                raise NotFound("Generation job not found")
            if status not in TRANSITIONS[row["status"]]:
                raise Conflict(f"Invalid job transition: {row['status']} -> {status}")
            db.execute(
                "UPDATE jobs SET status=?,stage=?,error_code=?,result_json=?,updated_at=? WHERE id=?",
                (status, stage, error_code, json.dumps(result, separators=(",", ":")) if result is not None else None, utc_now(), job_id),
            )
        self.add_checkpoint(job_id, stage, status, {"error_code": error_code} if error_code else {})

    def add_checkpoint(self, job_id: str, stage: str, status: str, payload: dict[str, object]) -> None:
        with self._transaction() as db:
            db.execute(
                "INSERT INTO checkpoints(job_id,stage,status,payload_json,created_at) VALUES(?,?,?,?,?)",
                (job_id, stage, status, json.dumps(payload, separators=(",", ":")), utc_now()),
            )

    def list_checkpoints(self, job_id: str) -> list[dict[str, object]]:
        with self._connect() as db:
            rows = db.execute("SELECT stage,status,payload_json,created_at FROM checkpoints WHERE job_id=? ORDER BY id", (job_id,)).fetchall()
        return [{"stage": r["stage"], "status": r["status"], "payload": json.loads(r["payload_json"]), "created_at": r["created_at"]} for r in rows]

    def begin_provider_call(self, job_id: str, idempotency_key: str, model: str, client_request_id: str) -> bool:
        """Durably record a single outbound attempt before making the network request."""
        with self._transaction() as db:
            prior = db.execute("SELECT id FROM provider_calls WHERE job_id=? OR idempotency_key=?", (job_id, idempotency_key)).fetchone()
            if prior:
                return False
            db.execute(
                "INSERT INTO provider_calls(id,job_id,idempotency_key,client_request_id,state,model,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)",
                (new_id("call"), job_id, idempotency_key, client_request_id, "started", model, utc_now(), utc_now()),
            )
        return True

    def finish_provider_call(
        self, job_id: str, state: str, *, request_id: str | None = None, response_id: str | None = None,
        input_tokens: int | None = None, output_tokens: int | None = None, estimated_cost_micros: int = 0,
        error_code: str | None = None,
    ) -> None:
        if state not in {"succeeded", "failed", "uncertain"}:
            raise ValidationError("Invalid provider call state")
        with self._transaction() as db:
            row = db.execute("SELECT state FROM provider_calls WHERE job_id=?", (job_id,)).fetchone()
            if not row:
                raise NotFound("Provider call record not found")
            if row["state"] != "started":
                raise Conflict("Provider call is already finalized")
            db.execute(
                "UPDATE provider_calls SET state=?,request_id=?,response_id=?,input_tokens=?,output_tokens=?,estimated_cost_micros=?,error_code=?,updated_at=? WHERE job_id=?",
                (state, request_id, response_id, input_tokens, output_tokens, estimated_cost_micros, error_code, utc_now(), job_id),
            )

    def save_creative_blueprint(self, project_id: str, job_id: str, generation_id: str, contract_version: str, brief_sha256: str, blueprint: dict[str, object]) -> dict[str, object]:
        created = utc_now()
        blueprint_id = new_id("bp")
        with self._transaction() as db:
            previous = db.execute("SELECT generation_id,version_number FROM creative_blueprints WHERE project_id=? ORDER BY version_number DESC LIMIT 1", (project_id,)).fetchone()
            version_number = int(previous["version_number"]) + 1 if previous else 1
            parent_generation_id = str(previous["generation_id"]) if previous else None
            db.execute(
                "INSERT INTO creative_blueprints(id,project_id,job_id,generation_id,version_number,parent_generation_id,contract_version,brief_sha256,blueprint_json,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                (blueprint_id, project_id, job_id, generation_id, version_number, parent_generation_id, contract_version, brief_sha256, json.dumps(blueprint, ensure_ascii=False, separators=(",", ":")), created),
            )
        return {"blueprint_id": blueprint_id, "project_id": project_id, "job_id": job_id, "generation_id": generation_id, "version_number": version_number, "parent_generation_id": parent_generation_id, "contract_version": contract_version, "brief_sha256": brief_sha256, "blueprint": blueprint, "created_at": created}

    def get_creative_blueprint(self, project_id: str, job_id: str) -> dict[str, object]:
        with self._connect() as db:
            row = db.execute("SELECT * FROM creative_blueprints WHERE project_id=? AND job_id=?", (project_id, job_id)).fetchone()
        if not row:
            raise NotFound("Creative blueprint not found")
        item = dict(row)
        item["blueprint"] = json.loads(item.pop("blueprint_json"))
        return item

    def list_creative_blueprints(self, project_id: str) -> list[dict[str, object]]:
        with self._connect() as db:
            rows = db.execute("SELECT id,project_id,job_id,generation_id,version_number,parent_generation_id,contract_version,brief_sha256,created_at FROM creative_blueprints WHERE project_id=? ORDER BY version_number DESC", (project_id,)).fetchall()
        return [dict(row) for row in rows]

    def recover_interrupted_jobs(self) -> tuple[int, int]:
        """Requeue only jobs with no recorded provider attempt; fail uncertain attempts closed."""
        requeued: list[str] = []
        failed: list[str] = []
        with self._transaction() as db:
            rows = db.execute("SELECT id FROM jobs WHERE status='running'").fetchall()
            for row in rows:
                job_id = str(row["id"])
                call = db.execute("SELECT state FROM provider_calls WHERE job_id=?", (job_id,)).fetchone()
                if call and call["state"] == "started":
                    db.execute("UPDATE provider_calls SET state='uncertain',error_code='PROCESS_INTERRUPTED_OUTCOME_UNKNOWN',updated_at=? WHERE job_id=?", (utc_now(), job_id))
                    db.execute("UPDATE jobs SET status='failed',stage='provider_outcome_unknown',error_code='OPENAI_OUTCOME_UNKNOWN',updated_at=? WHERE id=?", (utc_now(), job_id))
                    failed.append(job_id)
                elif call:
                    db.execute("UPDATE jobs SET status='failed',stage='provider_attempt_already_used',error_code='OPENAI_ATTEMPT_ALREADY_USED',updated_at=? WHERE id=?", (utc_now(), job_id))
                    failed.append(job_id)
                else:
                    db.execute("UPDATE jobs SET status='queued',stage='recovered_before_provider_call',updated_at=? WHERE id=?", (utc_now(), job_id))
                    requeued.append(job_id)
        for job_id in failed:
            self.add_checkpoint(job_id, "provider_outcome_unknown", "failed", {"provider_call_retried": False, "reason": "An outbound attempt may already have been accepted; automatic retry is disabled."})
        for job_id in requeued:
            self.add_checkpoint(job_id, "recovered_before_provider_call", "queued", {"provider_call_retried": False})
        return len(requeued), len(failed)

    def create_version(self, project_id: str, manifest: dict[str, object], parent_id: str | None = None) -> dict[str, object]:
        with self._transaction() as db:
            row = db.execute("SELECT COALESCE(MAX(version_number),0)+1 AS n FROM versions WHERE project_id=?", (project_id,)).fetchone()
            number, version_id, now = row["n"], new_id("ver"), utc_now()
            db.execute("INSERT INTO versions(id,project_id,version_number,parent_id,manifest_json,created_at) VALUES(?,?,?,?,?,?)", (version_id, project_id, number, parent_id, json.dumps(manifest), now))
        return {"id": version_id, "project_id": project_id, "version_number": number, "parent_id": parent_id, "created_at": now}

    def list_versions(self, project_id: str) -> list[dict[str, object]]:
        with self._connect() as db:
            rows = db.execute("SELECT id,version_number,parent_id,created_at FROM versions WHERE project_id=? ORDER BY version_number DESC", (project_id,)).fetchall()
        return [dict(r) for r in rows]

    def begin_factory_operation(self, project_id: str, job_id: str, operation_key: str, provider: str, request_sha256: str) -> bool:
        """Persist an operation marker before work; an existing marker is never replayed."""
        with self._transaction() as db:
            row = db.execute(
                "SELECT request_sha256 FROM factory_operations WHERE project_id=? AND job_id=? AND operation_key=?",
                (project_id, job_id, operation_key),
            ).fetchone()
            if row:
                if row["request_sha256"] != request_sha256:
                    raise Conflict("Factory operation key was reused with a different request")
                return False
            db.execute(
                "INSERT INTO factory_operations(id,project_id,job_id,operation_key,provider,request_sha256,state,created_at,updated_at) VALUES(?,?,?,?,?,?, 'started',?,?)",
                (new_id("op"), project_id, job_id, operation_key, provider, request_sha256, utc_now(), utc_now()),
            )
        return True

    def finish_factory_operation(self, project_id: str, job_id: str, operation_key: str, state: str, *, result: dict[str, object] | None = None, error_code: str | None = None) -> None:
        if state not in {"succeeded", "failed", "uncertain", "blocked"}:
            raise ValidationError("Invalid factory operation state")
        with self._transaction() as db:
            row = db.execute(
                "SELECT state FROM factory_operations WHERE project_id=? AND job_id=? AND operation_key=?",
                (project_id, job_id, operation_key),
            ).fetchone()
            if not row:
                raise NotFound("Factory operation marker not found")
            if row["state"] != "started":
                raise Conflict("Factory operation is already finalized")
            db.execute(
                "UPDATE factory_operations SET state=?,result_json=?,error_code=?,updated_at=? WHERE project_id=? AND job_id=? AND operation_key=?",
                (state, json.dumps(result, ensure_ascii=False, separators=(",", ":")) if result is not None else None,
                 error_code, utc_now(), project_id, job_id, operation_key),
            )

    def get_factory_operation(self, project_id: str, job_id: str, operation_key: str) -> dict[str, object] | None:
        with self._connect() as db:
            row = db.execute(
                "SELECT * FROM factory_operations WHERE project_id=? AND job_id=? AND operation_key=?",
                (project_id, job_id, operation_key),
            ).fetchone()
        if not row:
            return None
        item = dict(row)
        item["result"] = json.loads(item.pop("result_json")) if item.get("result_json") else None
        return item

    def add_factory_media(self, project_id: str, job_id: str, asset_id: str, variant: str, *, source_kind: str, rights_status: str, mime_type: str, storage_key: str, sha256: str, provider: str | None, model: str | None, request_id: str | None, estimated_cost_micros: int, provenance: dict[str, object]) -> dict[str, object]:
        media_id, created = new_id("media"), utc_now()
        with self._transaction() as db:
            prior = db.execute(
                "SELECT * FROM factory_media WHERE project_id=? AND job_id=? AND asset_id=? AND variant=?",
                (project_id, job_id, asset_id, variant),
            ).fetchone()
            if prior:
                item = dict(prior)
                item["provenance"] = json.loads(item.pop("provenance_json"))
                return item
            db.execute(
                "INSERT INTO factory_media(id,project_id,job_id,asset_id,variant,source_kind,rights_status,mime_type,storage_key,sha256,provider,model,request_id,estimated_cost_micros,provenance_json,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (media_id, project_id, job_id, asset_id, variant, source_kind, rights_status, mime_type,
                 storage_key, sha256, provider, model, request_id, estimated_cost_micros,
                 json.dumps(provenance, ensure_ascii=False, separators=(",", ":")), created),
            )
        return {"id": media_id, "project_id": project_id, "job_id": job_id, "asset_id": asset_id, "variant": variant,
                "source_kind": source_kind, "rights_status": rights_status, "mime_type": mime_type,
                "storage_key": storage_key, "sha256": sha256, "provider": provider, "model": model,
                "request_id": request_id, "estimated_cost_micros": estimated_cost_micros,
                "provenance": provenance, "created_at": created}

    def list_factory_media(self, project_id: str, job_id: str) -> list[dict[str, object]]:
        with self._connect() as db:
            rows = db.execute(
                "SELECT * FROM factory_media WHERE project_id=? AND job_id=? ORDER BY asset_id,variant",
                (project_id, job_id),
            ).fetchall()
        result = []
        for row in rows:
            item = dict(row)
            item["provenance"] = json.loads(item.pop("provenance_json"))
            result.append(item)
        return result

    def add_cost_event(self, project_id: str, job_id: str, provider: str, operation: str, reserved_micros: int, state: str = "reserved") -> str:
        event_id = new_id("cost")
        with self._transaction() as db:
            db.execute("INSERT INTO cost_events(id,project_id,job_id,provider,operation,reserved_micros,state,created_at) VALUES(?,?,?,?,?,?,?,?)", (event_id, project_id, job_id, provider, operation, reserved_micros, state, utc_now()))
        return event_id

    def settle_cost_event(self, event_id: str, actual_micros: int = 0, *, estimated_micros: int = 0) -> None:
        with self._transaction() as db:
            row = db.execute("SELECT state,reserved_micros FROM cost_events WHERE id=?", (event_id,)).fetchone()
            if not row:
                raise NotFound("Cost reservation not found")
            if row["state"] != "reserved":
                raise Conflict("Cost reservation is not open")
            if actual_micros < 0 or estimated_micros < 0:
                raise ValidationError("Cost cannot be negative")
            db.execute("UPDATE cost_events SET actual_micros=?,estimated_micros=?,state='settled' WHERE id=?", (actual_micros, estimated_micros, event_id))

    def release_cost_event(self, event_id: str) -> None:
        with self._transaction() as db:
            row = db.execute("SELECT state FROM cost_events WHERE id=?", (event_id,)).fetchone()
            if not row:
                raise NotFound("Cost reservation not found")
            if row["state"] != "reserved":
                raise Conflict("Only an open cost reservation can be released")
            db.execute("UPDATE cost_events SET state='released' WHERE id=?", (event_id,))

    def budget_usage(self, project_id: str, job_id: str) -> int:
        with self._connect() as db:
            row = db.execute("SELECT COALESCE(SUM(CASE WHEN state='released' THEN 0 WHEN state='reserved' THEN reserved_micros ELSE MAX(actual_micros,estimated_micros) END),0) AS usage FROM cost_events WHERE project_id=? AND job_id=?", (project_id, job_id)).fetchone()
        return int(row["usage"])

    def project_budget(self, project_id: str) -> int:
        return int(self.get_project(project_id)["budget_micros"])

