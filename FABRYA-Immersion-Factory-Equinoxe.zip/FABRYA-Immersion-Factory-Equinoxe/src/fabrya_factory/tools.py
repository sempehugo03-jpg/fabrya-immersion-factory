from __future__ import annotations

from typing import Protocol, TypeVar

from .contracts import (
    ArtDirectorInput, ArtDirectorOutput, BriefAnalyzerInput, BriefAnalyzerOutput,
    BrowserInspectorInput, BrowserInspectorOutput, CodeGeneratorInput, CodeGeneratorOutput,
    CostSupervisorInput, CostSupervisorOutput, ImmersionArchitectInput, ImmersionArchitectOutput,
    MotionBuilderInput, MotionBuilderOutput, PreviewPublisherInput, PreviewPublisherOutput,
    RevisionEngineInput, RevisionEngineOutput, SandboxBuilderInput, SandboxBuilderOutput,
    ToolContext, VersionManagerInput, VersionManagerOutput, VisualConsistencyInput,
    VisualConsistencyOutput, VisualCriticInput, VisualCriticOutput, VisualGeneratorInput,
    VisualGeneratorOutput, WebsiteArchitectInput, WebsiteArchitectOutput,
)

I = TypeVar("I")
O = TypeVar("O")


class Tool(Protocol[I, O]):
    async def run(self, request: I, context: ToolContext) -> O: ...


class BriefAnalyzer(Tool[BriefAnalyzerInput, BriefAnalyzerOutput], Protocol): ...
class ArtDirector(Tool[ArtDirectorInput, ArtDirectorOutput], Protocol): ...
class ImmersionArchitect(Tool[ImmersionArchitectInput, ImmersionArchitectOutput], Protocol): ...
class VisualGenerator(Tool[VisualGeneratorInput, VisualGeneratorOutput], Protocol): ...
class VisualConsistencyController(Tool[VisualConsistencyInput, VisualConsistencyOutput], Protocol): ...
class MotionBuilder(Tool[MotionBuilderInput, MotionBuilderOutput], Protocol): ...
class WebsiteArchitect(Tool[WebsiteArchitectInput, WebsiteArchitectOutput], Protocol): ...
class CodeGenerator(Tool[CodeGeneratorInput, CodeGeneratorOutput], Protocol): ...
class SandboxBuilder(Tool[SandboxBuilderInput, SandboxBuilderOutput], Protocol): ...
class BrowserInspector(Tool[BrowserInspectorInput, BrowserInspectorOutput], Protocol): ...
class VisualCritic(Tool[VisualCriticInput, VisualCriticOutput], Protocol): ...
class RevisionEngine(Tool[RevisionEngineInput, RevisionEngineOutput], Protocol): ...
class VersionManager(Tool[VersionManagerInput, VersionManagerOutput], Protocol): ...
class PreviewPublisher(Tool[PreviewPublisherInput, PreviewPublisherOutput], Protocol): ...
class CostReliabilitySupervisor(Tool[CostSupervisorInput, CostSupervisorOutput], Protocol): ...


class ToolRegistry:
    """Explicit allowlist. Empty at Phase A; no dynamic tool execution."""

    def __init__(self) -> None:
        self._tools: dict[str, Tool[object, object]] = {}

    def register(self, name: str, tool: Tool[object, object]) -> None:
        if name in self._tools:
            raise ValueError(f"Tool already registered: {name}")
        self._tools[name] = tool

    def get(self, name: str) -> Tool[object, object] | None:
        return self._tools.get(name)

    def names(self) -> tuple[str, ...]:
        return tuple(sorted(self._tools))

