from __future__ import annotations

import hashlib
import uuid
from datetime import datetime, timezone
from typing import Any

from .creative_blueprint import BLUEPRINT_VERSION, assemble_blueprint
from .costs import CostSupervisor
from .errors import BudgetExceeded, Conflict
from .openai_provider import MAX_INPUT_TOKENS, OpenAICreativeProvider, maximum_reservation_micros
from .store import Store


class CreativeBrain:
    """One structured Responses API turn for analysis, art direction, immersion and media planning."""

    def __init__(self, store: Store, provider: OpenAICreativeProvider, *, call_cap_micros: int) -> None:
        self.store = store
        self.provider = provider
        self.call_cap_micros = call_cap_micros
        self.costs = CostSupervisor(store)

    async def create(self, project_id: str, job_id: str, brief: str) -> dict[str, Any]:
        model = self.provider.model
        reservation_micros = maximum_reservation_micros(model)
        if self.call_cap_micros <= 0 or reservation_micros > self.call_cap_micros:
            raise BudgetExceeded("OpenAI call cap is zero or below the model's reserved maximum")
        input_tokens_estimate = self.provider_input_estimate(brief)
        if input_tokens_estimate > MAX_INPUT_TOKENS:
            raise BudgetExceeded("Brief exceeds the configured maximum prompt size")
        generation_id = "gen_" + uuid.uuid4().hex
        brief_sha256 = hashlib.sha256(brief.encode("utf-8")).hexdigest()
        idempotency_key = "fabrya-creative-v1-" + hashlib.sha256(job_id.encode("utf-8")).hexdigest()
        request_id = "fif-" + hashlib.sha256((job_id + ":creative-blueprint-v1").encode("utf-8")).hexdigest()[:48]

        reservation = self.costs.reserve(project_id, job_id, "openai", "creative_blueprint_v1", reservation_micros)
        if not self.store.begin_provider_call(job_id, idempotency_key, model, request_id):
            self.costs.release(reservation)
            raise Conflict("This generation job already has a provider attempt; automatic retry is disabled")
        self.store.add_checkpoint(job_id, "openai_request_started", "running", {
            "generation_id": generation_id,
            "model": model,
            "client_request_id": request_id,
            "estimated_input_tokens": input_tokens_estimate,
            "reserved_cost_micros_usd": reservation_micros,
            "automatic_retry": False,
        })

        try:
            result = await self.provider.create_blueprint(brief, request_id)
        except Exception as exc:
            # The request may have reached the provider. Keep the reservation and never retry it.
            status = "uncertain" if type(exc).__name__ in {"APIConnectionError", "APITimeoutError", "TimeoutError"} else "failed"
            error_code = "OPENAI_OUTCOME_UNKNOWN" if status == "uncertain" else "OPENAI_REQUEST_FAILED"
            self.store.finish_provider_call(job_id, status, request_id=str(getattr(exc, "request_id", "") or request_id), error_code=error_code)
            raise

        try:
            self.costs.settle_estimate(reservation, result.estimated_cost_micros)
        except BudgetExceeded:
            self.store.finish_provider_call(job_id, "succeeded", request_id=result.request_id or request_id, response_id=result.response_id,
                input_tokens=result.input_tokens, output_tokens=result.output_tokens, estimated_cost_micros=result.estimated_cost_micros,
                error_code="OPENAI_COST_OVERRUN")
            raise
        self.store.finish_provider_call(job_id, "succeeded", request_id=result.request_id or request_id, response_id=result.response_id,
            input_tokens=result.input_tokens, output_tokens=result.output_tokens, estimated_cost_micros=result.estimated_cost_micros)

        generated_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
        blueprint = assemble_blueprint(result.decisions, {
            "generation_id": generation_id,
            "generated_at": generated_at,
            "model": result.model,
            "sdk_version": self.provider.sdk_version,
            "provider": result.provider,
            "response_id": result.response_id or "unknown",
            "request_id": result.request_id or request_id,
            "brief_sha256": brief_sha256,
            "prompt_version": "fabrya.creative-director/v1",
            "input_tokens": result.input_tokens,
            "output_tokens": result.output_tokens,
            "estimated_cost_micros_usd": result.estimated_cost_micros,
        })
        self.store.save_creative_blueprint(project_id, job_id, generation_id, BLUEPRINT_VERSION, brief_sha256, blueprint)
        self.store.add_checkpoint(job_id, "creative_blueprint_validated", "completed", {
            "generation_id": generation_id,
            "schema_version": BLUEPRINT_VERSION,
            "model": result.model,
            "provider_request_id": result.request_id or "",
            "provider_response_id": result.response_id,
            "input_tokens": result.input_tokens,
            "output_tokens": result.output_tokens,
            "estimated_cost_micros_usd": result.estimated_cost_micros,
            "external_media_generated": False,
            "site_code_generated": False,
        })
        return blueprint

    @staticmethod
    def provider_input_estimate(brief: str) -> int:
        from .openai_provider import estimate_input_tokens
        return estimate_input_tokens(brief)
