from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True, slots=True)
class Settings:
    data_dir: Path
    bootstrap_token: str
    host: str = "127.0.0.1"
    port: int = 8787
    generation_budget_micros: int = 0
    openai_enabled: bool = False
    openai_model: str = "gpt-6.1-sol"
    openai_max_call_micros: int = 0
    openai_timeout_seconds: float = 60.0
    image_generation_enabled: bool = False
    image_generation_budget_micros: int = 0
    image_generation_max_call_micros: int = 0

    @classmethod
    def from_env(cls) -> "Settings":
        port = int(os.environ.get("FACTORY_PORT", "8787"))
        budget_usd = os.environ.get("FACTORY_GENERATION_BUDGET_USD", "0")
        call_cap_usd = os.environ.get("FACTORY_OPENAI_MAX_CALL_USD", "0")
        image_budget_usd = os.environ.get("FACTORY_IMAGE_GENERATION_BUDGET_USD", "0")
        image_call_cap_usd = os.environ.get("FACTORY_IMAGE_MAX_CALL_USD", "0")
        try:
            budget_micros = int(round(float(budget_usd) * 1_000_000))
            call_cap_micros = int(round(float(call_cap_usd) * 1_000_000))
            image_budget_micros = int(round(float(image_budget_usd) * 1_000_000))
            image_call_cap_micros = int(round(float(image_call_cap_usd) * 1_000_000))
            timeout = float(os.environ.get("FACTORY_OPENAI_TIMEOUT_SECONDS", "60"))
        except ValueError as exc:
            raise ValueError("Budget and timeout settings must be numeric") from exc
        if min(budget_micros, call_cap_micros, image_budget_micros, image_call_cap_micros) < 0:
            raise ValueError("Budgets cannot be negative")
        if timeout <= 0 or timeout > 180:
            raise ValueError("FACTORY_OPENAI_TIMEOUT_SECONDS must be between 0 and 180")
        if not 1 <= port <= 65535:
            raise ValueError("FACTORY_PORT must be between 1 and 65535")
        return cls(
            data_dir=Path(os.environ.get("FACTORY_DATA_DIR", "./data")).resolve(),
            bootstrap_token=os.environ.get("FACTORY_BOOTSTRAP_TOKEN", ""),
            host=os.environ.get("FACTORY_HOST", "127.0.0.1"),
            port=port,
            generation_budget_micros=budget_micros,
            openai_enabled=os.environ.get("FACTORY_OPENAI_ENABLED", "false").lower() == "true",
            openai_model=os.environ.get("FACTORY_OPENAI_MODEL", "gpt-6.1-sol").strip(),
            openai_max_call_micros=call_cap_micros,
            openai_timeout_seconds=timeout,
            image_generation_enabled=os.environ.get("FACTORY_IMAGE_GENERATION_ENABLED", "false").lower() == "true",
            image_generation_budget_micros=image_budget_micros,
            image_generation_max_call_micros=image_call_cap_micros,
        )

