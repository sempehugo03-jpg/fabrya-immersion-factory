from __future__ import annotations


class FactoryError(Exception):
    """Base error with a stable, user-safe API code."""

    code = "FACTORY_ERROR"
    status = 500

    def __init__(self, message: str = "Request could not be completed") -> None:
        super().__init__(message)
        self.message = message


class ValidationError(FactoryError):
    code = "VALIDATION_ERROR"
    status = 400


class Unauthorized(FactoryError):
    code = "UNAUTHORIZED"
    status = 401


class NotFound(FactoryError):
    code = "NOT_FOUND"
    status = 404


class Conflict(FactoryError):
    code = "CONFLICT"
    status = 409


class NotReady(FactoryError):
    code = "NOT_READY"
    status = 503


class BudgetExceeded(FactoryError):
    code = "BUDGET_EXCEEDED"
    status = 402

