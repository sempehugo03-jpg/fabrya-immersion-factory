"""FABRYA Immersion Factory Phase A foundation."""

__version__ = "0.1.0"
