from __future__ import annotations

import asyncio
import threading
import time

from .creative_brain import CreativeBrain
from .errors import BudgetExceeded, Conflict, FactoryError, NotReady
from .openai_provider import OpenAICreativeProvider
from .production import ProductionPipeline
from .store import Store


class GenerationOrchestrator:
    """Phase B job runner; only the creative-blueprint stage can reach the provider."""

    def __init__(self, store: Store, *, provider_enabled: bool = False,
                 provider: OpenAICreativeProvider | None = None,
                 generation_budget_micros: int = 0, max_call_micros: int = 0,
                 production_pipeline: ProductionPipeline | None = None) -> None:
        self.store = store
        self.provider_enabled = provider_enabled
        self.provider = provider
        self.generation_budget_micros = generation_budget_micros
        self.max_call_micros = max_call_micros
        self.production_pipeline = production_pipeline

    def run_one(self) -> bool:
        """Compatibility entrypoint for the existing thread worker."""
        return asyncio.run(self.run_one_async())

    async def run_one_async(self) -> bool:
        job = self.store.claim_next_job()
        if job is None:
            return False
        job_id = str(job["id"])
        project_id = str(job["project_id"])
        self.store.add_checkpoint(job_id, "provider_preflight", "running", {
            "provider_enabled": self.provider_enabled,
            "provider_adapter_ready": self.provider is not None,
            "external_calls": 0,
        })
        if not self.provider_enabled:
            self.store.transition_job(job_id, "blocked", "waiting_for_openai_authorization", error_code="OPENAI_PROVIDER_DISABLED")
            return True
        if self.max_call_micros <= 0 or self.generation_budget_micros <= 0:
            self.store.transition_job(job_id, "blocked", "waiting_for_budget_configuration", error_code="OPENAI_BUDGET_NOT_CONFIGURED")
            return True
        if self.provider is None:
            self.store.transition_job(job_id, "blocked", "waiting_for_openai_key", error_code="OPENAI_API_KEY_MISSING")
            return True

        try:
            blueprint = await CreativeBrain(
                self.store, self.provider,
                call_cap_micros=self.max_call_micros,
            ).create(project_id, job_id, str(job["brief"]))
            if self.production_pipeline is not None:
                await self.production_pipeline.run_generated(project_id, job_id, blueprint)
                return True
            self.store.transition_job(job_id, "completed", "creative_blueprint_ready", result={
                "contract_version": blueprint["contract_version"],
                "generation_id": blueprint["generation"]["generation_id"],
                "creative_blueprint": blueprint,
                "external_media_generated": False,
                "site_code_generated": False,
            })
        except BudgetExceeded:
            self.store.transition_job(job_id, "blocked", "openai_budget_gate", error_code="OPENAI_BUDGET_EXCEEDED_OR_UNAUTHORIZED")
        except Conflict:
            self.store.transition_job(job_id, "failed", "provider_attempt_prevented", error_code="OPENAI_ATTEMPT_ALREADY_USED")
        except Exception as exc:
            code = "OPENAI_OUTCOME_UNKNOWN" if type(exc).__name__ in {"APIConnectionError", "APITimeoutError", "TimeoutError"} else "CREATIVE_BLUEPRINT_FAILED"
            self.store.transition_job(job_id, "failed", "creative_blueprint_failed", error_code=code)
        return True


class Worker:
    def __init__(self, orchestrator: GenerationOrchestrator, poll_seconds: float = 0.4) -> None:
        self.orchestrator = orchestrator
        self.poll_seconds = poll_seconds
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, name="fif-phase-b-worker", daemon=True)
        self._thread.start()

    def stop(self, timeout: float = 2.0) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout)

    def _loop(self) -> None:
        while not self._stop.is_set():
            try:
                worked = self.orchestrator.run_one()
            except (BudgetExceeded, NotReady, FactoryError):
                worked = False
            except Exception:
                worked = False
            if not worked:
                time.sleep(self.poll_seconds)
