from __future__ import annotations

import json
import os
import re
import uuid
from dataclasses import dataclass
from typing import Callable, Iterable

from .config import Settings
from .contracts import require_text
from .errors import FactoryError, NotFound, NotReady, ValidationError
from .openai_provider import maximum_reservation_micros
from .security import authorize_bootstrap, new_project_token, parse_bearer
from .store import Store

MAX_BODY = 64 * 1024
PROJECT_PATH = re.compile(r"^/v1/projects/([A-Za-z0-9_-]{8,80})$")
GEN_PATH = re.compile(r"^/v1/projects/([A-Za-z0-9_-]{8,80})/generations$")
JOB_PATH = re.compile(r"^/v1/projects/([A-Za-z0-9_-]{8,80})/generations/([A-Za-z0-9_-]{8,80})$")
BLUEPRINT_PATH = re.compile(r"^/v1/projects/([A-Za-z0-9_-]{8,80})/generations/([A-Za-z0-9_-]{8,80})/creative-blueprint$")
BLUEPRINTS_PATH = re.compile(r"^/v1/projects/([A-Za-z0-9_-]{8,80})/creative-blueprints$")
CHECKPOINT_PATH = re.compile(r"^/v1/projects/([A-Za-z0-9_-]{8,80})/generations/([A-Za-z0-9_-]{8,80})/checkpoints$")
RESULT_PATH = re.compile(r"^/v1/projects/([A-Za-z0-9_-]{8,80})/generations/([A-Za-z0-9_-]{8,80})/result$")
VERSIONS_PATH = re.compile(r"^/v1/projects/([A-Za-z0-9_-]{8,80})/versions$")
RESTORE_PATH = re.compile(r"^/v1/projects/([A-Za-z0-9_-]{8,80})/versions/([A-Za-z0-9_-]{8,80})/restore$")
PREVIEW_PATH = re.compile(r"^/v1/projects/([A-Za-z0-9_-]{8,80})/previews$")
PUBLISH_PATH = re.compile(r"^/v1/projects/([A-Za-z0-9_-]{8,80})/publications$")
REVISION_PATH = re.compile(r"^/v1/projects/([A-Za-z0-9_-]{8,80})/revisions$")


@dataclass(slots=True)
class Request:
    method: str
    path: str
    headers: dict[str, str]
    body: bytes


@dataclass(slots=True)
class Response:
    status: int
    body: dict[str, object]
    headers: list[tuple[str, str]] | None = None


class FactoryApi:
    def __init__(self, settings: Settings, store: Store) -> None:
        self.settings = settings
        self.store = store

    def handle(self, request: Request) -> Response:
        request_id = request.headers.get("x-request-id") or "req_" + uuid.uuid4().hex
        try:
            response = self._route(request)
        except FactoryError as exc:
            response = Response(exc.status, {"error": {"code": exc.code, "message": exc.message}})
        except (json.JSONDecodeError, UnicodeDecodeError):
            response = Response(400, {"error": {"code": "INVALID_JSON", "message": "Body must be valid UTF-8 JSON"}})
        response.headers = (response.headers or []) + [("X-Request-ID", request_id), ("Cache-Control", "no-store")]
        return response

    def _route(self, request: Request) -> Response:
        if request.method == "GET" and request.path == "/healthz":
            try:
                required_reservation = maximum_reservation_micros(self.settings.openai_model)
            except ValueError:
                provider_ready = False
            else:
                provider_ready = self.settings.openai_enabled and self.settings.openai_max_call_micros >= required_reservation and self.settings.generation_budget_micros >= required_reservation and bool(os.environ.get("OPENAI_API_KEY", "").strip())
            return Response(200, {"status": "ok", "service": "fabrya-immersion-factory", "phase": "B", "provider_calls_enabled": provider_ready})
        if request.method == "GET" and request.path == "/v1/tools":
            from .contracts import TOOL_CATALOG
            return Response(200, {"tools": [{"name": x.name, "purpose": x.purpose, "input_type": x.input_type, "output_type": x.output_type, "status": x.implementation_status} for x in TOOL_CATALOG]})

        token = parse_bearer(request.headers.get("authorization"))
        if request.method == "POST" and request.path == "/v1/projects":
            authorize_bootstrap(token, self.settings.bootstrap_token)
            body = self._json_body(request.body)
            self._exact_keys(body, {"name"})
            name = require_text(body.get("name"), label="name", maximum=120)
            project_token = new_project_token()
            project = self.store.create_project(name, project_token, budget_micros=self.settings.generation_budget_micros)
            return Response(201, {"project_id": project["id"], "name": project["name"], "project_token": project_token, "created_at": project["created_at"], "budget_usd": self.settings.generation_budget_micros / 1_000_000})

        generation_match = GEN_PATH.fullmatch(request.path)
        if request.method == "POST" and generation_match:
            project_id = generation_match.group(1)
            self._authorize_project(project_id, token)
            body = self._json_body(request.body)
            self._exact_keys(body, {"brief"})
            brief = require_text(body.get("brief"), label="brief", maximum=20_000)
            idem = request.headers.get("idempotency-key", "").strip()
            if not 8 <= len(idem) <= 160:
                raise ValidationError("Idempotency-Key header is required (8–160 characters)")
            job, replay = self.store.create_job(project_id, brief, idem)
            return Response(202, {"job_id": job["id"], "project_id": project_id, "status": job["status"], "status_url": f"/v1/projects/{project_id}/generations/{job['id']}", "idempotent_replay": replay})

        blueprints_match = BLUEPRINTS_PATH.fullmatch(request.path)
        if request.method == "GET" and blueprints_match:
            project_id = blueprints_match.group(1)
            self._authorize_project(project_id, token)
            return Response(200, {"project_id": project_id, "blueprints": self.store.list_creative_blueprints(project_id)})

        job_match = JOB_PATH.fullmatch(request.path)
        if request.method == "GET" and job_match:
            project_id, job_id = job_match.groups()
            self._authorize_project(project_id, token)
            return Response(200, self.store.get_job(project_id, job_id))

        blueprint_match = BLUEPRINT_PATH.fullmatch(request.path)
        if request.method == "GET" and blueprint_match:
            project_id, job_id = blueprint_match.groups()
            self._authorize_project(project_id, token)
            self.store.get_job(project_id, job_id)
            return Response(200, self.store.get_creative_blueprint(project_id, job_id))

        checkpoint_match = CHECKPOINT_PATH.fullmatch(request.path)
        if request.method == "GET" and checkpoint_match:
            project_id, job_id = checkpoint_match.groups()
            self._authorize_project(project_id, token)
            self.store.get_job(project_id, job_id)
            return Response(200, {"job_id": job_id, "checkpoints": self.store.list_checkpoints(job_id)})

        result_match = RESULT_PATH.fullmatch(request.path)
        if request.method == "GET" and result_match:
            project_id, job_id = result_match.groups()
            self._authorize_project(project_id, token)
            job = self.store.get_job(project_id, job_id)
            if job["status"] == "blocked":
                return Response(409, {"error": {"code": job["error_code"], "message": "Generation is blocked until its provider is configured and authorized"}})
            if job["status"] != "completed":
                return Response(409, {"error": {"code": "RESULT_NOT_READY", "message": "Generation has no completed result"}})
            return Response(200, {"job_id": job_id, "result": job["result"]})

        versions_match = VERSIONS_PATH.fullmatch(request.path)
        if request.method == "GET" and versions_match:
            project_id = versions_match.group(1)
            self._authorize_project(project_id, token)
            return Response(200, {"project_id": project_id, "versions": self.store.list_versions(project_id)})

        restore_match = RESTORE_PATH.fullmatch(request.path)
        if request.method == "POST" and restore_match:
            project_id, _version_id = restore_match.groups()
            self._authorize_project(project_id, token)
            raise NotReady("Version restoration is defined by contract but not implemented in Phase A")

        revision_match = REVISION_PATH.fullmatch(request.path)
        if request.method == "POST" and revision_match:
            project_id = revision_match.group(1)
            self._authorize_project(project_id, token)
            raise NotReady("Conversation-driven revisions are defined by contract but not implemented in Phase A")

        preview_match = PREVIEW_PATH.fullmatch(request.path)
        if request.method == "POST" and preview_match:
            project_id = preview_match.group(1)
            self._authorize_project(project_id, token)
            raise NotReady("Private preview hosting is not implemented; no URL has been created")

        publish_match = PUBLISH_PATH.fullmatch(request.path)
        if request.method == "POST" and publish_match:
            project_id = publish_match.group(1)
            self._authorize_project(project_id, token)
            raise NotReady("Publication is disabled in Phase A")

        raise NotFound("Route not found")

    @staticmethod
    def _json_body(raw: bytes) -> dict[str, object]:
        if len(raw) > MAX_BODY:
            raise ValidationError("Request body exceeds 64 KiB")
        value = json.loads(raw.decode("utf-8")) if raw else {}
        if not isinstance(value, dict):
            raise ValidationError("Request body must be a JSON object")
        return value

    @staticmethod
    def _exact_keys(body: dict[str, object], expected: set[str]) -> None:
        if set(body) != expected:
            raise ValidationError("Request contains missing or unsupported fields")

    def _authorize_project(self, project_id: str, token: str) -> None:
        if not self.store.project_authorized(project_id, token):
            # Same response for unknown and unauthorized project IDs avoids project enumeration.
            raise NotFound("Project not found")


def wsgi_app(api: FactoryApi) -> Callable:
    def application(environ: dict[str, object], start_response: Callable) -> Iterable[bytes]:
        length_raw = str(environ.get("CONTENT_LENGTH", "0") or "0")
        try:
            length = int(length_raw)
        except ValueError:
            length = MAX_BODY + 1
        if length < 0 or length > MAX_BODY:
            response = Response(413, {"error": {"code": "BODY_TOO_LARGE", "message": "Request body exceeds 64 KiB"}})
        else:
            body = environ["wsgi.input"].read(length) if length else b""
            headers = {key[5:].replace("_", "-").lower(): str(value) for key, value in environ.items() if key.startswith("HTTP_")}
            request = Request(str(environ.get("REQUEST_METHOD", "GET")), str(environ.get("PATH_INFO", "/")), headers, body)
            response = api.handle(request)
        payload = json.dumps(response.body, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        headers_out = [("Content-Type", "application/json; charset=utf-8"), ("Content-Length", str(len(payload))), ("X-Content-Type-Options", "nosniff"), ("Referrer-Policy", "no-referrer")]
        headers_out.extend(response.headers or [])
        status_line = f"{response.status} {_status_text(response.status)}"
        start_response(status_line, headers_out)
        return [payload]
    return application


def _status_text(status: int) -> str:
    from http import HTTPStatus
    try:
        return HTTPStatus(status).phrase
    except ValueError:
        return "Error"

