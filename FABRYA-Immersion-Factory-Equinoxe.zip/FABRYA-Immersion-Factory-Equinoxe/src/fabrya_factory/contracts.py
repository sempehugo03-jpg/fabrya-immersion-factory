from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Literal, NotRequired, TypedDict

from .errors import ValidationError

JobStatus = Literal["queued", "running", "blocked", "failed", "completed", "cancelled"]


class ProjectCreate(TypedDict):
    name: str


class ProjectCreated(TypedDict):
    project_id: str
    name: str
    project_token: str
    created_at: str
    budget_usd: float


class GenerationCreate(TypedDict):
    brief: str


class GenerationAccepted(TypedDict):
    job_id: str
    project_id: str
    status: JobStatus
    status_url: str
    idempotent_replay: bool


class ErrorBody(TypedDict):
    error: dict[str, str]


class ToolContext(TypedDict):
    project_id: str
    job_id: str
    budget_micros: int
    cancellation_requested: bool


class BriefAnalyzerInput(TypedDict):
    brief: str
    existing_brand_assets: NotRequired[list[str]]


class BriefAnalyzerOutput(TypedDict):
    business_identity: dict[str, str]
    audience: list[str]
    goals: list[str]
    constraints: list[str]
    unknowns: list[str]


class ArtDirectorInput(TypedDict):
    business_identity: dict[str, str]
    audience: list[str]
    goals: list[str]
    existing_brand_assets: list[str]


class ArtDirectorOutput(TypedDict):
    concept: str
    palette: list[str]
    typography_direction: str
    light_and_materials: str
    composition: str
    narrative: str


class ImmersionArchitectInput(TypedDict):
    business_identity: dict[str, str]
    art_direction: ArtDirectorOutput
    accessibility_preferences: dict[str, str]


class ImmersionArchitectOutput(TypedDict):
    signature_moment: str
    interactions: list[dict[str, str]]
    rationale: list[str]
    reduced_motion_plan: str


class VisualGeneratorInput(TypedDict):
    art_direction: ArtDirectorOutput
    scene_brief: str
    desktop_frame: str
    mobile_frame: str


class VisualGeneratorOutput(TypedDict):
    media_ids: list[str]
    provenance: list[dict[str, str | int]]


class VisualConsistencyInput(TypedDict):
    art_direction: ArtDirectorOutput
    media_ids: list[str]


class VisualConsistencyOutput(TypedDict):
    passed: bool
    issues: list[str]


class MotionBuilderInput(TypedDict):
    interaction_plan: ImmersionArchitectOutput
    reduced_motion: bool


class MotionBuilderOutput(TypedDict):
    component_specs: list[dict[str, str]]
    requires_webgl: bool


class WebsiteArchitectInput(TypedDict):
    brief: str
    art_direction: ArtDirectorOutput
    immersion_plan: ImmersionArchitectOutput


class WebsiteArchitectOutput(TypedDict):
    pages: list[dict[str, str | list[str]]]
    navigation: list[dict[str, str]]
    conversion_goals: list[str]


class CodeGeneratorInput(TypedDict):
    website_plan: WebsiteArchitectOutput
    media_ids: list[str]
    motion_specs: MotionBuilderOutput


class CodeGeneratorOutput(TypedDict):
    source_manifest_id: str
    file_count: int


class SandboxBuilderInput(TypedDict):
    source_manifest_id: str
    project_id: str


class SandboxBuilderOutput(TypedDict):
    sandbox_id: str
    build_status: Literal["passed", "failed"]
    build_log_id: str


class BrowserInspectorInput(TypedDict):
    preview_url: str
    viewports: list[Literal["desktop", "mobile"]]
    interaction_selectors: list[str]


class BrowserInspectorOutput(TypedDict):
    screenshots: list[str]
    console_errors: list[str]
    interaction_results: list[dict[str, str | bool]]


class VisualCriticInput(TypedDict):
    screenshot_ids: list[str]
    brief: str
    art_direction: ArtDirectorOutput


class VisualCriticOutput(TypedDict):
    scorecard: dict[str, float]
    blocking_defects: list[str]
    targeted_fixes: list[str]


class RevisionEngineInput(TypedDict):
    user_request: str
    current_version_id: str


class RevisionEngineOutput(TypedDict):
    changed_files: list[str]
    new_version_id: str
    change_summary: str


class VersionManagerInput(TypedDict):
    action: Literal["snapshot", "restore", "list"]
    version_id: NotRequired[str]


class VersionManagerOutput(TypedDict):
    versions: list[dict[str, str]]
    active_version_id: str


class PreviewPublisherInput(TypedDict):
    version_id: str
    visibility: Literal["private"]


class PreviewPublisherOutput(TypedDict):
    preview_id: str
    preview_url: str
    expires_at: str


class CostSupervisorInput(TypedDict):
    provider: str
    operation: str
    estimated_cost_micros: int
    actual_cost_micros: NotRequired[int]


class CostSupervisorOutput(TypedDict):
    allowed: bool
    remaining_budget_micros: int


@dataclass(frozen=True, slots=True)
class ToolDefinition:
    name: str
    purpose: str
    input_type: str
    output_type: str
    implementation_status: Literal["interface_only", "implemented", "implemented_disabled", "fixture_only", "not_verified"] = "interface_only"


TOOL_CATALOG: tuple[ToolDefinition, ...] = (
    ToolDefinition("brief_analyzer", "Extract business, audience, goals, constraints and unknowns", "BriefAnalyzerInput", "BriefAnalyzerOutput", "implemented_disabled"),
    ToolDefinition("art_director", "Create a business-specific art direction", "ArtDirectorInput", "ArtDirectorOutput", "implemented_disabled"),
    ToolDefinition("immersion_architect", "Compile justified immersive interactions and reduced-motion behavior", "ImmersionArchitectInput", "ImmersionArchitectOutput", "fixture_only"),
    ToolDefinition("visual_generator", "Generate original project-specific media with provenance", "VisualGeneratorInput", "VisualGeneratorOutput", "implemented_disabled"),
    ToolDefinition("visual_consistency_controller", "Check visual continuity across project media", "VisualConsistencyInput", "VisualConsistencyOutput"),
    ToolDefinition("motion_builder", "Compile blueprint-justified motion specifications; WebGL remains spec-only", "MotionBuilderInput", "MotionBuilderOutput", "fixture_only"),
    ToolDefinition("website_architect", "Transform a blueprint into an explicit site plan", "WebsiteArchitectInput", "WebsiteArchitectOutput", "fixture_only"),
    ToolDefinition("code_generator", "Build data-driven static website source files", "CodeGeneratorInput", "CodeGeneratorOutput", "fixture_only"),
    ToolDefinition("sandbox_builder", "Syntax-check source in a read-only filesystem and network-denied sandbox", "SandboxBuilderInput", "SandboxBuilderOutput", "implemented"),
    ToolDefinition("browser_inspector", "Inspect real desktop/mobile browser renders with Playwright", "BrowserInspectorInput", "BrowserInspectorOutput", "not_verified"),
    ToolDefinition("visual_critic", "Score inspected screenshots and identify fixes", "VisualCriticInput", "VisualCriticOutput"),
    ToolDefinition("revision_engine", "Apply targeted conversational revisions", "RevisionEngineInput", "RevisionEngineOutput"),
    ToolDefinition("version_manager", "Snapshot and restore isolated build versions", "VersionManagerInput", "VersionManagerOutput", "fixture_only"),
    ToolDefinition("preview_publisher", "Publish private isolated previews", "PreviewPublisherInput", "PreviewPublisherOutput"),
    ToolDefinition("cost_reliability_supervisor", "Gate budgets and record provider reliability", "CostSupervisorInput", "CostSupervisorOutput", "implemented"),
)


def require_object(value: object, *, label: str) -> dict[str, object]:
    if not isinstance(value, dict) or any(not isinstance(k, str) for k in value):
        raise ValidationError(f"{label} must be a JSON object")
    return value


def require_text(value: object, *, label: str, minimum: int = 1, maximum: int = 20_000) -> str:
    if not isinstance(value, str):
        raise ValidationError(f"{label} must be a string")
    normalized = value.strip()
    if not minimum <= len(normalized) <= maximum:
        raise ValidationError(f"{label} length must be between {minimum} and {maximum}")
    return normalized


def require_identifier(value: str, *, label: str) -> str:
    if not re.fullmatch(r"[A-Za-z0-9_-]{8,80}", value):
        raise ValidationError(f"{label} has an invalid format")
    return value

