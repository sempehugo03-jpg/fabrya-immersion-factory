"""Phase C production plumbing. Fixture data is explicitly non-production and never sent to providers."""

from __future__ import annotations

import asyncio
import base64
import ctypes
import ctypes.util
import hashlib
import html
import json
import os
import re
import resource
import shutil
import signal
import subprocess
import tempfile
import threading
import time
from dataclasses import asdict, dataclass
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Protocol
from urllib.parse import urlparse

from .costs import CostSupervisor
from .errors import BudgetExceeded, Conflict, NotReady, ValidationError
from .store import Store, new_id, utc_now

MEDIA_PLAN_VERSION = "fabrya.media-plan/v1"
SITE_PLAN_VERSION = "fabrya.site-plan/v1"
IMMERSION_RUNTIME_VERSION = "fabrya.immersion-runtime/v1"
QA_REPORT_VERSION = "fabrya.visual-qa/v1"
IMAGE_MODEL_DEFAULT = "gpt-image-2.6-sunburst"


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _slug(text: str) -> str:
    value = re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")
    return value[:48] or "page"


def _hex_color(value: object) -> str:
    if isinstance(value, str) and re.fullmatch(r"#[0-9A-Fa-f]{6}", value):
        return value
    raise ValidationError("Site plan contains an invalid palette color")


def _decisions(blueprint: dict[str, Any]) -> dict[str, Any]:
    if blueprint.get("contract_version") != "fabrya.creative-blueprint/v1":
        raise ValidationError("Expected fabrya.creative-blueprint/v1")
    value = blueprint.get("decisions")
    if not isinstance(value, dict):
        raise ValidationError("Creative blueprint has no decisions object")
    return value


@dataclass(frozen=True, slots=True)
class PlannedImage:
    asset_id: str
    role: str
    representation: str
    desktop_prompt: str
    mobile_prompt: str
    desktop_size: str
    mobile_size: str
    authenticity_note: str
    requires_client_reference: bool


@dataclass(frozen=True, slots=True)
class MediaPlan:
    contract_version: str
    provenance: str
    external_stock_media_allowed: bool
    consistency_rules: tuple[str, ...]
    assets: tuple[PlannedImage, ...]

    def to_dict(self) -> dict[str, Any]:
        return {"contract_version": self.contract_version, "provenance": self.provenance,
                "external_stock_media_allowed": self.external_stock_media_allowed,
                "consistency_rules": list(self.consistency_rules),
                "assets": [asdict(item) for item in self.assets]}


class MediaPlanBuilder:
    @staticmethod
    def from_blueprint(blueprint: dict[str, Any]) -> MediaPlan:
        decisions = _decisions(blueprint)
        visual = decisions.get("visual_plan", {})
        if visual.get("external_stock_media_allowed") is not False:
            raise ValidationError("External stock-media use is forbidden")
        rules = tuple(str(x) for x in visual.get("global_consistency_rules", []))
        photography = decisions.get("art_direction", {}).get("photography_direction", {})
        assets: list[PlannedImage] = []
        for raw in visual.get("assets", []):
            asset_id = str(raw.get("asset_id", ""))
            if not re.fullmatch(r"[A-Za-z0-9_-]{1,80}", asset_id):
                raise ValidationError("Invalid image asset identifier")
            common = " ".join((str(raw.get("generation_prompt", "")), str(raw.get("authenticity_note", "")),
                               str(photography.get("style", "")), str(photography.get("lighting", "")),
                               str(photography.get("materials", "")), "Consistency: " + "; ".join(rules),
                               "Create an original conceptual image; do not claim it depicts the real company, "
                               "its premises, employees, customers, products, or completed work. No stock imagery.")).strip()
            assets.append(PlannedImage(
                asset_id=asset_id, role=str(raw.get("role", "")),
                representation=str(raw.get("representation", "conceptual_generated_visual")),
                desktop_prompt=common + " Desktop framing: " + str(raw.get("desktop_framing", "wide composition")) + ".",
                mobile_prompt=common + " Mobile framing: " + str(raw.get("mobile_framing", "vertical composition")) + ".",
                desktop_size="1536x1024", mobile_size="1024x1536",
                authenticity_note=str(raw.get("authenticity_note", "Conceptual visual; not a real business photograph.")),
                requires_client_reference=bool(raw.get("authentic_reference_required", False)),
            ))
        if not assets:
            raise ValidationError("Creative blueprint contains no visual assets")
        return MediaPlan(MEDIA_PLAN_VERSION, str(blueprint["generation"].get("provider", "unknown")), False, rules, tuple(assets))


@dataclass(frozen=True, slots=True)
class ImageGenerationResult:
    data: bytes
    mime_type: str
    model: str
    request_id: str | None
    input_tokens: int
    output_tokens: int


class ImageProvider(Protocol):
    name: str
    model: str

    async def generate(self, prompt: str, *, size: str) -> ImageGenerationResult: ...


class OpenAIImageProvider:
    """Server-only async Image API adapter. It is inert until explicitly enabled and budgeted."""

    name = "openai"

    def __init__(self, client: Any, model: str = IMAGE_MODEL_DEFAULT, *, enabled: bool = False) -> None:
        self.client, self.model, self.enabled = client, model, enabled

    @classmethod
    def from_env(cls) -> "OpenAIImageProvider | None":
        if os.environ.get("FACTORY_IMAGE_GENERATION_ENABLED", "false").lower() != "true":
            return None
        if not os.environ.get("OPENAI_API_KEY", "").strip():
            return None
        import openai
        from openai import AsyncOpenAI
        from .openai_provider import SDK_VERSION
        if openai.__version__ != SDK_VERSION:
            raise RuntimeError(f"Expected pinned OpenAI SDK {SDK_VERSION}; found {openai.__version__}")
        client = AsyncOpenAI(api_key=os.environ["OPENAI_API_KEY"].strip(), max_retries=0, timeout=90)
        return cls(client, os.environ.get("FACTORY_IMAGE_MODEL", IMAGE_MODEL_DEFAULT), enabled=True)

    async def generate(self, prompt: str, *, size: str) -> ImageGenerationResult:
        if not self.enabled:
            raise NotReady("Image provider is disabled")
        response = await self.client.images.generate(
            model=self.model, prompt=prompt, size=size, quality="high", output_format="png", n=1,
        )
        data = getattr(response, "data", None) or []
        encoded = getattr(data[0], "b64_json", None) if data else None
        if not encoded:
            raise ValueError("Image provider returned no base64 image")
        usage = getattr(response, "usage", None)
        if usage is None:
            # Do not silently settle an unknown provider charge as zero.
            raise ValueError("Image provider returned no usage; cost cannot be measured")
        return ImageGenerationResult(
            data=base64.b64decode(encoded, validate=True), mime_type="image/png", model=self.model,
            request_id=getattr(response, "_request_id", None),
            input_tokens=int(getattr(usage, "input_tokens", 0) or 0),
            output_tokens=int(getattr(usage, "output_tokens", 0) or 0),
        )


class OriginalImageFactory:
    def __init__(self, store: Store, media_root: Path, provider: ImageProvider | None = None, *, enabled: bool = False,
                 generation_budget_micros: int = 0, per_image_reservation_micros: int = 0) -> None:
        self.store, self.media_root, self.provider, self.enabled = store, media_root, provider, enabled
        self.generation_budget_micros = generation_budget_micros
        self.per_image_reservation_micros = per_image_reservation_micros
        self.costs = CostSupervisor(store)

    def plan(self, blueprint: dict[str, Any]) -> MediaPlan:
        return MediaPlanBuilder.from_blueprint(blueprint)

    def fixture_asset(self, project_id: str, job_id: str, plan: PlannedImage, variant: str) -> dict[str, Any]:
        if variant not in {"desktop", "mobile"}:
            raise ValidationError("Unsupported media variant")
        operation_key = f"fixture-image:{plan.asset_id}:{variant}"
        content = self._fixture_svg(plan, variant)
        digest = _sha256(content)
        if not self.store.begin_factory_operation(project_id, job_id, operation_key, "fixture", digest):
            previous = self.store.get_factory_operation(project_id, job_id, operation_key)
            if previous and previous["state"] == "succeeded":
                entries = self.store.list_factory_media(project_id, job_id)
                return next(item for item in entries if item["asset_id"] == plan.asset_id and item["variant"] == variant)
            raise Conflict("Fixture media operation already started; it will not be replayed")
        folder = self.media_root / project_id / job_id / "media"
        folder.mkdir(parents=True, exist_ok=True)
        path = folder / f"{plan.asset_id}-{variant}-FIXTURE.svg"
        path.write_bytes(content)
        result = self.store.add_factory_media(
            project_id, job_id, plan.asset_id, variant, source_kind="fixture", rights_status="fixture_not_for_client_use",
            mime_type="image/svg+xml", storage_key=str(path), sha256=digest, provider="fixture", model=None,
            request_id=None, estimated_cost_micros=0,
            provenance={"origin": "hand-authored plumbing fixture", "fixture": True,
                        "prompt_sha256": _sha256((plan.desktop_prompt if variant == "desktop" else plan.mobile_prompt).encode()),
                        "client_authorized": False, "original_media_retained": True},
        )
        self.store.finish_factory_operation(project_id, job_id, operation_key, "succeeded", result={"media_id": result["id"], "fixture": True})
        return result

    async def generate_variant(self, project_id: str, job_id: str, plan: PlannedImage, variant: str) -> dict[str, Any]:
        if not self.enabled or self.provider is None:
            raise NotReady("Original image generation is disabled; no provider call was made")
        if self.generation_budget_micros <= 0 or self.per_image_reservation_micros <= 0:
            raise BudgetExceeded("Image-generation budget is zero; no provider call was made")
        if self.per_image_reservation_micros > self.generation_budget_micros:
            raise BudgetExceeded("Per-image reservation exceeds the configured image-generation budget")
        if variant not in {"desktop", "mobile"}:
            raise ValidationError("Unsupported media variant")
        if self.provider.model != IMAGE_MODEL_DEFAULT:
            raise NotReady("Image model must be revalidated before enabling image generation")
        prompt = plan.desktop_prompt if variant == "desktop" else plan.mobile_prompt
        size = plan.desktop_size if variant == "desktop" else plan.mobile_size
        digest = _sha256(json.dumps({"prompt": prompt, "size": size, "model": self.provider.model}, sort_keys=True).encode())
        operation_key = f"image:{plan.asset_id}:{variant}"
        if self.store.get_factory_operation(project_id, job_id, operation_key):
            raise Conflict("Image operation already exists; no automatic retry is permitted")
        reservation = self.costs.reserve(project_id, job_id, "openai", operation_key, self.per_image_reservation_micros)
        if not self.store.begin_factory_operation(project_id, job_id, operation_key, self.provider.name, digest):
            self.costs.release(reservation)
            raise Conflict("Image operation already exists; no automatic retry is permitted")
        try:
            generated = await self.provider.generate(prompt, size=size)
            if generated.model != self.provider.model or not generated.data:
                raise ValidationError("Image provider result does not match the requested model or contains no bytes")
        except Exception as exc:
            self.store.finish_factory_operation(project_id, job_id, operation_key, "uncertain", error_code=type(exc).__name__)
            raise
        cost = self._estimate_image_cost(generated)
        folder = self.media_root / project_id / job_id / "media"
        folder.mkdir(parents=True, exist_ok=True)
        suffix = ".png" if generated.mime_type == "image/png" else ".webp"
        path = folder / f"{plan.asset_id}-{variant}-original{suffix}"
        temp_path = path.with_suffix(path.suffix + ".tmp")
        temp_path.write_bytes(generated.data)
        os.replace(temp_path, path)
        try:
            self.costs.settle_estimate(reservation, cost)
        except BudgetExceeded:
            self.store.finish_factory_operation(project_id, job_id, operation_key, "failed", error_code="IMAGE_COST_OVERRUN")
            raise
        item = self.store.add_factory_media(
            project_id, job_id, plan.asset_id, variant, source_kind="generated", rights_status="generated_by_fabrya_conceptual",
            mime_type=generated.mime_type, storage_key=str(path), sha256=_sha256(generated.data), provider="openai",
            model=generated.model, request_id=generated.request_id, estimated_cost_micros=cost,
            provenance={"origin": "OpenAI Image API", "fixture": False, "prompt_sha256": _sha256(prompt.encode()),
                        "client_authorized": False, "conceptual_only": True, "original_media_retained": True,
                        "input_tokens": generated.input_tokens, "output_tokens": generated.output_tokens,
                        "reserved_cost_micros": reservation.reserved_micros},
        )
        self.store.finish_factory_operation(project_id, job_id, operation_key, "succeeded", result={"media_id": item["id"], "cost_micros": cost})
        return item

    @staticmethod
    def _estimate_image_cost(result: ImageGenerationResult) -> int:
        # Standard token rates are cost accounting, not a billing ceiling.
        return int((result.input_tokens * 5 + result.output_tokens * 30) * 1_000_000 / 1_000_000)

    @staticmethod
    def _fixture_svg(plan: PlannedImage, variant: str) -> bytes:
        width, height = (1200, 760) if variant == "desktop" else (600, 900)
        svg = f'''<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}" role="img" aria-label="Visuel de fixture technique, pas une photographie">
<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#11191e"/><stop offset=".55" stop-color="#28353a"/><stop offset="1" stop-color="#a96943"/></linearGradient><pattern id="p" width="36" height="36" patternUnits="userSpaceOnUse"><path d="M0 36L36 0" stroke="#ffffff" stroke-opacity=".08"/></pattern></defs>
<rect width="100%" height="100%" fill="url(#g)"/><rect width="100%" height="100%" fill="url(#p)"/><circle cx="{width*.75:.0f}" cy="{height*.35:.0f}" r="{min(width,height)*.23:.0f}" fill="none" stroke="#f1dbc5" stroke-opacity=".3" stroke-width="2"/><path d="M0 {height*.72:.0f} Q{width*.35:.0f} {height*.48:.0f} {width} {height*.68:.0f} L{width} {height} L0 {height}Z" fill="#0b1013" fill-opacity=".72"/>
<!-- Fixture labeling is provided by the page overlay and persisted provenance. -->
</svg>'''
        return svg.encode("utf-8")


class ImmersionArchitectRuntime:
    """Compiles blueprint decisions into a bounded, auditable motion specification."""

    def compile(self, blueprint: dict[str, Any], media: list[dict[str, Any]]) -> dict[str, Any]:
        decisions = _decisions(blueprint)
        immersion = decisions["immersion"]
        has_scroll = any(re.search(r"scroll|défil|defil|progress", str(x.get("trigger", "") + " " + x.get("behavior", "")), re.I)
                         for x in immersion.get("interactions", []))
        effects = []
        if has_scroll:
            effects.append({"id": "narrative-reveal", "type": "scroll_reveal", "trigger": "intersection",
                            "rationale": str(immersion["signature_moment"]),
                            "reduced_motion": str(immersion["reduced_motion_plan"])})
        three_d = immersion.get("three_d_decision", {})
        return {
            "contract_version": IMMERSION_RUNTIME_VERSION,
            "provenance": str(blueprint["generation"].get("provider", "unknown")),
            "fixture": str(blueprint["generation"].get("provider", "")).startswith("offline_fixture"),
            "scene": {"id": "opening", "signature_moment": str(immersion["signature_moment"]),
                      "depth_model": str(immersion["depth_model"]), "media_ids": [str(x["id"]) for x in media]},
            "effects": effects,
            "interactions": immersion.get("interactions", []),
            "transitions": immersion.get("transition_plan", []),
            "responsive": {"mobile": immersion.get("mobile_adaptation", []),
                           "reduced_motion": immersion.get("reduced_motion_plan", "Respect prefers-reduced-motion")},
            "three_d": {"requested": bool(three_d.get("use_webgl", False)),
                        "status": "specification_only" if three_d.get("use_webgl", False) else "not_required",
                        "rationale": str(three_d.get("rationale", "")),
                        "fallback": str(three_d.get("fallback", ""))},
            "performance_constraints": immersion.get("performance_constraints", []),
        }


def site_plan_from_blueprint(blueprint: dict[str, Any]) -> dict[str, Any]:
    decisions = _decisions(blueprint)
    profile = decisions["analysis"]["business_profile"]
    art = decisions["art_direction"]
    hierarchy = art.get("page_hierarchy", [])
    pages = []
    seen = set()
    for raw in hierarchy:
        title = str(raw["page"]).strip()
        slug = "index" if not pages else _slug(title)
        if slug in seen:
            raise ValidationError("Blueprint page hierarchy contains duplicate routes")
        seen.add(slug)
        pages.append({"slug": slug, "title": title, "purpose": str(raw["purpose"]),
                      "visual_role": str(raw["visual_role"]), "sections": [str(raw["purpose"]), str(raw["visual_role"])]})
    if not pages:
        raise ValidationError("Blueprint has no page hierarchy")
    palette = [{"name": str(item["name"]), "hex": _hex_color(item["hex"]), "role": str(item["role"])}
               for item in art.get("palette", [])]
    if len(palette) < 2:
        raise ValidationError("Blueprint palette must contain at least two colors")
    company = str(profile.get("company_name", "Projet FABRYA"))
    return {
        "contract_version": SITE_PLAN_VERSION,
        "provenance": str(blueprint["generation"].get("provider", "unknown")),
        "fixture": str(blueprint["generation"].get("provider", "")).startswith("offline_fixture"),
        "brand": {"name": company, "concept": str(art["concept_title"]),
                  "central_concept": str(art["central_concept"]), "narrative": str(art["narrative"]),
                  "composition": str(art["composition"]), "typography": str(art["typography_direction"])},
        "palette": palette,
        "navigation": [{"label": p["title"], "href": "index.html" if p["slug"] == "index" else p["slug"] + ".html"}
                       for p in pages],
        "pages": pages,
        "form_mode": "local_fixture_no_external_submission",
        "image_asset_ids": [str(x["asset_id"]) for x in decisions["visual_plan"].get("assets", [])],
    }


def validate_site_plan(plan: dict[str, Any]) -> None:
    if plan.get("contract_version") != SITE_PLAN_VERSION or not isinstance(plan.get("fixture"), bool):
        raise ValidationError("Invalid Site Plan contract header")
    if not isinstance(plan.get("brand"), dict) or not plan["brand"].get("name"):
        raise ValidationError("Site Plan brand is required")
    if plan.get("form_mode") not in {"local_fixture_no_external_submission", "connected_service"}:
        raise ValidationError("Forms must declare their delivery mode")
    pages = plan.get("pages")
    navigation = plan.get("navigation")
    if not isinstance(pages, list) or not pages or len(pages) > 20 or not isinstance(navigation, list):
        raise ValidationError("Invalid Site Plan pages or navigation")
    slugs = [x.get("slug") for x in pages]
    if len(slugs) != len(set(slugs)) or any(not re.fullmatch(r"[a-z0-9-]{1,48}", str(x)) for x in slugs):
        raise ValidationError("Site Plan routes must be unique slugs")
    for item in plan.get("palette", []):
        _hex_color(item.get("hex"))


class WebsiteBuilder:
    """Generate self-contained, data-driven static pages; no garage preset or external dependency."""

    def build(self, plan: dict[str, Any], immersion: dict[str, Any], media: list[dict[str, Any]], output: Path) -> dict[str, Any]:
        validate_site_plan(plan)
        output.mkdir(parents=True, exist_ok=True)
        asset_dir = output / "assets"
        asset_dir.mkdir(exist_ok=True)
        desktop_by_asset = {str(x["asset_id"]): x for x in media if x.get("variant") == "desktop"}
        mobile_by_asset = {str(x["asset_id"]): x for x in media if x.get("variant") == "mobile"}
        asset_refs: dict[str, dict[str, str]] = {}
        for asset_id in plan["image_asset_ids"]:
            refs = {}
            for variant, lookup in (("desktop", desktop_by_asset), ("mobile", mobile_by_asset)):
                item = lookup.get(asset_id)
                if not item:
                    continue
                source = Path(str(item["storage_key"]))
                ext = source.suffix.lower()
                name = f"{_slug(asset_id)}-{variant}{ext}"
                shutil.copyfile(source, asset_dir / name)
                refs[variant] = "assets/" + name
            asset_refs[asset_id] = refs
        first_asset = plan["image_asset_ids"][0] if plan["image_asset_ids"] else ""
        palette = plan["palette"]
        tokens = {"--fif-bg": palette[0]["hex"], "--fif-accent": palette[1]["hex"],
                  "--fif-ink": palette[-1]["hex"], "--fif-paper": "#f2efe9"}
        (output / "styles.css").write_text(_site_css(tokens), encoding="utf-8")
        (output / "site.js").write_text(_site_js(bool(immersion.get("effects"))), encoding="utf-8")
        for page in plan["pages"]:
            filename = "index.html" if page["slug"] == "index" else page["slug"] + ".html"
            document = self._render_page(plan, page, filename, first_asset, asset_refs, immersion, tokens)
            (output / filename).write_text(document, encoding="utf-8")
        manifest = {"schema": "fabrya.website-build/v1", "provenance": plan["provenance"],
                    "fixture": plan["fixture"], "files": sorted(x.name for x in output.iterdir() if x.is_file()),
                    "assets": sorted(str(x.relative_to(output)) for x in asset_dir.iterdir() if x.is_file()),
                    "network_dependencies": [], "source_framework": "semantic static HTML/CSS/JS",
                    "responsive": True, "reduced_motion": True, "form_mode": plan["form_mode"]}
        (output / "build-manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
        return manifest

    def _render_page(self, plan: dict[str, Any], page: dict[str, Any], filename: str, asset_id: str,
                     assets: dict[str, dict[str, str]], immersion: dict[str, Any], tokens: dict[str, str]) -> str:
        e = lambda x: html.escape(str(x), quote=True)
        links = "".join(f'<a href="{e(nav["href"])}"{ " aria-current=\"page\"" if nav["href"] == filename else ""}>{e(nav["label"])}</a>' for nav in plan["navigation"])
        brand = plan["brand"]
        asset = assets.get(asset_id, {})
        picture = ""
        if asset:
            img_alt = "Visuel de fixture technique — à remplacer par un média original autorisé" if plan["fixture"] else "Visuel conceptuel original; ne représente pas l'entreprise réelle"
            picture = (f'<picture class="hero-media"><source media="(max-width: 640px)" srcset="{e(asset.get("mobile", asset.get("desktop", "")))}">'
                       f'<img src="{e(asset.get("desktop", ""))}" alt="{e(img_alt)}" fetchpriority="high"></picture>')
        is_home = page["slug"] == "index"
        headline = brand["concept"] if is_home else page["title"]
        intro = brand["central_concept"] if is_home else page["purpose"]
        paragraph = brand["narrative"] if is_home else page["visual_role"]
        cta_href = next((x["href"] for x in plan["navigation"] if "contact" in x["href"].lower()), "#site-footer")
        form = ""
        if "contact" in page["slug"].lower() or page["title"].lower() in {"contact", "contactez-nous"}:
            form = '''<form class="contact-form" data-form-mode="local_fixture_no_external_submission">
<label>Votre nom<input name="name" autocomplete="name" required></label><label>Votre email<input name="email" type="email" autocomplete="email" required></label>
<label>Votre demande<textarea name="message" rows="4" required></textarea></label><button type="submit">Préparer la demande</button>
<p class="form-status" role="status" aria-live="polite">Démo locale : aucun message n'est envoyé.</p></form>'''
        fx = immersion.get("effects", [])
        reveal = ' data-fif-reveal="true"' if fx else ""
        return f'''<!doctype html>
<html lang="fr" style="{e(";".join(f"{k}:{v}" for k,v in tokens.items()))}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex,nofollow"><meta name="description" content="{e(brand["narrative"])}"><title>{e(headline)} — {e(brand["name"])}</title><link rel="stylesheet" href="styles.css"><script defer src="site.js"></script></head>
<body data-fixture="{str(plan["fixture"]).lower()}"><a class="skip-link" href="#main">Aller au contenu</a>
<header class="site-header"><a class="wordmark" href="index.html">{e(brand["name"])}</a><button class="nav-toggle" type="button" aria-expanded="false" aria-controls="site-nav">Menu</button><nav id="site-nav" aria-label="Navigation principale">{links}</nav></header>
<main id="main"><section class="hero" data-signature-moment="{e(immersion["scene"]["signature_moment"])}">{picture}<div class="hero-copy"><p class="eyebrow">{e(brand["name"])} · {e(page["visual_role"])}</p><h1>{e(headline)}</h1><p class="lede">{e(intro)}</p><a class="button" href="{e(cta_href)}">Découvrir le parcours</a></div><span class="fixture-mark">{ "FIXTURE TECHNIQUE · PAS UNE CRÉATION IA" if plan["fixture"] else "VISUEL CONCEPTUEL" }</span></section>
<section class="narrative"{reveal}><p class="eyebrow">{e(page["title"])}</p><h2>{e(page["purpose"])}</h2><p>{e(paragraph)}</p><p class="note">{e(brand["composition"])}</p></section>
{form}<section class="next-step"><p>{e(page["visual_role"])}</p><a href="{e(cta_href)}">Continuer vers le contact <span aria-hidden="true">↗</span></a></section></main>
<footer id="site-footer"><span>{e(brand["name"])}</span><span>{e(brand["concept"])}</span><span class="fixture-mark">{ "SITE DE TEST — AUCUN ENVOI EXTERNE" if plan["fixture"] else "PRÉVISUALISATION PRIVÉE" }</span></footer></body></html>'''


def _site_css(tokens: dict[str, str]) -> str:
    return '''*{box-sizing:border-box}html{scroll-behavior:smooth;background:var(--fif-bg);color:var(--fif-paper);font-family:Arial,Helvetica,sans-serif}body{margin:0;min-width:320px}.skip-link{position:absolute;left:-999px;top:0}.skip-link:focus{left:1rem;top:1rem;z-index:10;background:var(--fif-paper);color:#111;padding:.8rem}.site-header{height:76px;padding:0 clamp(1rem,5vw,5rem);display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid #ffffff24;position:absolute;z-index:5;width:100%;color:#fff}.wordmark{color:inherit;text-decoration:none;letter-spacing:.08em;text-transform:uppercase;font-size:.85rem;font-weight:700}.site-header nav{display:flex;gap:clamp(1rem,3vw,2.7rem)}.site-header nav a{color:inherit;text-decoration:none;font-size:.9rem}.site-header nav a[aria-current=page]{border-bottom:1px solid #fff;padding-bottom:.3rem}.nav-toggle{display:none}.hero{min-height:min(820px,100svh);min-height:min(820px,100vh);position:relative;display:flex;align-items:flex-end;padding:clamp(6rem,16vh,10rem) clamp(1.25rem,8vw,8rem) clamp(3rem,9vh,7rem);overflow:hidden;background:linear-gradient(125deg,#10191d,#2d3639 58%,#9d6547)}.hero:after{content:"";position:absolute;inset:0;background:linear-gradient(90deg,#0b1013dd 0%,#0b101388 53%,#0b101322 100%),linear-gradient(0deg,#0b1013aa,transparent 55%)}.hero-media,.hero-media img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}.hero-media img{opacity:.48;mix-blend-mode:screen}.hero-copy{position:relative;z-index:2;max-width:780px}.eyebrow{text-transform:uppercase;letter-spacing:.16em;font-size:.74rem;line-height:1.5}.hero h1{font-family:Georgia,serif;font-size:clamp(3rem,8vw,7.8rem);font-weight:400;letter-spacing:-.055em;line-height:.94;max-width:11ch;margin:1rem 0 1.25rem}.lede{max-width:42rem;font-size:clamp(1rem,1.7vw,1.3rem);line-height:1.6;color:#f0ece6}.button{display:inline-flex;margin-top:1.6rem;padding:1rem 1.35rem;border:1px solid #fff;color:#fff;text-decoration:none;text-transform:uppercase;letter-spacing:.08em;font-size:.76rem}.button:hover,.button:focus-visible{background:#fff;color:#111}.fixture-mark{font-size:.62rem;letter-spacing:.12em;text-transform:uppercase}.hero>.fixture-mark{position:absolute;right:1.2rem;bottom:1rem;z-index:3}.narrative{max-width:1000px;margin:0 auto;padding:clamp(4rem,9vw,9rem) clamp(1.25rem,7vw,6rem);display:grid;grid-template-columns:1fr 2fr;gap:1rem 3rem}.narrative h2{font:400 clamp(2rem,4.5vw,4.2rem)/1.05 Georgia,serif;letter-spacing:-.04em;margin:.2rem 0}.narrative>p:not(.eyebrow){grid-column:2;font-size:1.08rem;line-height:1.8;max-width:52rem}.narrative .note{color:#c8b4a2;font-size:.9rem!important}.next-step{padding:3rem clamp(1.25rem,7vw,6rem);display:flex;justify-content:space-between;align-items:center;gap:2rem;background:var(--fif-ink);color:#f7f5f0}.next-step a{color:inherit;text-decoration:none;border-bottom:1px solid #fff;padding:.8rem 0}.contact-form{max-width:720px;margin:0 auto 5rem;padding:2rem clamp(1rem,5vw,4rem);display:grid;gap:1.2rem}.contact-form label{display:grid;gap:.45rem;font-size:.9rem}.contact-form input,.contact-form textarea{width:100%;padding:.9rem;background:#fff;color:#111;border:1px solid #999;font:inherit}.contact-form button{justify-self:start;padding:1rem 1.3rem;background:var(--fif-accent);border:0;color:#fff;font:inherit;cursor:pointer}.form-status{min-height:1.4rem}footer{padding:2rem clamp(1.25rem,5vw,5rem);display:flex;justify-content:space-between;gap:1rem;border-top:1px solid #ffffff30;font-size:.72rem;color:#ddd} @media(max-width:700px){.site-header{height:64px}.nav-toggle{display:block;background:none;border:1px solid #fff;color:#fff;padding:.65rem .8rem}.site-header nav{display:none;position:absolute;top:64px;left:0;right:0;padding:1rem 1.25rem 1.4rem;background:#10191df2;flex-direction:column}.site-header nav.open{display:flex}.hero{min-height:84svh;min-height:84vh;padding:7rem 1.3rem 4rem}.hero:after{background:linear-gradient(0deg,#0b1013ee 5%,#0b101355 83%)}.hero h1{font-size:clamp(3.2rem,14vw,5.4rem);max-width:9ch}.hero-media img{object-position:62% center}.hero>.fixture-mark{right:.8rem;bottom:.7rem}.narrative{display:block;padding:4rem 1.3rem}.narrative h2{margin:1rem 0 1.3rem}.narrative>p:not(.eyebrow){font-size:1rem}.next-step{align-items:flex-start;flex-direction:column;gap:.7rem}footer{flex-direction:column;gap:.65rem}}.js-ready [data-fif-reveal]{opacity:0;transform:translateY(22px);transition:opacity .65s ease,transform .65s ease}.js-ready [data-fif-reveal].is-visible{opacity:1;transform:none}@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto!important}*,*::before,*::after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important;scroll-behavior:auto!important}.js-ready [data-fif-reveal]{opacity:1;transform:none}}'''


def _site_js(enable_scroll_reveal: bool) -> str:
    return f'''(()=>{{const reduced=window.matchMedia('(prefers-reduced-motion: reduce)').matches;const toggle=document.querySelector('.nav-toggle');const nav=document.querySelector('#site-nav');if(toggle&&nav)toggle.addEventListener('click',()=>{{const open=toggle.getAttribute('aria-expanded')!=='true';toggle.setAttribute('aria-expanded',String(open));nav.classList.toggle('open',open);}});const form=document.querySelector('.contact-form');if(form)form.addEventListener('submit',event=>{{event.preventDefault();const status=form.querySelector('.form-status');status.textContent='Demande de test enregistrée dans cette page. Aucun envoi externe.';}});if(!reduced&&{str(enable_scroll_reveal).lower()}&&'IntersectionObserver'in window){{document.documentElement.classList.add('js-ready');const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{{if(entry.isIntersecting){{entry.target.classList.add('is-visible');observer.unobserve(entry.target);}}}}),{{threshold:.15}});document.querySelectorAll('[data-fif-reveal]').forEach(node=>observer.observe(node));}}}})();'''


def _network_seccomp_fd() -> int:
    library = ctypes.util.find_library("seccomp")
    if not library:
        raise NotReady("libseccomp is required for network-denied builds")
    seccomp = ctypes.CDLL(library, use_errno=True)
    seccomp.seccomp_init.argtypes = [ctypes.c_uint32]
    seccomp.seccomp_init.restype = ctypes.c_void_p
    seccomp.seccomp_syscall_resolve_name.argtypes = [ctypes.c_char_p]
    seccomp.seccomp_syscall_resolve_name.restype = ctypes.c_int
    seccomp.seccomp_rule_add.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_int, ctypes.c_uint]
    seccomp.seccomp_export_bpf.argtypes = [ctypes.c_void_p, ctypes.c_int]
    seccomp.seccomp_release.argtypes = [ctypes.c_void_p]
    context = seccomp.seccomp_init(0x7FFF0000)  # SCMP_ACT_ALLOW
    if not context:
        raise NotReady("Could not create network-denial policy")
    fd = os.memfd_create("fif-network-deny", 0)
    try:
        deny = 0x00050000 | 1  # SCMP_ACT_ERRNO(EPERM)
        for name in ("socket", "socketpair", "connect", "bind", "listen", "accept", "accept4",
                     "sendto", "sendmsg", "sendmmsg", "recvfrom", "recvmsg", "recvmmsg",
                     "io_uring_setup", "io_uring_enter", "io_uring_register"):
            number = seccomp.seccomp_syscall_resolve_name(name.encode())
            if number >= 0:
                result = seccomp.seccomp_rule_add(context, deny, number, 0)
                if result != 0:
                    raise NotReady(f"Could not block system call {name}")
        if seccomp.seccomp_export_bpf(context, fd) != 0:
            raise NotReady("Could not export network-denial policy")
        os.lseek(fd, 0, os.SEEK_SET)
        return fd
    except Exception:
        os.close(fd)
        raise
    finally:
        seccomp.seccomp_release(context)


@dataclass(frozen=True, slots=True)
class BuildReport:
    status: str
    sandbox: str
    network_denied: bool
    command: tuple[str, ...]
    return_code: int
    stdout: str
    stderr: str
    elapsed_ms: int

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class BuildSandbox:
    """Bubblewrap filesystem sandbox plus seccomp network denial and process resource limits."""

    def __init__(self, *, timeout_seconds: int = 20, memory_limit_bytes: int = 768 * 1024 * 1024,
                 max_output_bytes: int = 1_000_000) -> None:
        self.timeout_seconds = timeout_seconds
        self.memory_limit_bytes = memory_limit_bytes
        self.max_output_bytes = max_output_bytes

    def build(self, site_dir: Path) -> BuildReport:
        start = time.monotonic()
        bwrap, node = shutil.which("bwrap"), shutil.which("node")
        if not bwrap or not node:
            return BuildReport("blocked", "unavailable", False, (), -1, "", "bwrap or node missing", 0)
        site_dir = site_dir.resolve()
        if not site_dir.is_dir() or not (site_dir / "index.html").is_file() or not (site_dir / "site.js").is_file():
            return BuildReport("failed", "not_started", False, (), -1, "", "site source is incomplete", 0)
        node_path = Path(node).resolve()
        node_root = node_path.parent.parent
        seccomp_fd = -1
        try:
            seccomp_fd = _network_seccomp_fd()
            command = [bwrap, "--die-with-parent", "--new-session",
                       "--ro-bind", "/usr", "/usr",
                       "--ro-bind", "/lib", "/lib", "--ro-bind", "/lib64", "/lib64",
                       "--ro-bind", "/etc", "/etc",
                       "--proc", "/proc", "--dev", "/dev", "--tmpfs", "/tmp",
                       "--dir", "/node", "--ro-bind", str(node_root), "/node",
                       "--dir", "/workspace", "--ro-bind", str(site_dir), "/workspace",
                       "--clearenv", "--setenv", "PATH", "/node/bin:/usr/bin",
                       "--setenv", "HOME", "/tmp", "--chdir", "/workspace",
                       "--seccomp", str(seccomp_fd), "/node/bin/node", "--jitless", "--max-old-space-size=192",
                       "--check", "/workspace/site.js"]
            preflight = self._run(command, seccomp_fd)
            network_probe_code = "const n=require('net');try{const s=n.createConnection({host:'192.0.2.1',port:80});s.on('error',e=>process.exit(e.code==='EPERM'?0:9));setTimeout(()=>process.exit(8),300)}catch(e){process.exit(e.code==='EPERM'?0:9)}"
            node_index = command.index("/node/bin/node")
            probe_command = command[:node_index + 1] + ["--jitless", "--max-old-space-size=192", "-e", network_probe_code]
            probe = self._run(probe_command, seccomp_fd)
            passed = preflight.returncode == 0 and probe.returncode == 0
            report = BuildReport("passed" if passed else "failed", "bubblewrap+seccomp", passed,
                                 tuple(command), preflight.returncode if preflight.returncode else probe.returncode,
                                 (preflight.stdout + probe.stdout)[:self.max_output_bytes],
                                 (preflight.stderr + probe.stderr)[:self.max_output_bytes],
                                 int((time.monotonic() - start) * 1000))
            if passed:
                self._validate_static_files(site_dir)
            return report
        except (NotReady, ValidationError, OSError, subprocess.SubprocessError) as exc:
            return BuildReport("blocked", "fail_closed", False, (), -1, "", str(exc)[:self.max_output_bytes],
                               int((time.monotonic() - start) * 1000))
        finally:
            if seccomp_fd >= 0:
                os.close(seccomp_fd)

    def _run(self, command: list[str], seccomp_fd: int) -> subprocess.CompletedProcess[str]:
        os.lseek(seccomp_fd, 0, os.SEEK_SET)
        def limits() -> None:
            resource.setrlimit(resource.RLIMIT_CPU, (self.timeout_seconds, self.timeout_seconds + 1))
            resource.setrlimit(resource.RLIMIT_AS, (self.memory_limit_bytes, self.memory_limit_bytes))
            resource.setrlimit(resource.RLIMIT_FSIZE, (20 * 1024 * 1024, 20 * 1024 * 1024))
            resource.setrlimit(resource.RLIMIT_NOFILE, (64, 64))
            ctypes.CDLL(None).prctl(38, 1, 0, 0, 0)  # PR_SET_NO_NEW_PRIVS
        return subprocess.run(command, pass_fds=(seccomp_fd,), close_fds=True, stdin=subprocess.DEVNULL,
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                              timeout=self.timeout_seconds, check=False, preexec_fn=limits,
                              env={"PATH": "/usr/bin"})

    @staticmethod
    def _validate_static_files(site_dir: Path) -> None:
        from html.parser import HTMLParser
        class CheckHTML(HTMLParser):
            pass
        documents = list(site_dir.glob("*.html"))
        if not documents:
            raise ValidationError("Static website has no HTML pages")
        for document in documents:
            parser = CheckHTML(convert_charrefs=True)
            parser.feed(document.read_text(encoding="utf-8"))
            parser.close()
        for path in site_dir.rglob("*"):
            if path.is_file() and path.stat().st_size > 20 * 1024 * 1024:
                raise ValidationError("Generated artifact exceeds the sandbox file-size policy")


class LocalPreviewServer:
    """Loopback-only static preview. It never imports or executes the site source in the factory process."""

    def __init__(self, site_dir: Path) -> None:
        self.site_dir = site_dir.resolve()
        handler = lambda *args, **kwargs: SimpleHTTPRequestHandler(*args, directory=str(self.site_dir), **kwargs)
        self.server = ThreadingHTTPServer(("127.0.0.1", 0), handler)
        self.server.daemon_threads = True
        self.thread = threading.Thread(target=self.server.serve_forever, name="fif-loopback-preview", daemon=True)

    def __enter__(self) -> str:
        self.thread.start()
        return f"http://127.0.0.1:{self.server.server_port}/"

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)


class BrowserInspector:
    """Playwright checks real DOM/render behavior and blocks browser requests outside loopback."""

    def __init__(self, chromium_executable: str | None = None) -> None:
        self.chromium_executable = chromium_executable or os.environ.get("PLAYWRIGHT_CHROMIUM_EXECUTABLE")

    async def inspect(self, base_url: str, site_dir: Path, screenshots_dir: Path) -> dict[str, Any]:
        screenshots_dir.mkdir(parents=True, exist_ok=True)
        result: dict[str, Any] = {"contract_version": QA_REPORT_VERSION, "status": "not_executed",
                                  "executed": False, "viewports": [], "console_errors": [],
                                  "page_errors": [], "blocked_external_requests": [], "checks": [],
                                  "screenshots": [], "limitations": []}
        try:
            from playwright.async_api import async_playwright
        except ImportError:
            result["limitations"].append("Python Playwright is not installed")
            return result
        async with async_playwright() as playwright:
            try:
                browser = await playwright.chromium.launch(
                    headless=True,
                    executable_path=self.chromium_executable,
                    args=["--no-sandbox"],
                )
            except Exception as exc:
                result["limitations"].append(f"Chromium launch blocked: {type(exc).__name__}: {str(exc)[:300]}")
                return result
            result["executed"] = True
            external = result["blocked_external_requests"]
            for name, width, height, reduced in (("desktop", 1440, 900, "no-preference"), ("mobile", 390, 844, "reduce")):
                context = await browser.new_context(viewport={"width": width, "height": height}, reduced_motion=reduced,
                                                    service_workers="block", java_script_enabled=True)
                page = await context.new_page()
                page.on("console", lambda message, target=result["console_errors"]: target.append(message.text) if message.type == "error" else None)
                page.on("pageerror", lambda error, target=result["page_errors"]: target.append(str(error)))
                origin = urlparse(base_url).netloc
                async def network_policy(route: Any) -> None:
                    if urlparse(route.request.url).netloc != origin and urlparse(route.request.url).scheme not in {"data", "about"}:
                        external.append(route.request.url)
                        await route.abort()
                    else:
                        await route.continue_()
                await page.route("**/*", network_policy)
                response = await page.goto(base_url, wait_until="networkidle", timeout=15_000)
                screenshot = screenshots_dir / f"{name}-1440x900.png" if name == "desktop" else screenshots_dir / f"{name}-390x844.png"
                await page.screenshot(path=str(screenshot), full_page=False, animations="disabled")
                dimensions = await page.evaluate("({width:innerWidth,height:innerHeight,documentWidth:document.documentElement.scrollWidth,bodyWidth:document.body.scrollWidth})")
                result["viewports"].append({"name": name, "width": width, "height": height,
                                            "reduced_motion": reduced == "reduce", "dimensions": dimensions})
                result["checks"].append({"name": f"{name}_http", "passed": bool(response and response.ok), "status": response.status if response else None})
                result["checks"].append({"name": f"{name}_no_horizontal_overflow", "passed": dimensions["documentWidth"] <= width and dimensions["bodyWidth"] <= width, "details": dimensions})
                result["checks"].append({"name": f"{name}_reduced_motion", "passed": await page.evaluate("matchMedia('(prefers-reduced-motion: reduce)').matches") == (reduced == "reduce")})
                if name == "desktop":
                    await page.get_by_role("link", name="Services", exact=True).click()
                    result["checks"].append({"name": "navigation_services", "passed": "services" in page.url and await page.locator("h1").count() == 1})
                    await page.get_by_role("link", name="Contact", exact=True).click()
                    await page.get_by_label("Votre nom").fill("Test local")
                    await page.get_by_label("Votre email").fill("test@example.invalid")
                    await page.get_by_label("Votre demande").fill("Soumission locale de test")
                    await page.get_by_role("button", name="Préparer la demande").click()
                    result["checks"].append({"name": "contact_form_local_only", "passed": "Aucun envoi externe" in await page.locator(".form-status").inner_text()})
                else:
                    await page.get_by_role("button", name="Menu").click()
                    result["checks"].append({"name": "mobile_navigation_toggle", "passed": await page.get_by_role("button", name="Menu").get_attribute("aria-expanded") == "true"})
                result["screenshots"].append({"path": str(screenshot), "viewport": f"{width}x{height}", "captured": True})
                await context.close()
            await browser.close()
        failed = [x for x in result["checks"] if not x["passed"]]
        result["status"] = "passed" if not failed and not result["console_errors"] and not result["page_errors"] and not external else "failed"
        return result


class VersionManager:
    def __init__(self, store: Store) -> None:
        self.store = store

    def snapshot(self, project_id: str, manifest: dict[str, Any], parent_id: str | None = None) -> dict[str, Any]:
        return self.store.create_version(project_id, manifest, parent_id)

    def restore_copy(self, version_manifest: dict[str, Any], destination: Path) -> dict[str, Any]:
        source = Path(str(version_manifest.get("artifact_root", ""))).resolve()
        destination = destination.resolve()
        if not source.is_dir() or destination.exists():
            raise ValidationError("Version source is missing or restore destination already exists")
        shutil.copytree(source, destination)
        return {"status": "restored_copy", "source": str(source), "destination": str(destination),
                "version_id": version_manifest.get("version_id")}


class ProductionPipeline:
    """Fixture plumbing and an explicitly budget-gated real-blueprint production path."""

    def __init__(self, store: Store, *, sandbox: BuildSandbox | None = None, inspector: BrowserInspector | None = None,
                 builder: WebsiteBuilder | None = None, immersion_runtime: ImmersionArchitectRuntime | None = None,
                 image_factory: OriginalImageFactory | None = None, artifact_root: Path | None = None) -> None:
        self.store = store
        self.sandbox = sandbox or BuildSandbox()
        self.inspector = inspector or BrowserInspector()
        self.builder = builder or WebsiteBuilder()
        self.immersion_runtime = immersion_runtime or ImmersionArchitectRuntime()
        self.image_factory = image_factory
        self.artifact_root = artifact_root.resolve() if artifact_root else None
        self.versions = VersionManager(store)

    async def run_generated(self, project_id: str, job_id: str, blueprint: dict[str, Any]) -> dict[str, Any]:
        """Run the visual stages for a genuine blueprint; defaults to a zero-cost provider gate."""
        generation = blueprint.get("generation", {})
        if blueprint.get("contract_version") != "fabrya.creative-blueprint/v1" or str(generation.get("provider", "")).startswith("offline_fixture"):
            raise ValidationError("Production pipeline requires a non-fixture creative blueprint")
        if self.artifact_root is None:
            raise NotReady("Production artifact storage is not configured")
        artifact_root = self.artifact_root / project_id / job_id
        artifact_root.mkdir(parents=True, exist_ok=True)
        self.store.add_checkpoint(job_id, "creative_blueprint_ready", "completed", {
            "generation_id": generation.get("generation_id"), "contract_version": blueprint["contract_version"],
            "provider": generation.get("provider"),
        })
        factory = self.image_factory
        if factory is None:
            factory = OriginalImageFactory(self.store, artifact_root, enabled=False)
        media_plan = factory.plan(blueprint)
        (artifact_root / "media-plan.json").write_text(
            json.dumps(media_plan.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")
        self.store.add_checkpoint(job_id, "media_plan_created", "completed", {
            "contract_version": MEDIA_PLAN_VERSION, "asset_count": len(media_plan.assets),
            "stock_media_used": False, "provider_calls": 0,
        })
        if (not factory.enabled or factory.provider is None or factory.generation_budget_micros <= 0
                or factory.per_image_reservation_micros <= 0):
            self.store.add_checkpoint(job_id, "visual_assets", "blocked", {
                "reason": "provider_disabled_or_budget_zero", "provider_calls": 0,
            })
            self.store.transition_job(job_id, "blocked", "waiting_for_image_provider_and_budget",
                error_code="IMAGE_PROVIDER_DISABLED_OR_BUDGET_ZERO", result={
                    "fixture_only": False, "creative_blueprint_ready": True, "visual_assets": False,
                    "website_built": False, "provider_calls": 0, "public_deployment": False,
                })
            return {"job_status": "blocked", "stage": "visual_assets", "provider_calls": 0,
                    "media_plan_path": str(artifact_root / "media-plan.json")}

        media: list[dict[str, Any]] = []
        try:
            for planned in media_plan.assets:
                for variant in ("desktop", "mobile"):
                    asset = await factory.generate_variant(project_id, job_id, planned, variant)
                    media.append(asset)
                    self.store.add_checkpoint(job_id, "visual_asset_saved", "completed", {
                        "asset_id": planned.asset_id, "variant": variant, "media_id": asset["id"],
                        "source_kind": "generated", "sha256": asset["sha256"],
                        "estimated_cost_micros": asset["estimated_cost_micros"],
                    })
        except (NotReady, BudgetExceeded) as exc:
            self.store.add_checkpoint(job_id, "visual_assets", "blocked", {
                "reason": type(exc).__name__, "provider_calls_with_results": len(media),
            })
            if self.store.get_job(project_id, job_id)["status"] == "running":
                self.store.transition_job(job_id, "blocked", "visual_asset_generation_blocked",
                                          error_code="IMAGE_GENERATION_BLOCKED")
            return {"job_status": "blocked", "stage": "visual_assets", "reason": type(exc).__name__,
                    "provider_calls_with_results": len(media)}
        except Exception as exc:
            self.store.add_checkpoint(job_id, "visual_assets", "failed", {
                "reason": type(exc).__name__, "provider_calls_with_results": len(media),
                "automatic_retry": False,
            })
            if self.store.get_job(project_id, job_id)["status"] == "running":
                self.store.transition_job(job_id, "failed", "visual_asset_generation_failed",
                                          error_code="IMAGE_GENERATION_OUTCOME_UNKNOWN")
            return {"job_status": "failed", "stage": "visual_assets", "reason": type(exc).__name__,
                    "provider_calls_with_results": len(media)}

        self.store.add_checkpoint(job_id, "visual_assets_ready", "completed", {
            "media_count": len(media), "provider_calls": len(media),
        })
        site_plan = site_plan_from_blueprint(blueprint)
        (artifact_root / "site-plan.json").write_text(json.dumps(site_plan, ensure_ascii=False, indent=2), encoding="utf-8")
        self.store.add_checkpoint(job_id, "site_plan_created", "completed", {
            "contract_version": SITE_PLAN_VERSION, "page_count": len(site_plan["pages"]),
        })
        immersion = self.immersion_runtime.compile(blueprint, media)
        (artifact_root / "immersion-runtime.json").write_text(json.dumps(immersion, ensure_ascii=False, indent=2), encoding="utf-8")
        self.store.add_checkpoint(job_id, "immersion_runtime_compiled", "completed", {
            "contract_version": IMMERSION_RUNTIME_VERSION, "effect_count": len(immersion["effects"]),
            "three_d_status": immersion["three_d"]["status"],
        })
        site_dir = artifact_root / "site"
        site_manifest = self.builder.build(site_plan, immersion, media, site_dir)
        self.store.add_checkpoint(job_id, "website_source_built", "completed", {
            "file_count": len(site_manifest["files"]) + len(site_manifest["assets"]),
            "source_framework": site_manifest["source_framework"], "network_dependencies": 0,
        })
        build_report = self.sandbox.build(site_dir)
        (artifact_root / "sandbox-report.json").write_text(json.dumps(build_report.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")
        self.store.add_checkpoint(job_id, "sandbox_build", build_report.status, {
            "sandbox": build_report.sandbox, "network_denied": build_report.network_denied,
            "return_code": build_report.return_code,
        })
        if build_report.status != "passed":
            self.store.transition_job(job_id, "blocked", "sandbox_build_blocked", error_code="SANDBOX_BUILD_NOT_VERIFIED")
            return {"job_status": "blocked", "stage": "sandbox", "sandbox_status": build_report.status}
        with LocalPreviewServer(site_dir) as preview_url:
            qa = await self.inspector.inspect(preview_url, site_dir, artifact_root / "screenshots")
        (artifact_root / "visual-qa.json").write_text(json.dumps(qa, ensure_ascii=False, indent=2), encoding="utf-8")
        self.store.add_checkpoint(job_id, "browser_qa", qa["status"], {
            "executed": qa["executed"], "checks": qa.get("checks", []), "screenshots": qa.get("screenshots", []),
            "limitations": qa.get("limitations", []),
        })
        versions = self.store.list_versions(project_id)
        parent_id = str(versions[0]["id"]) if versions else None
        manifest = {"schema": "fabrya.production-version/v1", "job_id": job_id,
                    "blueprint_generation_id": generation.get("generation_id"),
                    "blueprint_version": blueprint["contract_version"], "fixture": False,
                    "artifact_root": str(artifact_root), "site_root": str(site_dir),
                    "media_ids": [item["id"] for item in media], "sandbox_status": build_report.status,
                    "browser_qa_status": qa["status"], "browser_qa_executed": qa["executed"],
                    "public_deployment": False}
        version = self.versions.snapshot(project_id, manifest, parent_id)
        manifest.update({"version_id": version["id"], "version_number": version["version_number"]})
        (artifact_root / "version-manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
        self.store.add_checkpoint(job_id, "version_created", "completed", {"version_id": version["id"], "version_number": version["version_number"]})
        if qa["status"] == "passed" and qa["executed"] is True:
            self.store.transition_job(job_id, "completed", "production_pipeline_verified", result={
                "fixture_only": False, "creative_blueprint_ready": True, "visual_assets": True,
                "website_built": True, "sandbox_status": "passed", "browser_qa": "passed",
                "browser_qa_executed": True, "version_id": version["id"], "public_deployment": False,
            })
        else:
            self.store.transition_job(job_id, "blocked", "browser_qa_not_verified", error_code="BROWSER_QA_NOT_EXECUTED")
        return {"job_status": self.store.get_job(project_id, job_id)["status"], "fixture_only": False,
                "sandbox_status": build_report.status, "browser_qa": qa["status"], "version": version,
                "artifact_root": str(artifact_root)}

    async def run_fixture(self, project_id: str, job_id: str, blueprint: dict[str, Any], artifact_root: Path,
                          *, browser_qa: bool = True) -> dict[str, Any]:
        if not str(blueprint.get("generation", {}).get("provider", "")).startswith("offline_fixture"):
            raise ValidationError("This plumbing runner only accepts explicitly identified offline fixtures")
        if blueprint.get("contract_version") != "fabrya.creative-blueprint/v1":
            raise ValidationError("Fixture blueprint contract mismatch")
        claimed = self.store.claim_next_job()
        if not claimed or str(claimed["id"]) != job_id:
            raise Conflict("Plumbing demo requires its existing queued job to be claimed first")
        artifact_root = artifact_root.resolve()
        artifact_root.mkdir(parents=True, exist_ok=True)
        self.store.add_checkpoint(job_id, "fixture_blueprint_loaded", "completed", {
            "fixture": True, "provider": blueprint["generation"]["provider"],
            "contract_version": blueprint["contract_version"], "external_provider_calls": 0})
        self.store.save_creative_blueprint(project_id, job_id, str(blueprint["generation"]["generation_id"]),
            str(blueprint["contract_version"]), str(blueprint["generation"]["brief_sha256"]), blueprint)

        media_factory = OriginalImageFactory(self.store, artifact_root, enabled=False)
        media_plan = media_factory.plan(blueprint)
        plan_dict = media_plan.to_dict()
        (artifact_root / "media-plan.json").write_text(json.dumps(plan_dict, ensure_ascii=False, indent=2), encoding="utf-8")
        self.store.add_checkpoint(job_id, "media_plan_created", "completed", {
            "contract_version": MEDIA_PLAN_VERSION, "asset_count": len(media_plan.assets),
            "fixture": True, "image_api_calls": 0, "stock_media_used": False})
        media = []
        for item in media_plan.assets:
            media.append(media_factory.fixture_asset(project_id, job_id, item, "desktop"))
            media.append(media_factory.fixture_asset(project_id, job_id, item, "mobile"))
        self.store.add_checkpoint(job_id, "fixture_media_saved", "completed", {
            "media_count": len(media), "source_kind": "fixture", "client_use_allowed": False,
            "original_media_saved": True})

        site_plan = site_plan_from_blueprint(blueprint)
        (artifact_root / "site-plan.json").write_text(json.dumps(site_plan, ensure_ascii=False, indent=2), encoding="utf-8")
        self.store.add_checkpoint(job_id, "site_plan_created", "completed", {
            "contract_version": SITE_PLAN_VERSION, "page_count": len(site_plan["pages"]), "fixture": True})

        immersion = self.immersion_runtime.compile(blueprint, media)
        (artifact_root / "immersion-runtime.json").write_text(json.dumps(immersion, ensure_ascii=False, indent=2), encoding="utf-8")
        self.store.add_checkpoint(job_id, "immersion_runtime_compiled", "completed", {
            "contract_version": IMMERSION_RUNTIME_VERSION, "effect_count": len(immersion["effects"]),
            "three_d_status": immersion["three_d"]["status"], "fixture": True})

        site_dir = artifact_root / "site"
        site_manifest = self.builder.build(site_plan, immersion, media, site_dir)
        self.store.add_checkpoint(job_id, "website_source_built", "completed", {
            "file_count": len(site_manifest["files"]) + len(site_manifest["assets"]),
            "source_framework": site_manifest["source_framework"], "fixture": True,
            "network_dependencies": 0, "form_mode": site_manifest["form_mode"]})
        build_report = self.sandbox.build(site_dir)
        (artifact_root / "sandbox-report.json").write_text(json.dumps(build_report.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")
        self.store.add_checkpoint(job_id, "sandbox_build", build_report.status, {
            "sandbox": build_report.sandbox, "network_denied": build_report.network_denied,
            "return_code": build_report.return_code, "elapsed_ms": build_report.elapsed_ms})

        if browser_qa and build_report.status == "passed":
            with LocalPreviewServer(site_dir) as preview_url:
                qa = await self.inspector.inspect(preview_url, site_dir, artifact_root / "screenshots")
        else:
            qa = {"contract_version": QA_REPORT_VERSION, "status": "not_executed", "executed": False,
                  "viewports": [], "checks": [], "console_errors": [], "page_errors": [], "screenshots": [],
                  "limitations": ["Browser QA disabled or sandbox build not passed"]}
        (artifact_root / "visual-qa.json").write_text(json.dumps(qa, ensure_ascii=False, indent=2), encoding="utf-8")
        self.store.add_checkpoint(job_id, "browser_qa", str(qa["status"]), {
            "executed": qa["executed"], "status": qa["status"], "screenshots": qa.get("screenshots", []),
            "check_count": len(qa.get("checks", [])), "limitations": qa.get("limitations", [])})

        existing = self.store.list_versions(project_id)
        parent_id = str(existing[0]["id"]) if existing else None
        version_manifest = {"schema": "fabrya.production-version/v1", "job_id": job_id,
                           "blueprint_generation_id": blueprint["generation"]["generation_id"],
                           "blueprint_version": blueprint["contract_version"], "fixture": True,
                           "artifact_root": str(artifact_root), "site_root": str(site_dir),
                           "media_ids": [str(x["id"]) for x in media], "sandbox_status": build_report.status,
                           "browser_qa_status": qa["status"], "browser_qa_executed": qa["executed"],
                           "external_provider_calls": 0, "public_deployment": False}
        version = self.versions.snapshot(project_id, version_manifest, parent_id)
        version_manifest.update({"version_id": version["id"], "version_number": version["version_number"]})
        (artifact_root / "version-manifest.json").write_text(json.dumps(version_manifest, ensure_ascii=False, indent=2), encoding="utf-8")
        self.store.add_checkpoint(job_id, "version_created", "completed", {
            "version_id": version["id"], "version_number": version["version_number"],
            "fixture": True, "restore_supported_as_copy": True})

        complete = build_report.status == "passed" and qa["status"] == "passed" and qa["executed"] is True
        if complete:
            status, stage, error_code = "completed", "fixture_plumbing_verified", None
        elif build_report.status != "passed":
            status, stage, error_code = "blocked", "sandbox_not_available_or_failed", "SANDBOX_BUILD_NOT_VERIFIED"
        elif not qa["executed"]:
            status, stage, error_code = "blocked", "browser_qa_not_executed", "BROWSER_QA_NOT_EXECUTED"
        else:
            status, stage, error_code = "failed", "browser_qa_failed", "BROWSER_QA_FAILED"
        result = {"fixture_only": True, "artistic_generation_proven": False, "image_generation": False,
                  "website_built": True, "sandbox_status": build_report.status, "browser_qa": qa["status"],
                  "browser_qa_executed": qa["executed"], "version_id": version["id"], "public_deployment": False,
                  "cost_usd": 0.0}
        self.store.transition_job(job_id, status, stage, error_code=error_code, result=result)
        report = {"schema": "fabrya.phase-c-plumbing-report/v1", "job_id": job_id, "project_id": project_id,
                  "fixture_only": True, "fixture_provider": blueprint["generation"]["provider"],
                  "steps": {"creative_blueprint": "fixture_loaded", "media_plan": "passed", "fixture_media": "saved",
                            "immersion_runtime": "compiled", "site_plan": "passed", "website_build": "passed",
                            "sandbox": build_report.status, "browser_qa": qa["status"], "version": "saved"},
                  "media_count": len(media), "site_manifest": site_manifest, "build_report": build_report.to_dict(),
                  "qa_report": qa, "version": version, "job_status": status,
                  "limitations": ["No OpenAI or image API call", "Fixture artwork is explicitly watermarked and not for client use",
                                  "No autonomous visual quality claim", "No public deployment"]}
        (artifact_root / "phase-c-report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        return report
