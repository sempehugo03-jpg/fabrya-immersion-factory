from __future__ import annotations

import json
from typing import Any

from .errors import ValidationError

BLUEPRINT_VERSION = "fabrya.creative-blueprint/v1"


def _str() -> dict[str, object]:
    # String length bounds are enforced by local validation; omit nonessential keywords
    # from the provider schema to stay inside the documented Structured Outputs subset.
    return {"type": "string"}


def _array(items: dict[str, object], minimum: int = 0, maximum: int = 20) -> dict[str, object]:
    return {"type": "array", "items": items, "minItems": minimum, "maxItems": maximum}


def _object(properties: dict[str, object]) -> dict[str, object]:
    return {"type": "object", "properties": properties, "required": list(properties), "additionalProperties": False}


S = _str()
STRING_LIST = _array(S, 0, 20)
CREATIVE_OUTPUT_SCHEMA: dict[str, object] = _object({
    "contract_version": {"type": "string", "enum": [BLUEPRINT_VERSION]},
    "analysis": _object({
        "business_profile": _object({
            "company_name": S,
            "industry": S,
            "offerings": STRING_LIST,
            "positioning": S,
            "facts_from_brief": STRING_LIST,
            "assumptions": STRING_LIST,
            "missing_information": STRING_LIST,
        }),
        "target_audience": STRING_LIST,
        "conversion_goals": STRING_LIST,
        "visual_constraints": STRING_LIST,
        "client_assets": _array(_object({
            "description": S,
            "status": {"type": "string", "enum": ["provided_by_client", "client_authorized", "needs_authentic_reference", "not_provided"]},
            "intended_use": S,
        }), 0, 20),
    }),
    "art_direction": _object({
        "concept_title": S,
        "central_concept": S,
        "business_fit_rationale": S,
        "atmosphere": S,
        "palette": _array(_object({"name": S, "hex": {"type": "string", "pattern": "^#[0-9A-Fa-f]{6}$"}, "role": S}), 3, 8),
        "typography_direction": S,
        "composition": S,
        "photography_direction": _object({
            "style": S,
            "framing": S,
            "lighting": S,
            "materials": S,
            "authenticity_rules": STRING_LIST,
        }),
        "narrative": S,
        "page_hierarchy": _array(_object({"page": S, "purpose": S, "visual_role": S}), 1, 12),
        "originality_guardrails": STRING_LIST,
    }),
    "immersion": _object({
        "signature_moment": S,
        "depth_model": S,
        "interactions": _array(_object({
            "name": S,
            "trigger": S,
            "behavior": S,
            "rationale": S,
            "mobile_behavior": S,
            "reduced_motion_behavior": S,
            "performance_cost": {"type": "string", "enum": ["low", "medium", "high"]},
        }), 1, 10),
        "three_d_decision": _object({"use_webgl": {"type": "boolean"}, "rationale": S, "fallback": S}),
        "transition_plan": STRING_LIST,
        "mobile_adaptation": STRING_LIST,
        "reduced_motion_plan": S,
        "performance_constraints": STRING_LIST,
    }),
    "visual_plan": _object({
        "global_consistency_rules": STRING_LIST,
        "external_stock_media_allowed": {"type": "boolean", "enum": [False]},
        "assets": _array(_object({
            "asset_id": S,
            "role": S,
            "representation": {"type": "string", "enum": ["conceptual_generated_visual", "client_authentic_media"]},
            "subject_and_content": S,
            "composition": S,
            "desktop_framing": S,
            "mobile_framing": S,
            "lighting": S,
            "format": S,
            "continuity_notes": S,
            "generation_prompt": S,
            "authentic_reference_required": {"type": "boolean"},
            "authenticity_note": S,
        }), 1, 20),
    }),
})

_creative_properties = CREATIVE_OUTPUT_SCHEMA["properties"]
assert isinstance(_creative_properties, dict)
_decision_properties = {key: value for key, value in _creative_properties.items() if key != "contract_version"}
BLUEPRINT_JSON_SCHEMA: dict[str, object] = _object({
    "contract_version": {"type": "string", "enum": [BLUEPRINT_VERSION]},
    "generation": _object({
        "generation_id": S,
        "generated_at": S,
        "model": S,
        "sdk_version": S,
        "provider": {"type": "string", "enum": ["openai", "offline_fixture"]},
        "response_id": S,
        "request_id": S,
        "brief_sha256": {"type": "string", "pattern": "^[0-9a-f]{64}$"},
        "prompt_version": {"type": "string", "enum": ["fabrya.creative-director/v1"]},
        "input_tokens": {"type": "integer", "minimum": 0},
        "output_tokens": {"type": "integer", "minimum": 0},
        "estimated_cost_micros_usd": {"type": "integer", "minimum": 0},
    }),
    "decisions": _object(_decision_properties),
})


def validate_model_decisions(value: object) -> dict[str, Any]:
    """Validate only the JSON body returned by OpenAI before adding trusted metadata."""
    errors: list[str] = []
    _validate(value, CREATIVE_OUTPUT_SCHEMA, "$", errors)
    if errors:
        raise ValidationError("Creative decisions do not match v1 schema: " + "; ".join(errors[:8]))
    return value  # type: ignore[return-value]


def assemble_blueprint(decisions: dict[str, Any], generation: dict[str, Any]) -> dict[str, Any]:
    clean_decisions = {key: value for key, value in decisions.items() if key != "contract_version"}
    blueprint = {"contract_version": BLUEPRINT_VERSION, "generation": generation, "decisions": clean_decisions}
    errors: list[str] = []
    _validate(blueprint, BLUEPRINT_JSON_SCHEMA, "$", errors)
    if errors:
        raise ValidationError("Stored creative blueprint does not match v1 schema: " + "; ".join(errors[:8]))
    return blueprint


def _validate(value: object, schema: dict[str, object], path: str, errors: list[str]) -> None:
    kind = schema.get("type")
    types = {"object": dict, "array": list, "string": str, "boolean": bool, "integer": int}
    expected = types.get(str(kind))
    if expected is not None and (not isinstance(value, expected) or (kind in {"boolean", "integer"} and type(value) is not expected)):
        errors.append(f"{path} must be {kind}")
        return
    enum = schema.get("enum")
    if isinstance(enum, list) and value not in enum:
        errors.append(f"{path} is outside the allowed values")
    if isinstance(value, str):
        if len(value) < int(schema.get("minLength", 1)) or len(value) > int(schema.get("maxLength", 5000)):
            errors.append(f"{path} has an invalid length")
        pattern = schema.get("pattern")
        if isinstance(pattern, str):
            import re
            if re.fullmatch(pattern, value) is None:
                errors.append(f"{path} has an invalid format")
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        if "minimum" in schema and value < schema["minimum"]:
            errors.append(f"{path} is below its minimum")
    if isinstance(value, list):
        if len(value) < int(schema.get("minItems", 0)) or len(value) > int(schema.get("maxItems", 1_000_000)):
            errors.append(f"{path} has an invalid item count")
        item_schema = schema.get("items")
        if isinstance(item_schema, dict):
            for index, item in enumerate(value):
                _validate(item, item_schema, f"{path}[{index}]", errors)
                if len(errors) >= 32:
                    return
    if isinstance(value, dict):
        properties = schema.get("properties", {})
        required = schema.get("required", [])
        if isinstance(properties, dict):
            for key in required if isinstance(required, list) else []:
                if key not in value:
                    errors.append(f"{path}.{key} is required")
            if schema.get("additionalProperties") is False:
                extras = set(value) - set(properties)
                if extras:
                    errors.append(f"{path} has unsupported keys: {', '.join(sorted(map(str, extras))[:4])}")
            for key, item in value.items():
                child = properties.get(key)
                if isinstance(child, dict):
                    _validate(item, child, f"{path}.{key}", errors)
                    if len(errors) >= 32:
                        return


def schema_as_json() -> str:
    return json.dumps(BLUEPRINT_JSON_SCHEMA, ensure_ascii=False, separators=(",", ":"))
