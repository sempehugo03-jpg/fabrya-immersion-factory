from __future__ import annotations

from dataclasses import dataclass

from .errors import BudgetExceeded, ValidationError
from .store import Store


@dataclass(frozen=True, slots=True)
class CostReservation:
    event_id: str
    reserved_micros: int
    remaining_micros: int


class CostSupervisor:
    """Fail-closed budget accounting. Provider token charges are estimated from usage and a rate snapshot."""

    def __init__(self, store: Store) -> None:
        self.store = store

    def reserve(self, project_id: str, job_id: str, provider: str, operation: str, estimated_micros: int) -> CostReservation:
        if estimated_micros <= 0:
            raise ValidationError("A positive cost estimate is required")
        limit = self.store.project_budget(project_id)
        used = self.store.budget_usage(project_id, job_id)
        if estimated_micros > limit - used:
            raise BudgetExceeded("Generation budget is absent or insufficient")
        event_id = self.store.add_cost_event(project_id, job_id, provider, operation, estimated_micros)
        return CostReservation(event_id, estimated_micros, limit - used - estimated_micros)

    def settle(self, reservation: CostReservation, actual_micros: int) -> None:
        if actual_micros < 0:
            raise ValidationError("Actual cost cannot be negative")
        self.store.settle_cost_event(reservation.event_id, actual_micros)
        if actual_micros > reservation.reserved_micros:
            raise BudgetExceeded("Actual cost exceeded its reservation; actual usage has been recorded")

    def settle_estimate(self, reservation: CostReservation, estimated_micros: int) -> None:
        if estimated_micros < 0:
            raise ValidationError("Estimated cost cannot be negative")
        self.store.settle_cost_event(reservation.event_id, estimated_micros=estimated_micros)
        if estimated_micros > reservation.reserved_micros:
            raise BudgetExceeded("Estimated cost exceeded its reservation; usage has been recorded")

    def release(self, reservation: CostReservation) -> None:
        self.store.release_cost_event(reservation.event_id)

