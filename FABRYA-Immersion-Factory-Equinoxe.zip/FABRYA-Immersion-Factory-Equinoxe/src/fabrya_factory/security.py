from __future__ import annotations

import hashlib
import hmac
import secrets

from .errors import Unauthorized


def new_project_token() -> str:
    return "fif_" + secrets.token_urlsafe(32)


def token_digest(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def token_matches(token: str, expected_digest: str) -> bool:
    return hmac.compare_digest(token_digest(token), expected_digest)


def parse_bearer(header: str | None) -> str:
    if not header or not header.startswith("Bearer "):
        raise Unauthorized("A bearer token is required")
    token = header[7:].strip()
    if not token or len(token) > 512:
        raise Unauthorized("Invalid bearer token")
    return token


def authorize_bootstrap(token: str, expected: str) -> None:
    if not expected or not hmac.compare_digest(token, expected):
        raise Unauthorized("Invalid bootstrap credential")

