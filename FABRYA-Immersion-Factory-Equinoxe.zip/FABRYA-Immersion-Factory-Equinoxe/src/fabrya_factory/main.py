from __future__ import annotations

import logging
from socketserver import ThreadingMixIn
from wsgiref.simple_server import WSGIServer, make_server

from .api import FactoryApi, wsgi_app
from .config import Settings
from .orchestrator import GenerationOrchestrator, Worker
from .openai_provider import OpenAICreativeProvider
from .production import OpenAIImageProvider, OriginalImageFactory, ProductionPipeline
from .store import Store


class ThreadedServer(ThreadingMixIn, WSGIServer):
    daemon_threads = True
    allow_reuse_address = True


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    settings = Settings.from_env()
    if not settings.bootstrap_token:
        raise SystemExit("Set FACTORY_BOOTSTRAP_TOKEN before starting the API")
    store = Store(settings.data_dir / "factory.sqlite3")
    api = FactoryApi(settings, store)
    recovered, uncertain = store.recover_interrupted_jobs()
    if recovered or uncertain:
        logging.warning("Recovered jobs before provider calls: requeued=%d uncertain_attempts_failed_closed=%d", recovered, uncertain)
    provider = None
    if settings.openai_enabled and settings.generation_budget_micros > 0 and settings.openai_max_call_micros > 0:
        provider = OpenAICreativeProvider.from_env(model=settings.openai_model, timeout_seconds=settings.openai_timeout_seconds)
    image_provider = OpenAIImageProvider.from_env() if settings.image_generation_enabled else None
    image_factory = OriginalImageFactory(
        store,
        settings.data_dir / "generated-media",
        image_provider,
        enabled=settings.image_generation_enabled,
        generation_budget_micros=settings.image_generation_budget_micros,
        per_image_reservation_micros=settings.image_generation_max_call_micros,
    )
    production_pipeline = ProductionPipeline(
        store,
        image_factory=image_factory,
        artifact_root=settings.data_dir / "generated-sites",
    )
    worker = Worker(GenerationOrchestrator(
        store,
        provider_enabled=settings.openai_enabled,
        provider=provider,
        generation_budget_micros=settings.generation_budget_micros,
        max_call_micros=settings.openai_max_call_micros,
        production_pipeline=production_pipeline,
    ))
    worker.start()
    try:
        with make_server(settings.host, settings.port, wsgi_app(api), server_class=ThreadedServer) as server:
            logging.info("FABRYA Immersion Factory Phase A listening at %s:%s", settings.host, settings.port)
            server.serve_forever()
    finally:
        worker.stop()


if __name__ == "__main__":
    main()

