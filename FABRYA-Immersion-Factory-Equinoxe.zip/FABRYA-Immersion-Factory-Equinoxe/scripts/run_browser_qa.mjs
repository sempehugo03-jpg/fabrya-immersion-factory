import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const args = Object.fromEntries(process.argv.slice(2).map((item, index, values) =>
  item.startsWith('--') ? [item.slice(2), values[index + 1]] : null).filter(Boolean));
for (const required of ['site', 'screenshots', 'report']) {
  if (!args[required]) throw new Error(`Missing --${required}`);
}
const site = path.resolve(args.site);
const shots = path.resolve(args.screenshots);
const reportPath = path.resolve(args.report);
const entry = process.env.PLAYWRIGHT_JS_ENTRY;
if (!entry) throw new Error('Set PLAYWRIGHT_JS_ENTRY to the Playwright Node package index.js');
const { chromium } = await import(pathToFileURL(entry).href);
fs.mkdirSync(shots, { recursive: true });

const mime = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png',
  '.webp': 'image/webp', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg' };
const server = http.createServer((req, res) => {
  const url = new URL(req.url, 'http://127.0.0.1');
  const relative = decodeURIComponent(url.pathname === '/' ? '/index.html' : url.pathname);
  const file = path.resolve(site, `.${relative}`);
  if (file !== site && !file.startsWith(site + path.sep)) { res.writeHead(403).end(); return; }
  if (url.pathname === '/favicon.ico') { res.writeHead(204).end(); return; }
  fs.readFile(file, (error, content) => {
    if (error) { res.writeHead(error.code === 'ENOENT' ? 404 : 500).end(); return; }
    res.writeHead(200, { 'Content-Type': mime[path.extname(file)] ?? 'application/octet-stream',
      'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
    res.end(content);
  });
});

const result = { contract_version: 'fabrya.visual-qa/v1', status: 'failed', executed: false,
  engine: 'Playwright', browser_version: null, preview_scope: '127.0.0.1 ephemeral test server',
  viewports: [], console_errors: [], page_errors: [], blocked_external_requests: [], checks: [], screenshots: [], limitations: [] };
let browser;
try {
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const origin = `http://127.0.0.1:${server.address().port}`;
  browser = await chromium.launch({ headless: true, executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE,
    chromiumSandbox: true });
  result.browser_version = browser.version();
  result.preview_url = origin;
  result.executed = true;
  for (const [name, width, height, motion] of [['desktop', 1440, 900, 'no-preference'], ['mobile', 390, 844, 'reduce']]) {
    const context = await browser.newContext({ viewport: { width, height }, reducedMotion: motion, serviceWorkers: 'block' });
    const page = await context.newPage();
    page.on('console', msg => { if (msg.type() === 'error') result.console_errors.push(msg.text()); });
    page.on('pageerror', error => result.page_errors.push(String(error)));
    await page.route('**/*', async route => {
      if (new URL(route.request().url()).origin !== origin) {
        result.blocked_external_requests.push(route.request().url());
        await route.abort();
      } else await route.continue();
    });
    const response = await page.goto(`${origin}/`, { waitUntil: 'networkidle' });
    const dims = await page.evaluate(() => ({ width: innerWidth, height: innerHeight,
      documentWidth: document.documentElement.scrollWidth, bodyWidth: document.body.scrollWidth }));
    result.viewports.push({ name, width, height, reduced_motion: motion === 'reduce', dimensions: dims });
    result.checks.push({ name: `${name}_http`, passed: Boolean(response?.ok()), details: response?.status() });
    result.checks.push({ name: `${name}_exact_viewport`, passed: dims.width === width && dims.height === height, details: dims });
    result.checks.push({ name: `${name}_no_horizontal_overflow`, passed: dims.documentWidth <= width && dims.bodyWidth <= width, details: dims });
    result.checks.push({ name: `${name}_reduced_motion`, passed: await page.evaluate("matchMedia('(prefers-reduced-motion: reduce)').matches") === (motion === 'reduce') });
    const shot = path.join(shots, `${name}-${width}x${height}.png`);
    await page.screenshot({ path: shot, fullPage: false, animations: 'disabled' });
    result.screenshots.push({ path: shot, viewport: `${width}x${height}`, captured: true });
    if (name === 'desktop') {
      await page.getByRole('link', { name: 'Services', exact: true }).click();
      result.checks.push({ name: 'navigation_services', passed: page.url().endsWith('/services.html') && await page.locator('h1').count() === 1 });
      await page.getByRole('link', { name: 'Contact', exact: true }).click();
      await page.getByLabel('Votre nom').fill('Test local');
      await page.getByLabel('Votre email').fill('test@example.invalid');
      await page.getByLabel('Votre demande').fill('Test de parcours local');
      await page.getByRole('button', { name: 'Préparer la demande' }).click();
      result.checks.push({ name: 'contact_form_local_only', passed: (await page.locator('.form-status').innerText()).includes('Aucun envoi externe') });
    } else {
      await page.getByRole('button', { name: 'Menu' }).click();
      result.checks.push({ name: 'mobile_menu_toggle', passed: await page.getByRole('button', { name: 'Menu' }).getAttribute('aria-expanded') === 'true' });
      await page.getByRole('link', { name: 'Services', exact: true }).click();
      result.checks.push({ name: 'mobile_navigation_services', passed: page.url().endsWith('/services.html') });
    }
    await context.close();
  }
  const failures = result.checks.filter(item => !item.passed);
  result.status = failures.length === 0 && result.console_errors.length === 0 && result.page_errors.length === 0 && result.blocked_external_requests.length === 0 ? 'passed' : 'failed';
} catch (error) {
  result.limitations.push(`${error.name}: ${String(error.message).slice(0, 500)}`);
  result.status = result.executed ? 'failed' : 'not_executed';
} finally {
  if (browser) await browser.close();
  await new Promise(resolve => server.close(resolve));
  fs.mkdirSync(path.dirname(reportPath), { recursive: true });
  fs.writeFileSync(reportPath, JSON.stringify(result, null, 2));
}
console.log(JSON.stringify(result, null, 2));
if (result.status !== 'passed') process.exitCode = 1;
