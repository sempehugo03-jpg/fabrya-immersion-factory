"""Persist a separately executed, successful Playwright report into a fixture job."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

REPOSITORY = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPOSITORY / "src"))

from fabrya_factory.errors import Conflict, ValidationError
from fabrya_factory.store import Store


def persist(database: Path, project_id: str, job_id: str, artifact_root: Path, qa_path: Path) -> dict[str, object]:
    qa_bytes = qa_path.read_bytes()
    qa = json.loads(qa_bytes)
    if qa.get("contract_version") != "fabrya.visual-qa/v1" or qa.get("status") != "passed" or qa.get("executed") is not True:
        raise ValidationError("Only a real, passing Playwright report can complete this job")
    if not qa.get("checks") or any(not item.get("passed") for item in qa["checks"]):
        raise ValidationError("Playwright checks are missing or include failures")
    if qa.get("console_errors") or qa.get("page_errors") or qa.get("blocked_external_requests"):
        raise ValidationError("Browser QA reports console, page, or external-network errors")
    expected = {"1440x900", "390x844"}
    captures = {item.get("viewport") for item in qa.get("screenshots", []) if item.get("captured") is True}
    if captures != expected:
        raise ValidationError("Expected successful captures at 1440x900 and 390x844")
    for item in qa["screenshots"]:
        if not Path(item["path"]).is_file():
            raise ValidationError("A screenshot referenced by the report is missing")

    store = Store(database)
    job = store.get_job(project_id, job_id)
    if job["status"] == "completed" and job.get("result", {}).get("browser_qa") == "passed":
        return {"status": "already_completed", "job_id": job_id, "version_id": job["result"].get("version_id")}
    if job["status"] != "blocked" or job.get("error_code") != "BROWSER_QA_NOT_EXECUTED":
        raise Conflict("Job is not waiting for browser QA")

    op_key = "fixture-browser-qa-resume-v1"
    fingerprint = hashlib.sha256(qa_bytes).hexdigest()
    if not store.begin_factory_operation(project_id, job_id, op_key, "playwright", fingerprint):
        previous = store.get_factory_operation(project_id, job_id, op_key)
        if previous and previous["state"] == "succeeded":
            return {"status": "already_completed", "job_id": job_id, "result": previous.get("result")}
        raise Conflict("Browser QA persistence already started; no duplicate version will be created")

    artifact_root = artifact_root.resolve()
    version_file = artifact_root / "version-manifest.json"
    pipeline_file = artifact_root / "phase-c-report.json"
    version_manifest = json.loads(version_file.read_text(encoding="utf-8"))
    pipeline_report = json.loads(pipeline_file.read_text(encoding="utf-8"))
    if version_manifest.get("job_id") != job_id or pipeline_report.get("job_id") != job_id:
        raise ValidationError("Artifact manifests do not belong to this job")

    store.transition_job(job_id, "queued", "browser_qa_resume_queued")
    claimed = store.claim_job(job_id)
    if str(claimed["id"]) != job_id:
        raise Conflict("Claimed a different job")
    store.add_checkpoint(job_id, "browser_qa", "passed", {
        "executed": True, "engine": qa.get("engine"), "browser_version": qa.get("browser_version"),
        "viewports": qa.get("viewports"), "checks": qa.get("checks"), "screenshots": qa.get("screenshots"),
        "preview_scope": qa.get("preview_scope"), "provider_calls": 0,
    })

    existing = store.list_versions(project_id)
    if not existing:
        raise ValidationError("Initial build version is missing")
    updated_manifest = dict(version_manifest)
    updated_manifest.update({"browser_qa_status": "passed", "browser_qa_executed": True,
                            "browser_qa_report": str(qa_path.resolve()), "screenshots": qa["screenshots"]})
    version = store.create_version(project_id, updated_manifest, str(existing[0]["id"]))
    updated_manifest.update({"version_id": version["id"], "version_number": version["version_number"]})
    version_file.write_text(json.dumps(updated_manifest, ensure_ascii=False, indent=2), encoding="utf-8")

    pipeline_report["qa_report"] = qa
    pipeline_report["steps"]["browser_qa"] = "passed"
    pipeline_report["version"] = version
    pipeline_report["job_status"] = "completed"
    pipeline_report["limitations"] = [item for item in pipeline_report.get("limitations", []) if item != "Browser QA was not executed"]
    result = {"fixture_only": True, "artistic_generation_proven": False, "image_generation": False,
              "website_built": True, "sandbox_status": updated_manifest["sandbox_status"],
              "browser_qa": "passed", "browser_qa_executed": True, "version_id": version["id"],
              "public_deployment": False, "cost_usd": 0.0}
    store.transition_job(job_id, "completed", "fixture_plumbing_verified", result=result)
    checkpoints = store.list_checkpoints(job_id)
    checkpoints_file = artifact_root / "checkpoints.json"
    checkpoints_file.write_text(json.dumps(checkpoints, ensure_ascii=False, indent=2), encoding="utf-8")
    pipeline_report["checkpoints"] = checkpoints
    pipeline_report["checkpoints_path"] = str(checkpoints_file.resolve())
    pipeline_file.write_text(json.dumps(pipeline_report, ensure_ascii=False, indent=2), encoding="utf-8")
    store.finish_factory_operation(project_id, job_id, op_key, "succeeded", result={
        "version_id": version["id"], "version_number": version["version_number"],
        "browser_qa_status": "passed", "screenshot_count": len(qa["screenshots"]),
    })
    return {"status": "completed", "job_id": job_id, "version_id": version["id"],
            "version_number": version["version_number"], "screenshots": qa["screenshots"]}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--database", type=Path, required=True)
    parser.add_argument("--project-id", required=True)
    parser.add_argument("--job-id", required=True)
    parser.add_argument("--artifact-root", type=Path, required=True)
    parser.add_argument("--qa-report", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(persist(args.database, args.project_id, args.job_id,
                             args.artifact_root, args.qa_report), ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
