"""Run Atelier Équinoxe once and preserve the generated blueprint and evidence."""

from __future__ import annotations

import asyncio
import json
import os
from pathlib import Path

from fabrya_factory.openai_provider import OpenAICreativeProvider, maximum_reservation_micros
from fabrya_factory.orchestrator import GenerationOrchestrator
from fabrya_factory.security import new_project_token
from fabrya_factory.store import Store

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "artifacts" / "jalon1-live"
MODEL = "gpt-6.1-sol"
PROJECT = "proj_pNDB4OTGo6zwMdXlRB3bxtJh"
CAP_MICROS = 100_000
BRIEF = (
    "Entreprise fictive : Atelier Équinoxe, garage automobile premium. "
    "Entretien, préparation et restauration de véhicules sportifs et de collection. "
    "Positionnement : précision mécanique, savoir-faire, exclusivité et confiance. "
    "Objectif commercial : présenter les prestations et obtenir des demandes de rendez-vous ou de devis. "
    "Ambition : une expérience web cinématographique, élégante, visuellement remarquable "
    "et intelligemment immersive. Justifie tes choix et rédige le blueprint en français."
)


def write_json(name: str, value: object) -> None:
    (RUN / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


async def run() -> None:
    if RUN.exists():
        raise SystemExit("A live-run directory already exists. Inspect its evidence; never resubmit automatically.")
    if not os.environ.get("OPENAI_API_KEY", "").strip():
        raise SystemExit("Server OPENAI_API_KEY is missing.")
    if os.environ.get("OPENAI_PROJECT_ID") != PROJECT:
        raise SystemExit("OPENAI_PROJECT_ID must match the dedicated FABRYA project.")
    if os.environ.get("FACTORY_OPENAI_PLATFORM_LIMIT_VERIFIED") != "YES":
        raise SystemExit("Verify the current credit, hard project limit, auto-reload and concurrent usage first.")
    if maximum_reservation_micros(MODEL) > CAP_MICROS:
        raise SystemExit("Model reservation exceeds the Jalon 1 software cap.")

    from jsonschema import Draft202012Validator

    schema = json.loads((ROOT / "docs" / "fabrya.creative-blueprint.v1.schema.json").read_text())
    Draft202012Validator.check_schema(schema)
    validator = Draft202012Validator(schema)
    provider = OpenAICreativeProvider.from_env(model=MODEL, timeout_seconds=120)
    if provider is None or str(provider.client.base_url).rstrip("/") != "https://api.openai.com/v1":
        raise SystemExit("Expected the official OpenAI API endpoint.")
    async with provider.client:
        model = await provider.client.models.retrieve(MODEL)
        if model.id != MODEL:
            raise SystemExit("The OpenAI project did not confirm the exact requested model.")

        # Atomic marker across concurrent invocations. Keep it after any uncertain outcome.
        RUN.parent.mkdir(exist_ok=True)
        RUN.mkdir(mode=0o700)
        store = Store(RUN / "factory.sqlite3")
        project = store.create_project("Atelier Équinoxe — Jalon 1", new_project_token(), budget_micros=CAP_MICROS)
        project_id = str(project["id"])
        job, _ = store.create_job(project_id, BRIEF, "atelier-equinoxe-jalon1-live")
        job_id = str(job["id"])
        worker = GenerationOrchestrator(
            store,
            provider_enabled=True,
            provider=provider,
            generation_budget_micros=CAP_MICROS,
            max_call_micros=CAP_MICROS,
        )
        await worker.run_one_async()
        final = store.get_job(project_id, job_id)
        write_json("checkpoints.json", store.list_checkpoints(job_id))
        if final["status"] != "completed":
            raise SystemExit(f"Job {job_id}: {final['status']} ({final['error_code']}). Inspect the database.")

        saved = store.get_creative_blueprint(project_id, job_id)
        blueprint = saved["blueprint"]
        validator.validate(blueprint)
        generation = blueprint["generation"]
        if generation["provider"] != "openai" or generation["model"] != MODEL:
            raise SystemExit("The persisted blueprint has unexpected provider or model provenance.")
        write_json("creative-blueprint.json", blueprint)
        write_json("evidence.json", {
            "project": PROJECT,
            "job_id": job_id,
            "schema_validation": "passed",
            "blueprint_version": saved["version_number"],
            "generation": generation,
            "reserved_cost_micros_usd": maximum_reservation_micros(MODEL),
        })
        print(f"Blueprint and evidence persisted in {RUN}")


if __name__ == "__main__":
    asyncio.run(run())
