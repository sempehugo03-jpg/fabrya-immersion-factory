from __future__ import annotations

import asyncio
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

REPOSITORY = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPOSITORY))

from fabrya_factory.creative_blueprint import BLUEPRINT_VERSION, assemble_blueprint
from fabrya_factory.production import ProductionPipeline
from fabrya_factory.security import new_project_token
from fabrya_factory.store import Store
from tests.creative_reference_fixtures import REFERENCE_BRIEFS, blueprint_fixture


def main() -> int:
    repository = REPOSITORY
    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + uuid4().hex[:8]
    root = repository / "artifacts" / "phase-c-fixture-demo" / run_id
    root.mkdir(parents=True, exist_ok=True)
    store = Store(root / "factory.sqlite3")
    project = store.create_project("Phase C plumbing fixture", new_project_token(), budget_micros=0)
    job, replay = store.create_job(str(project["id"]), REFERENCE_BRIEFS["garage"], "phase-c-fixture-" + run_id)
    if replay:
        raise RuntimeError("Unexpected fixture job replay")
    blueprint = assemble_blueprint(blueprint_fixture("garage"), {
        "generation_id": "offline-fixture-" + run_id,
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "model": "OFFLINE_FIXTURE_NOT_OPENAI", "sdk_version": "not-used", "provider": "offline_fixture",
        "response_id": "fixture-no-response", "request_id": "fixture-no-request",
        "brief_sha256": "0" * 64, "prompt_version": "fabrya.creative-director/v1",
        "input_tokens": 0, "output_tokens": 0, "estimated_cost_micros_usd": 0,
    })
    report = asyncio.run(ProductionPipeline(store).run_fixture(str(project["id"]), str(job["id"]), blueprint, root / "artifacts"))
    output = {"report_path": str(root / "artifacts" / "phase-c-report.json"),
              "job_id": job["id"], "project_id": project["id"], "job_status": report["job_status"],
              "sandbox": report["steps"]["sandbox"], "browser_qa": report["steps"]["browser_qa"],
              "version_id": report["version"]["id"], "fixture_only": True,
              "external_provider_calls": 0, "cost_usd": 0}
    print(json.dumps(output, ensure_ascii=False, indent=2))
    return 0 if report["steps"]["sandbox"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
