"""Run real Playwright visual QA against an existing local build."""

from __future__ import annotations

import argparse
import asyncio
import json
import sys
from pathlib import Path

REPOSITORY = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPOSITORY / "src"))

from fabrya_factory.production import BrowserInspector, LocalPreviewServer


async def run(site: Path, screenshots: Path) -> dict[str, object]:
    with LocalPreviewServer(site) as url:
        return await BrowserInspector().inspect(url, site, screenshots)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--site", type=Path, required=True)
    parser.add_argument("--screenshots", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()
    result = asyncio.run(run(args.site.resolve(), args.screenshots.resolve()))
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result.get("status") == "passed" and result.get("executed") is True else 1


if __name__ == "__main__":
    raise SystemExit(main())
