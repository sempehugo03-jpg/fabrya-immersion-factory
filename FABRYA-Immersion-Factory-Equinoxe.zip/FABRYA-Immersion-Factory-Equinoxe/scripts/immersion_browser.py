"""Browser acceptance checks for generated sites."""

from __future__ import annotations

import os
from pathlib import Path
from urllib.parse import urlsplit

from fabrya_factory.production import LocalPreviewServer


async def inspect(site: Path, screenshots: Path) -> dict:
    from playwright.async_api import Error, async_playwright

    screenshots.mkdir(parents=True, exist_ok=True)
    checks: dict[str, bool] = {}
    errors: list[str] = []
    captures: list[str] = []
    with LocalPreviewServer(site) as url:
        async with async_playwright() as playwright:
            browser = await playwright.chromium.launch(
                executable_path=os.environ.get("PLAYWRIGHT_CHROMIUM_EXECUTABLE"),
                env={key: os.environ[key] for key in ("HOME", "PATH", "LANG", "TMPDIR") if key in os.environ},
            )
            try:
                for name, width, height, reduced in (
                    ("desktop", 1440, 900, False),
                    ("mobile", 390, 844, False),
                    ("mouvement-reduit", 390, 844, True),
                ):
                    context = await browser.new_context(
                        viewport={"width": width, "height": height},
                        is_mobile=width < 500, has_touch=width < 500,
                        reduced_motion="reduce" if reduced else "no-preference",
                        service_workers="block",
                    )
                    blocked: list[str] = []

                    async def route_request(route):
                        target = urlsplit(route.request.url)
                        if target.scheme in {"http", "https"} and target.netloc == urlsplit(url).netloc:
                            await route.continue_()
                        else:
                            blocked.append(target.scheme + ":" + target.netloc)
                            await route.abort()

                    await context.route("**/*", route_request)
                    await context.route_web_socket("**/*", lambda socket: socket.close())
                    page = await context.new_page()
                    page.set_default_timeout(4500)
                    page.on("pageerror", lambda error: errors.append(str(error)[:250]))
                    page.on("console", lambda msg: errors.append(msg.text[:250]) if msg.type == "error" else None)
                    page.on("response", lambda response: errors.append(f"HTTP {response.status} {urlsplit(response.url).path}")
                            if response.status >= 400 else None)

                    def record(check: str, passed: bool):
                        checks[f"{name}/{check}"] = passed

                    async def capture(state: str):
                        if not reduced:
                            path = screenshots / f"{name}-{state}.png"
                            await page.screenshot(path=path)
                            captures.append(path.name)

                    try:
                        response = await page.goto(url, wait_until="load")
                        record("http", response is not None and response.ok)
                        record("viewport", await page.evaluate(
                            "document.documentElement.scrollWidth <= innerWidth + 1 && "
                            "Math.abs(innerWidth - window.visualViewport.width) < 2"
                        ))
                        record("image-origine", await page.locator("[data-fabrya-hero]").evaluate(
                            """img => img instanceof HTMLImageElement && img.complete && img.naturalWidth >= 800
                            && img.getBoundingClientRect().width >= 160 && img.currentSrc.includes('/assets/')"""
                        ))
                        record("mention-synthétique", await page.locator("[data-fabrya-synthetic]").is_visible())
                        contact = page.locator("[data-fabrya-contact]")
                        record("action-visible", await contact.evaluate(
                            "node => { const b = node.getBoundingClientRect(); "
                            "return b.width > 1 && b.top >= 0 && b.bottom <= innerHeight; }"
                        ))
                        await capture("accueil")
                        await contact.focus()
                        await contact.press("Enter")
                        record("action-clavier", await page.locator("#contact").evaluate(
                            "node => location.hash === '#contact' || node.contains(document.activeElement) "
                            "|| node.matches('[open]')"
                        ))

                        form = page.locator("#contact")
                        subject = form.locator("[data-fabrya-request]")
                        submit = form.locator("[data-fabrya-submit]")
                        result = form.locator("[data-fabrya-result]")
                        await submit.click()
                        record("demande-vide", await subject.evaluate("node => !node.validity.valid"))
                        for test_text in ("Contrôle de freinage", "Préparation piste"):
                            await subject.fill(test_text)
                            await submit.press("Enter")
                            record(f"demande-{test_text}", test_text in await result.inner_text() and await result.is_visible())

                        await page.goto(url, wait_until="load")
                        enter = page.locator("[data-fabrya-enter]")
                        scene = page.locator("[data-fabrya-scene]")
                        await enter.click()
                        if reduced:
                            record("anim-absente", await page.evaluate(
                                "document.getAnimations().every(a => a.playState !== 'running')"
                            ))
                        else:
                            record("anim-visible", await scene.evaluate(
                                """async scene => {
                                  for (let i = 0; i < 12; i++) {
                                    if (scene.getAnimations({subtree:true}).some(animation =>
                                      animation.playState === 'running' && animation.effect.getTiming().duration >= 120
                                      && animation.effect.target?.getBoundingClientRect().width > 0)) return true;
                                    await new Promise(requestAnimationFrame);
                                  }
                                  return false;
                                }"""
                            ))
                        await scene.locator("[data-fabrya-service]").scroll_into_view_if_needed()
                        await capture("atelier")
                        await scene.locator("[data-fabrya-service]").click()
                        detail = page.locator("#prestation")
                        await detail.scroll_into_view_if_needed()
                        record("navigation-prestation", await detail.is_visible() and await detail.evaluate(
                            """node => { const b = node.getBoundingClientRect();
                            return b.bottom > 0 && b.top < innerHeight; }"""
                        ))
                        await detail.locator("[data-fabrya-back]").click()
                        record("retour", urlsplit(page.url).fragment in {"", "accueil", "atelier"}
                               and await enter.is_visible())
                        record("toutes-images-chargees", await page.locator("img").evaluate_all(
                            """async images => {
                              for (const image of images) image.loading = 'eager';
                              await Promise.allSettled(images.map(image => image.decode()));
                              const paths = images.map(image => new URL(image.currentSrc).pathname);
                              const hero = innerWidth < 500 ? '/assets/ouverture-mobile.webp' : '/assets/ouverture.webp';
                              return [hero, '/assets/scene-1.webp', '/assets/scene-2.webp'].every(path => paths.includes(path))
                                && images.every(image => image.complete && image.naturalWidth >= 800);
                            }"""
                        ))
                    except Error as exc:
                        errors.append(f"{name}: {str(exc).splitlines()[0][:250]}")
                    finally:
                        record("reseau-local", not blocked)
                        errors.extend(f"Requête externe bloquée: {target}" for target in blocked)
                        await context.close()
            finally:
                await browser.close()
    return {"status": "passed" if checks and all(checks.values()) and not errors else "failed",
            "checks": checks, "errors": errors, "captures": captures}
