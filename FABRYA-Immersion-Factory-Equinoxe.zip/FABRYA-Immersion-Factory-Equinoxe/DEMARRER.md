# FABRYA Immersion Factory · Atelier Équinoxe

Depuis le dossier décompressé, dans un terminal macOS ou Linux avec Python 3.12 ou supérieur :

```bash
bash lancer-equinoxe.sh
```

Saisir la clé du projet OpenAI FABRYA dans l'invite masquée. Une clé existante
injectée par un gestionnaire de secrets via `OPENAI_API_KEY` convient aussi.
Le lanceur installe Playwright et Chromium si nécessaire. La clé est lue en
mémoire et envoyée uniquement à `https://api.openai.com/v1` via TLS. La
prévisualisation s'ouvre sur le navigateur local après validation.

Utiliser les crédits déjà disponibles et vérifier que le rechargement
automatique est désactivé. Le budget logiciel par exécution est de 2 USD au
maximum. S'il y a des dépenses antérieures de la même mission, utiliser
`--budget-usd MONTANT` avec le plus petit montant entre 2 USD, le budget
cumulatif restant converti en USD et le crédit disponible. Le lanceur demande
une réserve minimale de 1,77 USD pour commencer. La limite logicielle ne
contrôle ni les dépenses concurrentes ni la facturation de l'organisation.
Les valeurs dans le registre résultent des tokens mesurés par l'API, valorisés
au tarif standard. Le tableau de bord OpenAI reste la référence de facturation.
Aucune relance automatique après une erreur API ou un résultat ambigu.

## Fichiers après une exécution

| Élément | Fichier ou dossier dans `atelier-equinoxe-resultat` |
| --- | --- |
| Site validé et exportable | `site/` |
| Captures d'accueil et d'atelier, desktop et mobile | `captures/` |
| Scène choisie et direction artistique | `creative-blueprint.json` |
| Images WebP et leur provenance | `media/`, `media-provenance.json` |
| Identifiants des requêtes, modèles, tokens et coûts en USD | `model-access.json`, `api-ledger.json` |
| Contrôles Chromium et versions | `tests.json`, `versions/` |

Les versions restent sur disque, y compris si un contrôle échoue. Le
répertoire final `site/` est promu uniquement lorsque Chromium valide le
parcours. Le formulaire prépare localement une demande fictive. Aucun
hébergement externe n'est utilisé par le lanceur. L'option `--sans-apercu`
permet l'exécution dans un environnement automatisé. Les options `--brief`
et `--sortie` permettent de traiter un autre client avec le même agent.

## Vérifications de cette livraison

Cette archive reprend le contenu de l'export `3412375`, sans historique Git
embarqué. Le lanceur réutilise le schéma créatif et la planification média de
cet export, puis délègue le design et le code à `gpt-6.1-sol`. Il demande les
quatre images à `gpt-image-2.6-sunburst` et peut demander au modèle une
correction ciblée à partir des échecs du navigateur.

- Suite du socle : 33 tests réussis, 1 test facturable ignoré.
- Test de bout en bout avec réponses fournisseur simulées et Chromium réel :
  6 échecs injectés et détectés en v1, 42 contrôles réussis en v2.
  Quatre captures techniques produites. Ces images de test ne sont pas
  incluses comme livrables artistiques.
- Exécution API dans cette session : aucun appel facturable, 0 USD dépensé.
  L'accès aux modèles sur le projet et le résultat artistique restent à
  vérifier sur l'exécution authentifiée.
