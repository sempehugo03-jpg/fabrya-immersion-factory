# FABRYA Immersion Factory

Independent, API-first codebase. This continues the Phase A repository at commit `c8d5f97`; it does not import or modify the existing FABRYA public site, legacy engines, deployments, Stripe accounts, or client data. The repository remains local because the available GitHub connector cannot create a new remote repository.

## Phase B — Creative Brain

**Implemented:** an async adapter around the official OpenAI Python SDK (`openai==3.52.0`) and the Responses API; strict JSON Schema output `fabrya.creative-blueprint/v1`; analysis of facts, assumptions and missing information; business-specific art direction; justified immersion and 3D choices; original-image prompts, desktop/mobile framing and authenticity/provenance notes; persistent job integration, checkpoints, usage/cost records, provider request IDs, and restart-safe no-automatic-retry behavior.

The four creative tasks run as one structured model request per job to reduce orchestration cost. The model has no tools, no browser, no stock-image access, and cannot generate website code in this phase. The prompts make the brief untrusted data and explicitly distinguish concept art from authentic client premises, staff, services and work. This is a prompt-level control, not a complete prompt-injection defense.

**Not implemented in Phase B:** image generation, 3D or motion assets, website source code, sandboxed execution, browser inspection, visual critique, preview hosting, publishing, or conversational editing. A successful blueprint is not a completed site.

## Safe defaults

Provider calls are disabled by default. The API key is only read server-side from `OPENAI_API_KEY`; it is not created, printed, included in checkpoints, or sent to the generated client. Both `FACTORY_GENERATION_BUDGET_USD` and `FACTORY_OPENAI_MAX_CALL_USD` default to `0`. SDK retries are disabled. Every job gets at most one persisted provider-attempt marker. If a timeout or process interruption leaves the outcome uncertain, the job is failed closed and is not replayed automatically.

The configured model must have a price schedule in `openai_provider.py`. The current default is `gpt-6.1-sol`. With the documented standard-context rates and token limits in code, the estimated maximum reservation is **$0.041 per blueprint** (16,000 input tokens × $1 / million + 5,000 output tokens × $5 / million). This is a reservation ceiling, not an observed charge. Actual token usage and estimated model cost are stored after a provider response. No real call has been made during Phase B.

## Local setup

Requires Python 3.12+. Install the pinned official SDK, then run the existing tests:

```bash
python3 -m pip install -e .
python3 -m unittest discover -s tests -v
```

To run the service locally with provider use still disabled:

```bash
export FACTORY_BOOTSTRAP_TOKEN="$(python3 -c 'import secrets; print(secrets.token_urlsafe(32))')"
export FACTORY_DATA_DIR="./data"
python3 -m fabrya_factory.main
```

The server binds to `127.0.0.1:8787` by default. To prepare a first real integration test, see [Phase B runbook](docs/phase-b-status.md). That runbook explicitly requires a configured key and an approved budget cap. Do not set those values until a real call is authorized.

## API

`POST /v1/projects/{project_id}/generations` accepts a brief and an idempotency key. The worker returns job state through `GET /v1/projects/{project_id}/generations/{job_id}` and, after a successful real OpenAI call, the saved blueprint through `/creative-blueprint` or `/result`. `GET /v1/projects/{project_id}/creative-blueprints` lists sequential generations for the project. The per-generation budget is assigned from the server setting at project creation; it remains zero by default.

See [OpenAPI](openapi.yaml), [architecture](docs/architecture.md), and [Phase B status and runbook](docs/phase-b-status.md). Phase A's initial state and limitations are retained in [phase-a-status.md](docs/phase-a-status.md).
