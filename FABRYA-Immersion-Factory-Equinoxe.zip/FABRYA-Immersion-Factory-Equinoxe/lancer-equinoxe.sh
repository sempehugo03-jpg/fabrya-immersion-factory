#!/usr/bin/env bash
set -eu
set +x
cd "$(dirname "$0")"
export PYTHONPATH="$PWD/src"
if ! python3 -c 'import playwright' 2>/dev/null; then
  python3 -m venv .venv-immersion
  .venv-immersion/bin/python -m pip install 'playwright==1.62.0'
  if ! command -v chromium >/dev/null && [ -z "${PLAYWRIGHT_CHROMIUM_EXECUTABLE:-}" ]; then
    .venv-immersion/bin/python -m playwright install chromium
  fi
  exec .venv-immersion/bin/python scripts/run_immersion.py "$@"
fi
exec python3 scripts/run_immersion.py "$@"
