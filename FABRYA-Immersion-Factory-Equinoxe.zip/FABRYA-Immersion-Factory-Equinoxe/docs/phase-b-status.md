# Phase B — implementation status and first live-test procedure

> **Phase B.1 update (17 November 2026):** SDK installation/transport compatibility, offline test results, and current cost-gate status are recorded in [`phase-b1-status.md`](phase-b1-status.md). Its current official Standard price calculation supersedes the historical estimate below; the default `gpt-6.1-sol` reservation is now $0.082, so a $0.05 cap blocks it.

## Delivered in code

| Area | Status | Evidence |
|---|---|---|
| Official OpenAI SDK adapter | Implemented, not live-tested | `openai==3.52.0`, `openai_provider.py`; async `AsyncOpenAI.responses.create`; server-side key read only |
| Structured creative output | Implemented | `creative_blueprint.py`; strict `fabrya.creative-blueprint/v1` schema and local validator |
| Brief analysis | Implemented as a schema-governed brain capability | `analysis`: facts, assumptions, unknowns, business, audience, conversion and constraints |
| Art direction | Implemented as a schema-governed brain capability | Concept, fit rationale, atmosphere, palette, type, composition, photo direction, narrative and pages |
| Immersion architecture | Implemented as a schema-governed brain capability | Signature moment, interactions, rationale, mobile/reduced-motion behavior, 3D choice and performance constraints |
| Original visual planner | Implemented; image generation is not | Per-asset role, prompt, framing, light, format, continuity and authentic-reference requirement; external stock explicitly false |
| Job integration and blueprint versions | Implemented locally | Existing worker executes async stage; sequential per-project results persist; `GET .../creative-blueprint` and `GET /v1/projects/{project_id}/creative-blueprints` |
| Budget and retries | Implemented fail-closed locally | $0 defaults, pre-call reservation, token usage and estimated-cost ledger, `max_retries=0`, one persisted call marker per job |
| Restart safety | Implemented fail-closed locally | `recover_interrupted_jobs`: requeues only before a provider marker; uncertain attempts are failed without replay |
| Real OpenAI quality | Not evaluated | No API request was executed; offline fixtures are explicitly marked `offline_fixture` |
| Images, websites, visual QA | Out of scope for Phase B | No images generated, no site code, no sandbox or browser run |

The core creative capabilities are delivered in one model call, not as four autonomous agents or reusable style templates. The visual planner outputs prompts but does not create image files. Model answers still require human evaluation for aesthetic quality and factual accuracy.

## Three offline reference briefs

The test briefs and hand-authored validation fixtures live in `tests/creative_reference_fixtures.py`. They are **not** model responses and are not used by production generation:

1. **Atelier Équinoxe:** premium sports/collector garage. Fixture concept: *Le silence avant le départ*, light revealing an explicitly conceptual car; photo-led, no WebGL because it adds weight without clear value.
2. **Podology practice:** appointments and patient reassurance, no treatment promises. Fixture concept: *La confiance au premier pas*, an abstract pressure line leads to booking; calm reduced-motion path, no medical diagnosis imagery.
3. **Interior architecture studio:** residential renovation and real portfolio distinction. Fixture concept: *Habiter la lumière*, a threshold into an imaginary room; WebGL is conditional on authorized space assets, with a light photographic fallback.

Automated tests check schema validity, facts/assumptions/missing information, originality and authenticity rules, tailored justified immersion, mobile and reduced-motion behavior, and distinct concepts. They do not judge real model creativity. The next qualitative comparison requires the separately authorized live test.

## Cost estimate and limits

Price source checked **17 November 2026**: [OpenAI pricing](https://platform.openai.com/pricing/) reports standard short-context rates for `gpt-6.1-sol` of **$1 / 1M input tokens** and **$5 / 1M output tokens**. With code limits of 16,000 input and 5,000 output tokens, the maximum reservation is **$0.041**. Configure `$0.05` per generation/call for the first test to leave a small margin. This excludes images (none are generated in Phase B).

This calculation uses the captured public rate schedule and a conservative local token-size heuristic. It is not an exact invoice and does not impose a hard limit at OpenAI. Before any API call, separately configure an OpenAI Platform project usage/spend limit. Pricing can change; recheck it before a live call. Unknown models have no cost schedule and are blocked before requests.

## Exact configuration needed for a future live test

The API key is not created, retrieved or embedded. An authorized operator will have to place an existing key in a server-side secret store/environment and then configure:

```text
FACTORY_OPENAI_ENABLED=true
FACTORY_OPENAI_MODEL=gpt-6.1-sol
FACTORY_GENERATION_BUDGET_USD=0.05
FACTORY_OPENAI_MAX_CALL_USD=0.05
FACTORY_OPENAI_TIMEOUT_SECONDS=60
OPENAI_API_KEY=<set through the server's secret store; do not commit or print>
```

Then start a clean local database, create a project (the per-generation project budget is assigned at creation), submit exactly one of the three briefs with a new `Idempotency-Key`, wait for the job, and inspect `/creative-blueprint` plus the `creative_blueprint_validated` checkpoint. Reusing that same job never repeats a provider request. A timeout or process exit after request start must be reviewed manually and will not be retried automatically.

**This procedure is documentation only. No key or budget was configured and no live call was made in this mandate.** The first test must only proceed after a separate explicit budget authorization and verification of an OpenAI Platform spend limit.

## Remaining limits and risks

- The SDK dependency is pinned but was not installed or imported in this run; local tests inject a fake async client. Thus API method shape follows the [official Responses API structured-output guidance](https://platform.openai.com/docs/guides/structured-outputs) and the [official Python SDK](https://github.com/openai/openai-python), but live compatibility remains unverified.
- The default SQLite database and single thread worker remain a local/single-node foundation, not a production queue. There is no distributed locking, rate limiting, key rotation workflow, secret manager integration or provider-side hard cost limit check.
- If the provider response arrives but the local process dies before saving it, the job is deliberately marked outcome-unknown and no automatic retry occurs. This prevents uncontrolled duplicates but can require manual resolution.
- Model/schema output cannot ensure good art direction. A real creative evaluation and prompt revision may be needed after the first authorized responses.
- Authentic visual references are not uploaded in the current API. The blueprint can identify missing references and label conceptual image prompts, but cannot inspect rights or verify client assets.
- No actual images, site, browser rendering, visual inspection or previews exist. Phase C onward needs separate validation.

## Verification on 17 November 2026

`python3 -m unittest discover -s tests -v`: **27 tests discovered, 26 passed, 1 skipped**. The skipped test is the guarded real OpenAI call. `compileall` and `git diff --check` passed. The tests used local SQLite and fake async responses; no external API request or network call was made by the application.
