# FABRYA Immersion Factory — Phase C.1

Vérification : 17 novembre 2026. Dépôt et historique conservés, à partir du commit Phase C `0bad826`.

## Résultat

Le parcours technique Atelier Équinoxe a été construit, ouvert dans Chromium piloté par Playwright, contrôlé aux dimensions demandées, puis inscrit comme version 2 dans le stockage local. Le job de démonstration est `completed` pour **la plomberie fixture uniquement**. Aucun appel fournisseur ni déploiement n'a été réalisé.

## Étapes et preuves

`Creative Blueprint fixture → Media Plan → médias fixture desktop/mobile → Site Plan → Immersion Runtime → Website Builder → sandbox → Playwright QA → version 2`

- Pipeline détaillé : `artifacts/phase-c-fixture-demo/20261117T211549Z-f9306118/artifacts/phase-c-report.json`.
- Résultat navigateur : `artifacts/phase-c-fixture-demo/20261117T211549Z-f9306118/artifacts/visual-qa-live.json`.
- Checkpoints persistés : `artifacts/phase-c-fixture-demo/20261117T211549Z-f9306118/artifacts/checkpoints.json`.
- Version persistée : `ver_6c30bc710a6140c2a3c4e3f993cfdb96`, numéro 2; manifeste sous le même dossier.
- Aperçu HTTP : `127.0.0.1` temporaire, fermé après le test. Aucun hébergement public ou URL persistante n'a été créé.

## Résultats Playwright

Playwright `1.62.0`, Chromium `156.0.8078.79` : **12 contrôles réussis**; zéro erreur console, erreur JavaScript ou requête réseau externe. Navigation Services, formulaire local sans envoi, menu mobile, overflow et `prefers-reduced-motion` ont été testés. Captures originales conservées dans ce dossier d'artefacts.

Captures originales :

- `screenshots/desktop-1440x900.png`
- `screenshots/mobile-390x844.png`

La panne initiale venait de deux environnements isolés : le shell de build interdit à Chromium d'ouvrir des sockets, tandis que le bureau possède Chromium mais pas l'interpréteur Playwright du venv. La QA a tourné sur le bureau isolé, avec le serveur loopback et le binaire Chromium déjà présents. `scripts/run_browser_qa.mjs` et son wrapper `scripts/run_browser_qa.sh` permettent de rejouer cette QA quand la distribution Python Playwright et Chromium sont disponibles ensemble.

## Connexion du worker et garde-fous

Le worker appelle maintenant `ProductionPipeline.run_generated` après un blueprint non-fixture. Le plan média est persisté; si le fournisseur image est désactivé, la chaîne s'arrête explicitement au checkpoint `visual_assets` et marque le job bloqué sans requête. Avec un fournisseur activé et un budget positif, le chemin implémenté poursuit les images, les plans, le site, le sandbox, la QA et la version.

Les réglages image sont désactivés par défaut et à zéro : `FACTORY_IMAGE_GENERATION_ENABLED=false`, `FACTORY_IMAGE_GENERATION_BUDGET_USD=0`, `FACTORY_IMAGE_MAX_CALL_USD=0`. La clé reste serveur seulement. Les opérations ambiguës ne sont pas rejouées automatiquement. Le test de ce mandat n'a invoqué ni OpenAI texte ni Images et a coûté 0 USD.

## Limites réelles

- Le blueprint et les médias Atelier Équinoxe de cette démonstration sont des fixtures. Aucun concept n'a été généré par OpenAI et aucun média ne doit être montré comme photo réelle.
- Le rendu actuel est HTML/CSS/JS statique, responsive et navigable; il n'est pas en React/TypeScript.
- L'immersion active une révélation au défilement issue du blueprint. Les primitives de profondeur sont simples; aucune scène Three.js/WebGL n'est produite.
- Le sandbox compile la syntaxe JavaScript et prouve le refus réseau via `bubblewrap + seccomp`; il ne construit pas de paquet React. L'inspection navigateur s'exécute dans Chromium isolé avec réseau externe bloqué, séparément du sandbox de syntaxe.
- Le formulaire est local uniquement. Aucun service de contact ni hébergement de preview n'est raccordé.
- Le budget cumulatif autorisé n'est pas vérifié par l'application elle-même contre le tableau de bord OpenAI. Il doit rester désactivé tant que le solde et le plafond opérationnel ne sont pas vérifiés; aucune clé ou limite OpenAI n'a été inspectée ici.

## Validation

`PYTHONPATH=src python -m unittest discover -v` : **34 tests, 33 réussis, 1 ignoré** (appel OpenAI payant). Le test couvre aussi le blocage avant toute génération image lorsque le fournisseur ou son budget est désactivé.
