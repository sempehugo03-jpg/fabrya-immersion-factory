# Briefs de référence Phase B

Ces briefs servent aux tests. Les exemples de blueprint utilisés par les tests hors fournisseur sont explicitement marqués `offline_fixture` et ne sont jamais présentés comme des réponses OpenAI.

## A. Garage automobile premium

> Atelier Équinoxe est un garage automobile premium spécialisé dans les véhicules sportifs et de collection. Je veux un site cinématographique, élégant, avec une expérience immersive dès l'ouverture, des images photoréalistes originales et une navigation remarquable.

Le test vérifie une révélation automobile originale et une décision justifiée sur l'utilité de la 3D. Le résultat ne doit pas laisser croire qu'une voiture conceptuelle est un véhicule client authentique ou une photo du garage.

## B. Cabinet de podologie

> Un cabinet de podologie reçoit des patients pour bilans et soins du pied. Le site doit rassurer, expliquer les prestations et faciliter la prise de rendez-vous, sans promettre de résultat médical.

Le test vérifie un parcours calme et accessible vers la prise de rendez-vous, sans imagerie de diagnostic ni promesse de soin.

## C. Studio d'architecture intérieure

> Un studio d'architecture intérieure accompagne des rénovations et aménagements résidentiels. Le site doit présenter sa méthode et ses projets, distinguer les réalisations authentiques des images conceptuelles et susciter des demandes de rendez-vous.

Le test vérifie un concept spatial et conditionne la 3D à des références de projets autorisées. Un intérieur imaginé doit être identifié comme conceptuel, et non comme une réalisation du studio.
