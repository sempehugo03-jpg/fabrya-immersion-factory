# Phase B.1 — validation du cerveau créatif OpenAI

Date de vérification : **17 novembre 2026**. Ce rapport complète Phase B et remplace ses anciennes indications de prix et de compatibilité SDK. Aucun appel OpenAI n'a été exécuté.

## Résultat synthétique

| Vérification | Résultat | Preuve |
|---|---|---|
| Dépôt repris | Oui, dépôt Phase A/B existant, HEAD initial `cd4d1af`, parent `c8d5f97`; aucun remote configuré | `git log -2`; pas de nouveau dépôt |
| SDK officiel épinglé | Installé dans `/tmp/fabrya-phase-b1-venv`, hors dépôt | `openai==3.52.0` installé et `openai.__version__ == 3.52.0`; version publiée le 16 novembre 2026 |
| Import et client asynchrone | Vérifiés | `AsyncOpenAI`, `responses.create` présents; POST Responses exercé via `httpx2.MockTransport`, sans réseau externe |
| Paramètres Responses | Vérifiés au transport simulé | `text.format.type=json_schema`, `strict=true`, `store=false`, `tools=[]`, `X-Client-Request-Id`; aucun retry SDK (`max_retries=0`) |
| Schéma | Vérifié hors fournisseur | Schéma publié identique au contrat runtime; validations métier et champs inconnus rejetés |
| Secret | Côté serveur | Lecture de `OPENAI_API_KEY` uniquement dans l'adaptateur Python serveur; `.env.example` vide; aucun secret imprimé ou ajouté |
| Tests hors fournisseur | **27 réussis, 1 ignoré** | `PYTHONPATH=src env -u FACTORY_LIVE_OPENAI_TEST /tmp/fabrya-phase-b1-venv/bin/python -m unittest discover -s tests -v` |
| Budget / idempotence | Vérifiés en local | Tests couvrent refus à zéro, rejet du dépassement, enregistrement de réservation, replay d'idempotence et absence de retry après issue incertaine |
| Limite OpenAI Platform | **Non vérifiée** | Aucun accès en lecture au projet, à son usage actuel, ou à ses réglages de limite n'est exposé dans cet environnement |
| Appel réel et qualité artistique | **Non exécutés / non évalués** | Test réel ignoré; les fixtures locales ne sont pas des réponses OpenAI |

## Compatibilité SDK et environnement

La dépendance `openai==3.52.0` s'installe et l'import fonctionne avec Python 3.12.14. Le SDK officiel documente `AsyncOpenAI` et l'appel asynchrone `await client.responses.create(...)`. Le test au transport simulé a vérifié la requête sérialisée et une réponse factice; il n'atteste ni accès réseau au fournisseur, ni disponibilité du modèle sur un compte.

Dans le shell de validation, un proxy SOCKS préconfiguré empêchait la création du client HTTP par défaut car l'option facultative `socksio` n'est pas installée. Sans ces variables proxy, ou avec un `httpx2.AsyncClient` explicitement fourni, le client se construit. Le transport simulé explicite a été utilisé pour vérifier le format. La configuration de proxy de l'environnement qui exécutera le premier test devra donc être contrôlée; l'environnement d'exécution de production n'a pas été inspecté.

Le schéma `fabrya.creative-blueprint/v1` a des clés obligatoires, interdit les propriétés additionnelles, et passe la validation locale. Le payload Responses n'expose aucun outil au modèle et désactive le stockage de réponse (`store=false`). Le code lit la clé API dans le processus serveur; aucun appel ou composant frontend ne reçoit cette clé.

## Barème et blocage financier

La page tarifaire officielle OpenAI, consultée le **17 novembre 2026**, donne pour le modèle par défaut `gpt-6.1-sol` les taux Standard de **2 $/million de tokens d'entrée et 10 $/million de tokens de sortie**. Avec les limites Phase B de 16 000 tokens d'entrée estimés et 5 000 tokens de sortie, le calcul de réservation corrigé est :

`16 000 × 2 $/1 000 000 + 5 000 × 10 $/1 000 000 = 0,082 $`.

Le plafond logiciel demandé de **0,05 $ refuse donc maintenant le modèle par défaut avant l'appel**. Le barème antérieur de Phase B (1 $/5 $) ne correspondait pas au tarif Standard du modèle par défaut; il a été corrigé dans `openai_provider.py`. Le test local verrouille le calcul à 0,082 $.

Cette réservation reste une estimation, car la taille du prompt est calculée par heuristique et le rapprochement fournisseur peut différer. OpenAI indique que le hard limit peut être appliqué avec un délai et que les dépenses enregistrées peuvent légèrement dépasser la limite configurée. Il n'existe donc pas ici de garantie technique absolue de facturation maximale à 0,05 $. **Aucun appel n'est acceptable sous ce mandat.**

La documentation OpenAI distingue alertes, limite de suivi et option « Enforce a hard limit ». Les limites peuvent arrêter les requêtes après dépense suivie, mais leur enforcement n'est pas instantané. Il faut un rôle Owner de l'organisation ou du projet pour vérifier et modifier ce réglage. L'accès de cette session ne permet pas de confirmer la limite, le montant déjà consommé, ni l'activation effective de l'enforcement. Le niveau d'usage du projet est donc **non vérifié**, et aucune nouvelle clé n'a été créée.

## Préparation artistique

Le test réel prévu utilise le brief garage Atelier Équinoxe déjà présent dans `tests/creative_reference_fixtures.py`. La requête vise une seule réponse structurée contenant l'analyse, le concept, la direction artistique, le scénario immersif, les interactions, les adaptations desktop/mobile et le plan média. Aucun concept artistique n'est injecté par les fixtures dans la requête réelle. Le résultat éventuel devra distinguer les faits du brief et les hypothèses; les images resteront à générer dans une phase ultérieure.

### Grille à appliquer à la vraie réponse

Noter chaque critère de 1 (non satisfaisant) à 5 (excellent), joindre une citation courte de la réponse ou une observation concrète, et marquer les faits/hypothèses inventés. La grille n'a pas encore été remplie : aucune réponse réelle n'existe.

| Critère | Ce qui sera observé |
|---|---|
| Originalité artistique | Concept propre au brief; absence de composition de template générique |
| Pertinence métier | Garage premium, véhicules sportifs/de collection, objectifs et limites du brief |
| Concept immersif | Moment d'entrée mémorable et intelligible, lié à l'expérience du visiteur |
| Justification des mouvements | Chaque effet sert la narration, la compréhension ou une action utile |
| Cohérence visuelle | Continuité de lumière, matière, palette, cadrage et intention entre les médias |
| Faisabilité technique | Interactions explicites et réalistes pour une future réalisation web |
| Mobile et accessibilité | Parcours mobile décrit, mouvement réduit et lisibilité traités |
| Absence de template imposé | Pas de concept, palette ou direction artistique pré-remplis dans le résultat |

## Procédure après autorisation

1. Un Owner FABRYA consulte dans OpenAI Platform le projet exact, son usage courant et ses réglages **Limits**; vérifie la limite mensuelle et active **Enforce a hard limit**. L'alerte seule ne bloque pas les appels. Il faut tenir compte du délai d'application et d'une possible légère dépense au-delà du seuil.
2. Le fondateur donne une autorisation explicite pour **un seul appel réel**, après examen de ce rapport et décision sur le modèle/plafond. Avec `gpt-6.1-sol`, un plafond logiciel de 0,05 $ est refusé; le faire passer exige soit un plafond supérieur à la réservation estimée, soit un modèle moins coûteux, ce qui change le test artistique. Aucun de ces choix n'est fait ici.
3. L'opérateur configure la clé déjà existante exclusivement dans le secret store serveur, configure budgets et modèle acceptés, puis définit `FACTORY_OPENAI_PLATFORM_LIMIT_VERIFIED=YES` après la vérification manuelle. Ne jamais committer, afficher ou transmettre la clé.
4. Il démarre une base locale vide, configure le runner et lance uniquement `tests.test_openai_live_opt_in`. Le test exige aussi `FACTORY_LIVE_OPENAI_TEST=AUTHORIZED`; il réalise un seul blueprint Atelier Équinoxe. Le SDK ne relance pas automatiquement; l'identifiant de tentative persisté empêche une répétition du même job. En cas de timeout ou résultat incertain, ne pas relancer avant examen manuel.
5. Il archive l'identifiant de réponse, l'identifiant de requête, les tokens, le coût réel fournisseur et le blueprint; puis remplit la grille ci-dessus. Les fixtures hors fournisseur ne remplacent pas cette évaluation.

**État maintenant : arrêt avant appel.** Le contrôle de limite plateforme n'est pas accessible, et le modèle par défaut ne tient pas dans le plafond de 0,05 $. Une autorisation explicite seule ne rendrait pas le plafond suffisant; il faut aussi trancher le budget ou le modèle. Phase C n'a pas commencé.

## Sources officielles consultées

- [OpenAI Python SDK — release v3.52.0 (16 novembre 2026)](https://github.com/openai/openai-python/releases/tag/v3.52.0)
- [OpenAI Python SDK — usage asynchrone](https://github.com/openai/openai-python)
- [Structured Outputs et format `json_schema`](https://developers.openai.com/api/docs/guides/structured-outputs)
- [Tarification API OpenAI](https://developers.openai.com/api/docs/pricing)
- [Réglages de dépenses des projets](https://help.openai.com/en/articles/9186755-managing-projects-in-the-api-platform)
- [Comportement des limites de dépense](https://help.openai.com/en/articles/6614457-troubleshooting-api-usage-and-spend-limits)
