# Phase A — actual status

| Capability | Status | Evidence in this repository |
|---|---|---|
| Independent code base | Implemented locally | Git repository initialized; no remote repository configured |
| Versioned API | Implemented for local tests | `openapi.yaml`, `api.py` |
| Authentication and project isolation | Implemented for local tests | Bootstrap token, per-project bearer hash; cross-project lookup returns 404 |
| Typed contracts / 15 tools | Interfaces only | `contracts.py`, `tools.py`, `/v1/tools` |
| Orchestrator | Implemented as a fail-closed state machine | Job is checkpointed and blocked before any external call |
| Persistent jobs / checkpoints | Implemented locally | SQLite WAL tables in `store.py` |
| Cost supervisor | Implemented as local accounting/gate | Budget defaults to zero; positive reservation is refused |
| OpenAI text or image calls | Not implemented | No provider adapter and no credentials used |
| Website code generation | Not implemented | No HTML/CSS generated |
| Code execution sandbox | Interface only | No execution or network access is provided |
| Browser QA / image captures | Not implemented | No browser driver or screenshots |
| Versions / restore | Partial foundation | Version table and listing; no artifact snapshots or restore operation |
| Private preview URL | Not implemented | Endpoint returns 503 and creates no URL |
| Production publication | Disabled | Endpoint returns 503 |

## Verification requested for Phase A

The suite verifies contract validation, token isolation, idempotency, state transitions, durable checkpoints, zero-budget refusal, provider-off blocking, and API behavior. It does **not** verify OpenAI output, website quality, sandbox isolation, browser rendering, preview hosting, or production compatibility.

Latest local verification: **19 unit/integration tests passed** on Python 3.12.14. The HTTP smoke test bound only to loopback, created a test project and queued job, checked the provider-blocked state, and confirmed cross-project access is refused. `compileall` and staged whitespace checks passed. No external API or network service was called.

## Remaining Phase A gaps

- No remote GitHub repository was created; the connected GitHub tools do not expose repository creation. This repository currently exists only in the local workspace and its exportable archive.
- API key rotation/revocation, rate limiting, audit-log retention, and production-grade identity provider are not implemented.
- Durable queue is SQLite and single-node; worker lease recovery, distributed claims, and operational monitoring are not implemented.
- Typed tool interfaces are contracts only. No tool implementation is registered.
- No OpenAI adapter, prompt-injection mitigation runtime, container sandbox, filtered egress, media object store, Playwright inspector, real visual critic, preview host, or publication provider exists.
- Version rows currently retain manifests only; artifact snapshot/restore is not implemented.
- No generated site or screenshot exists, so visual acceptance criteria are not yet testable.

