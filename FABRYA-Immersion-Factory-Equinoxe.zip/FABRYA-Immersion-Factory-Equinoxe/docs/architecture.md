# Architecture — Phase B

```mermaid
flowchart LR
  Client["Future FABRYA platform"] --> API["Versioned local API"]
  API --> Auth["Project auth"]
  API --> Queue["SQLite jobs and checkpoints"]
  Queue --> Orchestrator["Async job worker"]
  Orchestrator --> Budget["Zero-default cost gate"]
  Budget --> Brain["Creative Brain"]
  Brain --> Responses["OpenAI Responses API"]
  Brain --> Blueprint["Validated creative blueprint"]
  Blueprint -. "later phases" .-> Media["Image generation"]
  Media -.-> Sandbox["Site sandbox"]
```

## Decisions

- **Python 3.12+ for API, storage and orchestration:** SQLite supplies the local durable job/checkpoint store. The official OpenAI Python SDK is pinned to `3.52.0`; it is imported only when server-side OpenAI configuration is enabled and an API key is available.
- **One structured Responses API request per creative job:** brief analysis, art direction, immersion decisions and original visual planning are returned together to limit cost and preserve a single blueprint version.
- **Provider calls fail closed:** `FACTORY_OPENAI_ENABLED=false`, project budget zero and per-call ceiling zero are defaults. An API key alone cannot enable calls.
- **At-most-one local provider attempt per job:** the worker persists a call marker before requesting, disables SDK retries, and stores a stable client request ID for correlation. If a request outcome is uncertain, the attempt is failed closed and is not automatically repeated.
- **Cost reservation is conservative, not a billing guarantee:** the local estimate uses a captured token price schedule, a bounded input size and a maximum output token count. Actual usage is recorded after a response. A separate OpenAI project spend limit must be configured by the operator before a live test.
- **The brief is untrusted text:** instructions ask the model to analyze it as data, not follow embedded role changes, request secrets, browse, or call tools. This lowers risk but is not a complete prompt-injection defense. No brief is executed.
- **Generated code remains unexecuted:** no website, HTML, CSS, images, browser captures, or preview URLs are produced in Phase B.

## Persistent record

The existing SQLite database now also stores one provider-attempt record and one Creative Blueprint per job. Each project's blueprints receive a sequential content version and point to the previous generation; each blueprint records schema, prompt and SDK versions, generation ID, brief SHA-256, provider/model, client and provider request IDs, token counts and estimated cost. Checkpoints record stage transitions without storing secrets. A started call interrupted by process exit is marked uncertain and not replayed.

The production FABRYA site and all prior engines remain outside this repository.
